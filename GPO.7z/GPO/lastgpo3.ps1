﻿# Requires Administrator privileges to run

Write-Host "Applying Windows Firewall Group Policies..." -ForegroundColor Green

# Array to store the status of each GPO for export
$GPOStatusReport = @()

# Function to set a registry value, creating the path if it doesn't exist
function Set-GPOption {
    Param(
        [Parameter(Mandatory=$true)]
        [string]$Path,
        [Parameter(Mandatory=$true)]
        [string]$Name,
        [Parameter(Mandatory=$true)]
        $Value,
        [Parameter(Mandatory=$true)]
        [string]$Type,
        [Parameter(Mandatory=$false)]
        [string]$Description = "" # Optional description for status output
    )
    $FullKeyPath = "HKLM:\" + $Path
    try {
        if (-not (Test-Path $FullKeyPath)) {
            New-Item -Path $FullKeyPath -Force | Out-Null
            Write-Host "Created Registry Path: $FullKeyPath" -ForegroundColor DarkGray
        }
        Set-ItemProperty -Path $FullKeyPath -Name $Name -Value $Value -Type $Type -Force
        Write-Host "SET: '$($Description)' ($Name) to Value '$Value' in '$Path'" -ForegroundColor Cyan
    }
    catch {
        Write-Error "Failed to set policy '$Name'. Error: $($_.Exception.Message)"
    }
}

# Function to get and return the status of a registry-based GPO as an object
function Get-GPOptionStatus {
    Param(
        [Parameter(Mandatory=$true)]
        [string]$Path,
        [Parameter(Mandatory=$true)]
        [string]$Name,
        [Parameter(Mandatory=$true)]
        $ExpectedValue,
        [Parameter(Mandatory=$true)]
        [string]$Description
    )
    $FullKeyPath = "HKLM:\" + $Path
    $CurrentValue = $null
    $Status = "Not Found" # Default status
    $StatusColor = "Yellow"

    try {
        if (Test-Path $FullKeyPath) {
            $RegProperty = Get-ItemProperty -Path $FullKeyPath -Name $Name -ErrorAction SilentlyContinue
            if ($RegProperty -and $RegProperty.PSObject.Properties.Name -contains $Name) {
                $CurrentValue = $RegProperty.$Name
                if ($CurrentValue -eq $ExpectedValue) {
                    $Status = "Applied"
                    $StatusColor = "Green"
                } else {
                    $Status = "Mismatch"
                    $StatusColor = "Red"
                }
            } else {
                $Status = "Key Value Missing"
                $StatusColor = "Yellow"
            }
        } else {
            $Status = "Registry Path Missing"
            $StatusColor = "Red"
        }
    }
    catch {
        $Status = "Error: $($_.Exception.Message)"
        $StatusColor = "Red"
    }

    # Output to console
    Write-Host "STATUS: '$($Description)' ($Name)" -NoNewline
    Write-Host " | Current: '$($CurrentValue)'" -NoNewline
    Write-Host " | Expected: '$ExpectedValue'" -NoNewline
    Write-Host " | Result: $($Status)" -ForegroundColor $StatusColor

    # Create a custom object to return
    [PSCustomObject]@{
        Description    = $Description
        RegistryPath   = $FullKeyPath
        RegistryKeyName= $Name
        ExpectedValue  = $ExpectedValue
        CurrentValue   = $CurrentValue
        Status         = $Status
    }
}

# --- Windows Firewall: Domain Profile ---
Write-Host "`n--- Configuring Windows Firewall: Domain Profile ---" -ForegroundColor Yellow

# 'Windows Firewall: Domain: Logging: Name' is set to '%SystemRoot%\System32\logfiles\firewall\domainfw.log'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging" -Name "LogFile" -Value "%SystemRoot%\System32\logfiles\firewall\domainfw.log" -Type String -Description "Domain FW Log File Name"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging" -Name "LogFile" -ExpectedValue "%SystemRoot%\System32\logfiles\firewall\domainfw.log" -Description "Domain FW Log File Name"

# 'Windows Firewall: Domain: Logging: Log dropped packets' is set to 'Yes'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging" -Name "LogDroppedPackets" -Value 1 -Type DWORD -Description "Domain FW Log Dropped Packets" # 1 for Yes
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging" -Name "LogDroppedPackets" -ExpectedValue 1 -Description "Domain FW Log Dropped Packets"

# 'Windows Firewall: Domain: Logging: Log successful connections' is set to 'Yes'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging" -Name "LogSuccessfulConnections" -Value 1 -Type DWORD -Description "Domain FW Log Successful Connections" # 1 for Yes
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging" -Name "LogSuccessfulConnections" -ExpectedValue 1 -Description "Domain FW Log Successful Connections"


# --- Windows Firewall: Private Profile ---
Write-Host "`n--- Configuring Windows Firewall: Private Profile ---" -ForegroundColor Yellow

# 'Windows Firewall: Private: Logging: Name' is set to '%SystemRoot%\System32\logfiles\firewall\privatefw.log'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging" -Name "LogFile" -Value "%SystemRoot%\System32\logfiles\firewall\privatefw.log" -Type String -Description "Private FW Log File Name"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging" -Name "LogFile" -ExpectedValue "%SystemRoot%\System32\logfiles\firewall\privatefw.log" -Description "Private FW Log File Name"

# 'Windows Firewall: Private: Logging: Log dropped packets' is set to 'Yes'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging" -Name "LogDroppedPackets" -Value 1 -Type DWORD -Description "Private FW Log Dropped Packets" # 1 for Yes
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging" -Name "LogDroppedPackets" -ExpectedValue 1 -Description "Private FW Log Dropped Packets"

# 'Windows Firewall: Private: Logging: Log successful connections' is set to 'Yes'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging" -Name "LogSuccessfulConnections" -Value 1 -Type DWORD -Description "Private FW Log Successful Connections" # 1 for Yes
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging" -Name "LogSuccessfulConnections" -ExpectedValue 1 -Description "Private FW Log Successful Connections"


# --- Windows Firewall: Public Profile ---
Write-Host "`n--- Configuring Windows Firewall: Public Profile ---" -ForegroundColor Yellow

# 'Windows Firewall: Public: Firewall state' is set to 'On (recommended)'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -Name "EnableFirewall" -Value 1 -Type DWORD -Description "Public FW State (On)" # 1 for On
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -Name "EnableFirewall" -ExpectedValue 1 -Description "Public FW State (On)"

# 'Windows Firewall: Public: Inbound connections' is set to 'Block (default)'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -Name "DefaultInboundAction" -Value 1 -Type DWORD -Description "Public FW Inbound Connections (Block)" # 1 for Block
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -Name "DefaultInboundAction" -ExpectedValue 1 -Description "Public FW Inbound Connections (Block)"

# 'Windows Firewall: Public: Settings: Apply local firewall rules' is set to 'No'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Settings" -Name "AllowLocalPolicyMerge" -Value 0 -Type DWORD -Description "Public FW Apply Local Rules" # 0 for No
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Settings" -Name "AllowLocalPolicyMerge" -ExpectedValue 0 -Description "Public FW Apply Local Rules"

# 'Windows Firewall: Public: Logging: Name' is set to '%SystemRoot%\System32\logfiles\firewall\publicfw.log'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging" -Name "LogFile" -Value "%SystemRoot%\System32\logfiles\firewall\publicfw.log" -Type String -Description "Public FW Log File Name"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging" -Name "LogFile" -ExpectedValue "%SystemRoot%\System32\logfiles\firewall\publicfw.log" -Description "Public FW Log File Name"

# 'Windows Firewall: Public: Logging: Log dropped packets' is set to 'Yes'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging" -Name "LogDroppedPackets" -Value 1 -Type DWORD -Description "Public FW Log Dropped Packets" # 1 for Yes
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging" -Name "LogDroppedPackets" -ExpectedValue 1 -Description "Public FW Log Dropped Packets"

# 'Windows Firewall: Public: Logging: Log successful connections' is set to 'Yes'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging" -Name "LogSuccessfulConnections" -Value 1 -Type DWORD -Description "Public FW Log Successful Connections" # 1 for Yes
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging" -Name "LogSuccessfulConnections" -ExpectedValue 1 -Description "Public FW Log Successful Connections"


Write-Host "`n--- Policy Application Summary ---" -ForegroundColor Green
Write-Host "All specified policies have been applied (or attempted) to the registry." -ForegroundColor Green
Write-Host "Please review the 'STATUS' lines above to verify current registry values." -ForegroundColor Green
Write-Host "For some policies, a 'gpupdate /force' and/or system reboot may be required for full effect." -ForegroundColor Green


### Exporting Status Report

$ReportFilePath = "$env:TEMP\GPO_Firewall_Status_Report_$(Get-Date -Format 'yyyyMMdd_HHmmss')"

Write-Host "`n--- Exporting GPO Status Report ---" -ForegroundColor Yellow

# Export to CSV (Recommended for easy viewing in Excel)
$CSVPath = $ReportFilePath + ".csv"
try {
    $GPOStatusReport | Export-Csv -Path $CSVPath -NoTypeInformation -Encoding UTF8
    Write-Host "GPO status report exported to CSV: $CSVPath" -ForegroundColor Green
}
catch {
    Write-Error "Failed to export CSV report: $($_.Exception.Message)"
}

# Export to XML (Uncomment the following lines if you prefer XML)
# $XMLPath = $ReportFilePath + ".xml"
# try {
#     $GPOStatusReport | Export-Clixml -Path $XMLPath
#     Write-Host "GPO status report exported to XML: $XMLPath" -ForegroundColor Green
# }
# catch {
#     Write-Error "Failed to export XML report: $($_.Exception.Message)"
# }

Write-Host "`nScript execution complete." -ForegroundColor Green