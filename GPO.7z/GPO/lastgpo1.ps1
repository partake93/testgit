﻿# Requires Administrator privileges to run

Write-Host "Applying Local Group Policies..." -ForegroundColor Green

# Array to store the status of each GPO for export
$GPOStatusReport = @()

# Function to set a registry value, creating the path if it doesn't exist
function Set-GPOption {
    Param(
        [Parameter(Mandatory=$true)]
        [string]$Path,
        [Parameter(Mandatory=$true)]
        [string]$Name,
        [Parameter(Mandatory=$true)]
        $Value,
        [Parameter(Mandatory=$true)]
        [string]$Type,
        [Parameter(Mandatory=$false)]
        [string]$Description = "" # Optional description for status output
    )
    $FullKeyPath = "HKLM:\" + $Path
    try {
        if (-not (Test-Path $FullKeyPath)) {
            New-Item -Path $FullKeyPath -Force | Out-Null
            Write-Host "Created Registry Path: $FullKeyPath" -ForegroundColor DarkGray
        }
        Set-ItemProperty -Path $FullKeyPath -Name $Name -Value $Value -Type $Type -Force
        Write-Host "SET: '$($Description)' ($Name) to Value '$Value' in '$Path'" -ForegroundColor Cyan
    }
    catch {
        Write-Error "Failed to set policy '$Name'. Error: $($_.Exception.Message)"
    }
}

# Function to get and return the status of a registry-based GPO as an object
function Get-GPOptionStatus {
    Param(
        [Parameter(Mandatory=$true)]
        [string]$Path,
        [Parameter(Mandatory=$true)]
        [string]$Name,
        [Parameter(Mandatory=$true)]
        $ExpectedValue,
        [Parameter(Mandatory=$true)]
        [string]$Description
    )
    $FullKeyPath = "HKLM:\" + $Path
    $CurrentValue = $null
    $Status = "Not Found" # Default status
    $StatusColor = "Yellow"

    try {
        if (Test-Path $FullKeyPath) {
            $RegProperty = Get-ItemProperty -Path $FullKeyPath -Name $Name -ErrorAction SilentlyContinue
            if ($RegProperty -and $RegProperty.PSObject.Properties.Name -contains $Name) {
                $CurrentValue = $RegProperty.$Name
                if ($CurrentValue -eq $ExpectedValue) {
                    $Status = "Applied"
                    $StatusColor = "Green"
                } else {
                    $Status = "Mismatch"
                    $StatusColor = "Red"
                }
            } else {
                $Status = "Key Value Missing"
                $StatusColor = "Yellow"
            }
        } else {
            $Status = "Registry Path Missing"
            $StatusColor = "Red"
        }
    }
    catch {
        $Status = "Error: $($_.Exception.Message)"
        $StatusColor = "Red"
    }

    # Output to console
    Write-Host "STATUS: '$($Description)' ($Name)" -NoNewline
    Write-Host " | Current: '$($CurrentValue)'" -NoNewline
    Write-Host " | Expected: '$ExpectedValue'" -NoNewline
    Write-Host " | Result: $($Status)" -ForegroundColor $StatusColor

    # Create a custom object to return
    [PSCustomObject]@{
        Description    = $Description
        RegistryPath   = $FullKeyPath
        RegistryKeyName= $Name
        ExpectedValue  = $ExpectedValue
        CurrentValue   = $CurrentValue
        Status         = $Status
    }
}

# --- Printer Policies ---
Write-Host "`n--- Configuring Printer Policies ---" -ForegroundColor Yellow
# 'Limits print driver installation to Administrators' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" -Name "RestrictDriverInstallationToAdministrators" -Value 1 -Type DWORD -Description "Limit Print Driver Installation to Admins"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" -Name "RestrictDriverInstallationToAdministrators" -ExpectedValue 1 -Description "Limit Print Driver Installation to Admins"

# 'Manage processing of Queue-specific files' is set to 'Enabled: Limit Queue-specific files to Color profiles'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows NT\Printers\PrintQueue" -Name "ManageQueueSpecificFiles" -Value 3 -Type DWORD -Description "Manage processing of Queue-specific files"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows NT\Printers\PrintQueue" -Name "ManageQueueSpecificFiles" -ExpectedValue 3 -Description "Manage processing of Queue-specific files"

# 'Point and Print Restrictions: When installing drivers for a new connection' is set to 'Enabled: Show warning and elevation prompt'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" -Name "NoWarningNoElevationOnInstall" -Value 0 -Type DWORD -Description "Point and Print Restrictions (New Connection)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" -Name "NoWarningNoElevationOnInstall" -ExpectedValue 0 -Description "Point and Print Restrictions (New Connection)"

# 'Point and Print Restrictions: When updating drivers for an existing connection' is set to 'Enabled: Show warning and elevation prompt'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" -Name "UpdatePromptBehavior" -Value 1 -Type DWORD -Description "Point and Print Restrictions (Existing Connection)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" -Name "UpdatePromptBehavior" -ExpectedValue 1 -Description "Point and Print Restrictions (Existing Connection)"


# --- System Notifications ---
Write-Host "`n--- Configuring System Notifications ---" -ForegroundColor Yellow
# 'Turn off notifications network usage' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Policies\System" -Name "DisableNetworkUsageNotifications" -Value 1 -Type DWORD -Description "Turn off notifications network usage"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Policies\System" -Name "DisableNetworkUsageNotifications" -ExpectedValue 1 -Description "Turn off notifications network usage"


# --- Event Logging ---
Write-Host "`n--- Configuring Event Logging ---" -ForegroundColor Yellow
# 'Include command line in process creation events' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit" -Name "IncludeCommandLine" -Value 1 -Type DWORD -Description "Include command line in process creation events"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit" -Name "IncludeCommandLine" -ExpectedValue 1 -Description "Include command line in process creation events"


# --- Credential Delegation ---
Write-Host "`n--- Configuring Credential Delegation ---" -ForegroundColor Yellow
# 'Remote host allows delegation of non-exportable credentials' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation" -Name "AllowDelegationOfNonExportableCredentials" -Value 1 -Type DWORD -Description "Remote host allows delegation of non-exportable credentials"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation" -Name "AllowDelegationOfNonExportableCredentials" -ExpectedValue 1 -Description "Remote host allows delegation of non-exportable credentials"


# --- Device Installation ---
Write-Host "`n--- Configuring Device Installation ---" -ForegroundColor Yellow
# 'Prevent device metadata retrieval from the Internet' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings" -Name "PreventDeviceMetadataFromNetwork" -Value 1 -Type DWORD -Description "Prevent device metadata retrieval from the Internet"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings" -Name "PreventDeviceMetadataFromNetwork" -ExpectedValue 1 -Description "Prevent device metadata retrieval from the Internet"


# --- Group Policy Processing ---
Write-Host "`n--- Configuring Group Policy Processing ---" -ForegroundColor Yellow
# 'Configure security policy processing: Do not apply during periodic background processing' is set to 'Enabled: FALSE'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\GroupPolicy\Security" -Name "NoGPOListChanges" -Value 0 -Type DWORD -Description "Security policy processing: Do not apply during periodic background processing"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\GroupPolicy\Security" -Name "NoGPOListChanges" -ExpectedValue 0 -Description "Security policy processing: Do not apply during periodic background processing"

# 'Configure security policy processing: Process even if the Group Policy objects have not changed' is set to 'Enabled: TRUE'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\GroupPolicy\{3AF3B7A9-867F-4B14-B095-E584852BF196}" -Name "ForceRefresh" -Value 1 -Type DWORD -Description "Security policy processing: Process even if GPOs haven't changed"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\GroupPolicy\{3AF3B7A9-867F-4B14-B095-E584852BF196}" -Name "ForceRefresh" -ExpectedValue 1 -Description "Security policy processing: Process even if GPOs haven't changed"


# --- Kernel DMA Protection ---
Write-Host "`n--- Configuring Kernel DMA Protection ---" -ForegroundColor Yellow
# 'Enumeration policy for external devices incompatible with Kernel DMA Protection' is set to 'Enabled: Block All'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" -Name "KernelDMABlockExternalDevices" -Value 1 -Type DWORD -Description "Enumeration policy for external devices incompatible with Kernel DMA Protection"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" -Name "KernelDMABlockExternalDevices" -ExpectedValue 1 -Description "Enumeration policy for external devices incompatible with Kernel DMA Protection"


# --- Password Policies (Local Account Settings) ---
Write-Host "`n--- Configuring Local Password Policies ---" -ForegroundColor Yellow
# Note: These local password policies apply to local accounts. Domain accounts are governed by domain GPOs.
# 'Configure password backup directory' is set to 'Enabled: Active Directory'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Cryptography\ProtectAdmin" -Name "EnablePasswordBackup" -Value 1 -Type DWORD -Description "Configure password backup directory"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Cryptography\ProtectAdmin" -Name "EnablePasswordBackup" -ExpectedValue 1 -Description "Configure password backup directory"

# 'Password Settings: Password Complexity' is set to 'Enabled: Large letters + small letters + numbers + special characters'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "PasswordComplexity" -Value 1 -Type DWORD -Description "Password Complexity"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "PasswordComplexity" -ExpectedValue 1 -Description "Password Complexity"

# 'Password Settings: Password Length' is set to 'Enabled: 15 or more'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "MinPasswordLength" -Value 15 -Type DWORD -Description "Password Length"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "MinPasswordLength" -ExpectedValue 15 -Description "Password Length"

# 'Password Settings: Password Age (Days)' is set to 'Enabled: 30 or fewer'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "MaximumPasswordAge" -Value 30 -Type DWORD -Description "Password Age (Days)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "MaximumPasswordAge" -ExpectedValue 30 -Description "Password Age (Days)"


# --- User Activities and Clipboard ---
Write-Host "`n--- Configuring User Activities and Clipboard ---" -ForegroundColor Yellow
# 'Allow Clipboard synchronization across devices' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "AllowCrossDeviceClipboard" -Value 0 -Type DWORD -Description "Allow Clipboard synchronization across devices"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "AllowCrossDeviceClipboard" -ExpectedValue 0 -Description "Allow Clipboard synchronization across devices"

# 'Allow upload of User Activities' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "AllowActivities" -Value 0 -Type DWORD -Description "Allow upload of User Activities"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "AllowActivities" -ExpectedValue 0 -Description "Allow upload of User Activities"


# --- Autoplay ---
Write-Host "`n--- Configuring Autoplay ---" -ForegroundColor Yellow
# 'Turn off Autoplay' is set to 'Enabled: All drives'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "NoAutorun" -Value 1 -Type DWORD -Description "Turn off Autoplay"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "NoAutorun" -ExpectedValue 1 -Description "Turn off Autoplay"


# --- Cloud Content ---
Write-Host "`n--- Configuring Cloud Content ---" -ForegroundColor Yellow
# 'Turn off cloud consumer account state content' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Name "DisableConsumerAccountStateContent" -Value 1 -Type DWORD -Description "Turn off cloud consumer account state content"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Name "DisableConsumerAccountStateContent" -ExpectedValue 1 -Description "Turn off cloud consumer account state content"


Write-Host "`n--- Policy Application Summary ---" -ForegroundColor Green
Write-Host "All specified policies have been applied (or attempted) to the registry." -ForegroundColor Green
Write-Host "Please review the 'STATUS' lines above to verify current registry values." -ForegroundColor Green
Write-Host "For some policies, a 'gpupdate /force' and/or system reboot may be required for full effect." -ForegroundColor Green


# --- Exporting Status Report ---
$ReportFilePath = "$env:TEMP\GPO_Status_Report_$(Get-Date -Format 'yyyyMMdd_HHmmss')"

Write-Host "`n--- Exporting GPO Status Report ---" -ForegroundColor Yellow

# Export to CSV
$CSVPath = $ReportFilePath + ".csv"
try {
    $GPOStatusReport | Export-Csv -Path $CSVPath -NoTypeInformation -Encoding UTF8
    Write-Host "GPO status report exported to CSV: $CSVPath" -ForegroundColor Green
}
catch {
    Write-Error "Failed to export CSV report: $($_.Exception.Message)"
}

# Export to XML (uncomment the following lines if you prefer XML)
# $XMLPath = $ReportFilePath + ".xml"
# try {
#     $GPOStatusReport | Export-Clixml -Path $XMLPath
#     Write-Host "GPO status report exported to XML: $XMLPath" -ForegroundColor Green
# }
# catch {
#     Write-Error "Failed to export XML report: $($_.Exception.Message)"
# }

Write-Host "`nScript execution complete." -ForegroundColor Green