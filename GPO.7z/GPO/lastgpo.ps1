﻿# Requires Administrator privileges to run

Write-Host "Applying Local Group Policies..." -ForegroundColor Green

# Array to store the status of each GPO for export
$GPOStatusReport = @()

# Function to set a registry value, creating the path if it doesn't exist
function Set-GPOption {
    Param(
        [Parameter(Mandatory=$true)]
        [string]$Path,
        [Parameter(Mandatory=$true)]
        [string]$Name,
        [Parameter(Mandatory=$true)]
        $Value,
        [Parameter(Mandatory=$true)]
        [string]$Type,
        [Parameter(Mandatory=$false)]
        [string]$Description = "" # Optional description for status output
    )
    $FullKeyPath = "HKLM:\" + $Path
    try {
        if (-not (Test-Path $FullKeyPath)) {
            New-Item -Path $FullKeyPath -Force | Out-Null
            Write-Host "Created Registry Path: $FullKeyPath" -ForegroundColor DarkGray
        }
        Set-ItemProperty -Path $FullKeyPath -Name $Name -Value $Value -Type $Type -Force
        Write-Host "SET: '$($Description)' ($Name) to Value '$Value' in '$Path'" -ForegroundColor Cyan
    }
    catch {
        Write-Error "Failed to set policy '$Name'. Error: $($_.Exception.Message)"
    }
}

# Function to get and return the status of a registry-based GPO as an object
function Get-GPOptionStatus {
    Param(
        [Parameter(Mandatory=$true)]
        [string]$Path,
        [Parameter(Mandatory=$true)]
        [string]$Name,
        [Parameter(Mandatory=$true)]
        $ExpectedValue,
        [Parameter(Mandatory=$true)]
        [string]$Description
    )
    $FullKeyPath = "HKLM:\" + $Path
    $CurrentValue = $null
    $Status = "Not Found" # Default status
    $StatusColor = "Yellow"

    try {
        if (Test-Path $FullKeyPath) {
            $RegProperty = Get-ItemProperty -Path $FullKeyPath -Name $Name -ErrorAction SilentlyContinue
            if ($RegProperty -and $RegProperty.PSObject.Properties.Name -contains $Name) {
                $CurrentValue = $RegProperty.$Name
                if ($CurrentValue -eq $ExpectedValue) {
                    $Status = "Applied"
                    $StatusColor = "Green"
                } else {
                    $Status = "Mismatch"
                    $StatusColor = "Red"
                }
            } else {
                $Status = "Key Value Missing"
                $StatusColor = "Yellow"
            }
        } else {
            $Status = "Registry Path Missing"
            $StatusColor = "Red"
        }
    }
    catch {
        $Status = "Error: $($_.Exception.Message)"
        $StatusColor = "Red"
    }

    # Output to console
    Write-Host "STATUS: '$($Description)' ($Name)" -NoNewline
    Write-Host " | Current: '$($CurrentValue)'" -NoNewline
    Write-Host " | Expected: '$ExpectedValue'" -NoNewline
    Write-Host " | Result: $($Status)" -ForegroundColor $StatusColor

    # Create a custom object to return
    [PSCustomObject]@{
        Description    = $Description
        RegistryPath   = $FullKeyPath
        RegistryKeyName= $Name
        ExpectedValue  = $ExpectedValue
        CurrentValue   = $CurrentValue
        Status         = $Status
    }
}

# --- Connected User Experience and Telemetry Service ---
Write-Host "`n--- Configuring Connected User Experience and Telemetry ---" -ForegroundColor Yellow
# 'Configure Authenticated Proxy usage for the Connected User Experience and Telemetry service' is set to 'Enabled: Disable Authenticated Proxy usage'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "DisableEnterpriseAuthProxy" -Value 1 -Type DWORD -Description "Disable Authenticated Proxy for Telemetry"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "DisableEnterpriseAuthProxy" -ExpectedValue 1 -Description "Disable Authenticated Proxy for Telemetry"

# 'Disable OneSettings Downloads' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\OneSettings" -Name "DisableOneSettingsDownloads" -Value 1 -Type DWORD -Description "Disable OneSettings Downloads"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\OneSettings" -Name "DisableOneSettingsDownloads" -ExpectedValue 1 -Description "Disable OneSettings Downloads"

# 'Enable OneSettings Auditing' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\OneSettings" -Name "EnableOneSettingsAuditing" -Value 1 -Type DWORD -Description "Enable OneSettings Auditing"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\OneSettings" -Name "EnableOneSettingsAuditing" -ExpectedValue 1 -Description "Enable OneSettings Auditing"

# 'Limit Diagnostic Log Collection' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "LimitDiagnosticLogCollection" -Value 1 -Type DWORD -Description "Limit Diagnostic Log Collection"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "LimitDiagnosticLogCollection" -ExpectedValue 1 -Description "Limit Diagnostic Log Collection"

# 'Limit Dump Collection' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "LimitDumpCollection" -Value 1 -Type DWORD -Description "Limit Dump Collection"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "LimitDumpCollection" -ExpectedValue 1 -Description "Limit Dump Collection"


# --- App Installer ---
Write-Host "`n--- Configuring App Installer ---" -ForegroundColor Yellow
# 'Enable App Installer' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\AppInstaller" -Name "EnableAppInstaller" -Value 0 -Type DWORD -Description "Enable App Installer"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\AppInstaller" -Name "EnableAppInstaller" -ExpectedValue 0 -Description "Enable App Installer"

# 'Enable App Installer Experimental Features' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\AppInstaller" -Name "EnableExperimentalFeatures" -Value 0 -Type DWORD -Description "Enable App Installer Experimental Features"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\AppInstaller" -Name "EnableExperimentalFeatures" -ExpectedValue 0 -Description "Enable App Installer Experimental Features"

# 'Enable App Installer Hash Override' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\AppInstaller" -Name "EnableHashOverride" -Value 0 -Type DWORD -Description "Enable App Installer Hash Override"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\AppInstaller" -Name "EnableHashOverride" -ExpectedValue 0 -Description "Enable App Installer Hash Override"

# 'Enable App Installer ms-appinstaller protocol' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\AppInstaller" -Name "EnableMSAppInstallerProtocol" -Value 0 -Type DWORD -Description "Enable App Installer ms-appinstaller protocol"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\AppInstaller" -Name "EnableMSAppInstallerProtocol" -ExpectedValue 0 -Description "Enable App Installer ms-appinstaller protocol"


# --- Microsoft Account and Cloud Sync ---
Write-Host "`n--- Configuring Microsoft Account and Cloud Sync ---" -ForegroundColor Yellow
# 'Allow Message Service Cloud Sync' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\CloudMessaging" -Name "AllowMessageSync" -Value 0 -Type DWORD -Description "Allow Message Service Cloud Sync"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\CloudMessaging" -Name "AllowMessageSync" -ExpectedValue 0 -Description "Allow Message Service Cloud Sync"

# 'Block all consumer Microsoft account user authentication' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\Safer" -Name "BlockMSA" -Value 1 -Type DWORD -Description "Block all consumer Microsoft account user authentication"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\Safer" -Name "BlockMSA" -ExpectedValue 1 -Description "Block all consumer Microsoft account user authentication"


# --- Windows Defender / Antivirus ---
Write-Host "`n--- Configuring Windows Defender Antivirus ---" -ForegroundColor Yellow

# 'Configure Attack Surface Reduction rules' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows Defender\Windows Defender Exploit Guard\ASR" -Name "ASRRules_Enabled" -Value 1 -Type DWORD -Description "ASR Rules (Overall Enabled)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows Defender\Windows Defender Exploit Guard\ASR" -Name "ASRRules_Enabled" -ExpectedValue 1 -Description "ASR Rules (Overall Enabled)"

# 'Configure Attack Surface Reduction rules: Set the state for each ASR rule' is configured
# This section needs to be CUSTOMIZED with specific ASR rule GUIDs and their desired state.
# States: 1 (Block), 2 (Audit), 3 (Warn), 0 (Disabled)
# Example GUIDs:
# Block credential stealing from the Windows local security authority (lsass.exe): D4F940AB-401B-4EFC-A04D-4F3472E7B196
# Block process creations originating from PSExec and WMI commands: D1E49AAC-89C4-4A9A-BEED-AD4402127BBA
# For a full list of ASR rules and their GUIDs, refer to Microsoft documentation.
# I'll enable one example rule here. You need to add more as needed.
$ASR_Rule_BlockLsassCredentialStealing_GUID = "D4F940AB-401B-4EFC-A04D-4F3472E7B196"
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows Defender\Windows Defender Exploit Guard\ASR\Rules" -Name $ASR_Rule_BlockLsassCredentialStealing_GUID -Value 1 -Type DWORD -Description "ASR: Block credential stealing from LSASS (Example)" # 1 for Block
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows Defender\Windows Defender Exploit Guard\ASR\Rules" -Name $ASR_Rule_BlockLsassCredentialStealing_GUID -ExpectedValue 1 -Description "ASR: Block credential stealing from LSASS (Example)"


# 'Prevent users and apps from accessing dangerous websites' is set to 'Enabled: Block'
# This is usually Controlled Folder Access or Network Protection.
# This GPO usually refers to Network Protection in Defender SmartScreen
# Value: 1 (Block), 2 (Audit)
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows Defender\Windows Defender Exploit Guard\NetworkProtection" -Name "EnableNetworkProtection" -Value 1 -Type DWORD -Description "Prevent users and apps from accessing dangerous websites (Network Protection)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows Defender\Windows Defender Exploit Guard\NetworkProtection" -Name "EnableNetworkProtection" -ExpectedValue 1 -Description "Prevent users and apps from accessing dangerous websites (Network Protection)"

# 'Enable file hash computation feature' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows Defender" -Name "EnableFileHashComputation" -Value 1 -Type DWORD -Description "Enable file hash computation feature"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows Defender" -Name "EnableFileHashComputation" -ExpectedValue 1 -Description "Enable file hash computation feature"

# 'Scan all downloaded files and attachments' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows Defender\Scan" -Name "DisableArchiveScanning" -Value 0 -Type DWORD -Description "Scan all downloaded files and attachments" # 0 means enabled (do not disable)
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows Defender\Scan" -Name "DisableArchiveScanning" -ExpectedValue 0 -Description "Scan all downloaded files and attachments"

# 'Turn off real-time protection' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" -Name "DisableRealtimeMonitoring" -Value 0 -Type DWORD -Description "Turn off real-time protection" # 0 means enabled (do not disable)
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" -Name "DisableRealtimeMonitoring" -ExpectedValue 0 -Description "Turn off real-time protection"

# 'Turn on script scanning' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" -Name "ScanScripts" -Value 1 -Type DWORD -Description "Turn on script scanning"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" -Name "ScanScripts" -ExpectedValue 1 -Description "Turn on script scanning"

# 'Scan packed executables' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows Defender\Scan" -Name "DisablePackedExeScanning" -Value 0 -Type DWORD -Description "Scan packed executables" # 0 means enabled (do not disable)
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows Defender\Scan" -Name "DisablePackedExeScanning" -ExpectedValue 0 -Description "Scan packed executables"

# 'Configure detection for potentially unwanted applications' is set to 'Enabled: Block'
# 1 for Audit, 2 for Block
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows Defender\PUA Protection" -Name "EnablePUAProtection" -Value 2 -Type DWORD -Description "Configure detection for potentially unwanted applications" # 2 for Block
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows Defender\PUA Protection" -Name "EnablePUAProtection" -ExpectedValue 2 -Description "Configure detection for potentially unwanted applications"


# --- Push To Install Service ---
Write-Host "`n--- Configuring Push To Install Service ---" -ForegroundColor Yellow
# 'Turn off Push To Install service' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\PushToInstall" -Name "DisablePushToInstall" -Value 1 -Type DWORD -Description "Turn off Push To Install service"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\PushToInstall" -Name "DisablePushToInstall" -ExpectedValue 1 -Description "Turn off Push To Install service"


# --- Remote Desktop Services ---
Write-Host "`n--- Configuring Remote Desktop Services ---" -ForegroundColor Yellow
# 'Restrict Remote Desktop Services users to a single Remote Desktop Services session' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name "fSingleSessionPerUser" -Value 1 -Type DWORD -Description "Restrict RDP users to a single session"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name "fSingleSessionPerUser" -ExpectedValue 1 -Description "Restrict RDP users to a single session"

# 'Require use of specific security layer for remote (RDP) connections' is set to 'Enabled: SSL'
# 0 = Negotiate, 1 = RDP Security Layer, 2 = SSL (TLS 1.0)
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name "SecurityLayer" -Value 2 -Type DWORD -Description "RDP Security Layer (SSL)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name "SecurityLayer" -ExpectedValue 2 -Description "RDP Security Layer (SSL)"

# 'Require user authentication for remote connections by using Network Level Authentication' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name "UserAuthentication" -Value 1 -Type DWORD -Description "RDP Network Level Authentication"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name "UserAuthentication" -ExpectedValue 1 -Description "RDP Network Level Authentication"

# 'Set time limit for disconnected sessions' is set to 'Enabled: 1 minute'
# Value in milliseconds (1 minute = 60000 ms)
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name "DisconnectedSessionTimer" -Value 60000 -Type DWORD -Description "RDP Time limit for disconnected sessions (ms)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name "DisconnectedSessionTimer" -ExpectedValue 60000 -Description "RDP Time limit for disconnected sessions (ms)"


# --- Search and UI Elements ---
Write-Host "`n--- Configuring Search and UI Elements ---" -ForegroundColor Yellow
# 'Allow search highlights' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "DisableSearchHighlights" -Value 1 -Type DWORD -Description "Allow search highlights"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "DisableSearchHighlights" -ExpectedValue 1 -Description "Allow search highlights"

# 'Configure Windows Defender SmartScreen' is set to 'Enabled: Warn and prevent bypass'
# 0 = Off, 1 = Warn, 2 = Warn and prevent bypass, 3 = Warn (User can override)
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "EnableSmartScreen" -Value 2 -Type DWORD -Description "Configure Windows Defender SmartScreen" # 2 for Warn and prevent bypass
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "EnableSmartScreen" -ExpectedValue 2 -Description "Configure Windows Defender SmartScreen"

# 'Allow Windows Ink Workspace' is set to 'Enabled: Disabled'
# 0 = Disabled, 1 = On, 2 = On, but disallow access above lock
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\WindowsInkWorkspace" -Name "AllowInkWorkspace" -Value 0 -Type DWORD -Description "Allow Windows Ink Workspace" # Setting to Disabled
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\WindowsInkWorkspace" -Name "AllowInkWorkspace" -ExpectedValue 0 -Description "Allow Windows Ink Workspace"


# --- PowerShell Logging ---
Write-Host "`n--- Configuring PowerShell Logging ---" -ForegroundColor Yellow
# 'Turn on PowerShell Script Block Logging' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging" -Name "EnableScriptBlockLogging" -Value 1 -Type DWORD -Description "Turn on PowerShell Script Block Logging"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging" -Name "EnableScriptBlockLogging" -ExpectedValue 1 -Description "Turn on PowerShell Script Block Logging"

# 'Turn on PowerShell Transcription' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription" -Name "EnableTranscription" -Value 1 -Type DWORD -Description "Turn on PowerShell Transcription"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription" -Name "EnableTranscription" -ExpectedValue 1 -Description "Turn on PowerShell Transcription"


# --- Windows Update Settings ---
Write-Host "`n--- Configuring Windows Update ---" -ForegroundColor Yellow
# 'Prevent users from modifying settings' is set to 'Enabled'
# This policy is part of Windows Update settings
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" -Name "DisableWUAccess" -Value 1 -Type DWORD -Description "Prevent users from modifying Windows Update settings"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" -Name "DisableWUAccess" -ExpectedValue 1 -Description "Prevent users from modifying Windows Update settings"

# 'No auto-restart with logged on users for scheduled automatic updates installations' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "NoAutoRebootWithLoggedOnUsers" -Value 0 -Type DWORD -Description "No auto-restart with logged on users" # 0 for Disabled
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "NoAutoRebootWithLoggedOnUsers" -ExpectedValue 0 -Description "No auto-restart with logged on users"

# 'Manage preview builds' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\UX\Settings" -Name "DisablePreviewBuilds" -Value 1 -Type DWORD -Description "Manage preview builds"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\UX\Settings" -Name "DisablePreviewBuilds" -ExpectedValue 1 -Description "Manage preview builds"

# 'Select when Quality Updates are received' is set to 'Enabled: 0 days'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "DeferQualityUpdatesPeriodInDays" -Value 0 -Type DWORD -Description "Select when Quality Updates are received (Days)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "DeferQualityUpdatesPeriodInDays" -ExpectedValue 0 -Description "Select when Quality Updates are received (Days)"


# --- Privacy and Diagnostics ---
Write-Host "`n--- Configuring Privacy and Diagnostics ---" -ForegroundColor Yellow
# 'Turn off toast notifications on the lock screen' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Notifications\Settings" -Name "DisableNotificationsOnLockScreen" -Value 1 -Type DWORD -Description "Turn off toast notifications on the lock screen"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Notifications\Settings" -Name "DisableNotificationsOnLockScreen" -ExpectedValue 1 -Description "Turn off toast notifications on the lock screen"

# 'Do not use diagnostic data for tailored experiences' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "DisableTailoredExperiencesWithDiagnosticData" -Value 1 -Type DWORD -Description "Do not use diagnostic data for tailored experiences"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "DisableTailoredExperiencesWithDiagnosticData" -ExpectedValue 1 -Description "Do not use diagnostic data for tailored experiences"

# 'Turn off Spotlight collection on Desktop' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Name "DisableSpotlightCollectionOnDesktop" -Value 1 -Type DWORD -Description "Turn off Spotlight collection on Desktop"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Name "DisableSpotlightCollectionOnDesktop" -ExpectedValue 1 -Description "Turn off Spotlight collection on Desktop"


# --- MSI Installer ---
Write-Host "`n--- Configuring MSI Installer ---" -ForegroundColor Yellow
# 'Always install with elevated privileges' is set to 'Disabled'
# This is a critical security setting. 0 for Disabled is the secure default.
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\Installer" -Name "AlwaysInstallElevated" -Value 0 -Type DWORD -Description "Always install with elevated privileges"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\Installer" -Name "AlwaysInstallElevated" -ExpectedValue 0 -Description "Always install with elevated privileges"


Write-Host "`n--- Policy Application Summary ---" -ForegroundColor Green
Write-Host "All specified policies have been applied (or attempted) to the registry." -ForegroundColor Green
Write-Host "Please review the 'STATUS' lines above to verify current registry values." -ForegroundColor Green
Write-Host "For some policies, a 'gpupdate /force' and/or system reboot may be required for full effect." -ForegroundColor Green


# --- Exporting Status Report ---
$ReportFilePath = "$env:TEMP\GPO_General_Security_Report_$(Get-Date -Format 'yyyyMMdd_HHmmss')"

Write-Host "`n--- Exporting GPO Status Report ---" -ForegroundColor Yellow

# Export to CSV (Recommended for easy viewing in Excel)
$CSVPath = $ReportFilePath + ".csv"
try {
    $GPOStatusReport | Export-Csv -Path $CSVPath -NoTypeInformation -Encoding UTF8
    Write-Host "GPO status report exported to CSV: $CSVPath" -ForegroundColor Green
}
catch {
    Write-Error "Failed to export CSV report: $($_.Exception.Message)"
}

# Export to XML (Uncomment the following lines if you prefer XML)
# $XMLPath = $ReportFilePath + ".xml"
# try {
#     $GPOStatusReport | Export-Clixml -Path $XMLPath
#     Write-Host "GPO status report exported to XML: $XMLPath" -ForegroundColor Green
# }
# catch {
#     Write-Error "Failed to export XML report: $($_.Exception.Message)"
# }

Write-Host "`nScript execution complete." -ForegroundColor Green