﻿# Requires Administrator privileges to run

Write-Host "Applying Local Group Policies..." -ForegroundColor Green

# Array to store the status of each GPO for export
$GPOStatusReport = @()

# Function to set a registry value, creating the path if it doesn't exist
function Set-GPOption {
    Param(
        [Parameter(Mandatory=$true)]
        [string]$Path,
        [Parameter(Mandatory=$true)]
        [string]$Name,
        [Parameter(Mandatory=$true)]
        $Value,
        [Parameter(Mandatory=$true)]
        [string]$Type,
        [Parameter(Mandatory=$false)]
        [string]$Description = "" # Optional description for status output
    )
    $FullKeyPath = "HKLM:\" + $Path
    try {
        if (-not (Test-Path $FullKeyPath)) {
            New-Item -Path $FullKeyPath -Force | Out-Null
            Write-Host "Created Registry Path: $FullKeyPath" -ForegroundColor DarkGray
        }
        Set-ItemProperty -Path $FullKeyPath -Name $Name -Value $Value -Type $Type -Force
        Write-Host "SET: '$($Description)' ($Name) to Value '$Value' in '$Path'" -ForegroundColor Cyan
    }
    catch {
        Write-Error "Failed to set policy '$Name'. Error: $($_.Exception.Message)"
    }
}

# Function to get and return the status of a registry-based GPO as an object
function Get-GPOptionStatus {
    Param(
        [Parameter(Mandatory=$true)]
        [string]$Path,
        [Parameter(Mandatory=$true)]
        [string]$Name,
        [Parameter(Mandatory=$true)]
        $ExpectedValue,
        [Parameter(Mandatory=$true)]
        [string]$Description
    )
    $FullKeyPath = "HKLM:\" + $Path
    $CurrentValue = $null
    $Status = "Not Found" # Default status
    $StatusColor = "Yellow"

    try {
        if (Test-Path $FullKeyPath) {
            $RegProperty = Get-ItemProperty -Path $FullKeyPath -Name $Name -ErrorAction SilentlyContinue
            if ($RegProperty -and $RegProperty.PSObject.Properties.Name -contains $Name) {
                $CurrentValue = $RegProperty.$Name
                if ($CurrentValue -eq $ExpectedValue) {
                    $Status = "Applied"
                    $StatusColor = "Green"
                } else {
                    $Status = "Mismatch"
                    $StatusColor = "Red"
                }
            } else {
                $Status = "Key Value Missing"
                $StatusColor = "Yellow"
            }
        } else {
            $Status = "Registry Path Missing"
            $StatusColor = "Red"
        }
    }
    catch {
        $Status = "Error: $($_.Exception.Message)"
        $StatusColor = "Red"
    }

    # Output to console
    Write-Host "STATUS: '$($Description)' ($Name)" -NoNewline
    Write-Host " | Current: '$($CurrentValue)'" -NoNewline
    Write-Host " | Expected: '$ExpectedValue'" -NoNewline
    Write-Host " | Result: $($Status)" -ForegroundColor $StatusColor

    # Create a custom object to return
    [PSCustomObject]@{
        Description    = $Description
        RegistryPath   = $FullKeyPath
        RegistryKeyName= $Name
        ExpectedValue  = $ExpectedValue
        CurrentValue   = $CurrentValue
        Status         = $Status
    }
}

# --- Speech and Online Services ---
Write-Host "`n--- Configuring Speech and Online Services ---" -ForegroundColor Yellow
# 'Allow users to enable online speech recognition services' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\InputPersonalization" -Name "AllowOnlineSpeech" -Value 0 -Type DWORD -Description "Allow online speech recognition services"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\InputPersonalization" -Name "AllowOnlineSpeech" -ExpectedValue 0 -Description "Allow online speech recognition services"

# 'Allow Online Tips' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Name "DisableOnlineTips" -Value 1 -Type DWORD -Description "Allow Online Tips"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Name "DisableOnlineTips" -ExpectedValue 1 -Description "Allow Online Tips"


# --- User Account Control (UAC) ---
Write-Host "`n--- Configuring User Account Control (UAC) ---" -ForegroundColor Yellow
# 'Apply UAC restrictions to local accounts on network logons' is set to 'Enabled'
# This setting is typically named FilterAdministratorToken and is under System
Set-GPOption -Path "SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "FilterAdministratorToken" -Value 1 -Type DWORD -Description "Apply UAC restrictions to local accounts on network logons"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "FilterAdministratorToken" -ExpectedValue 1 -Description "Apply UAC restrictions to local accounts on network logons"


# --- RPC Configuration ---
Write-Host "`n--- Configuring RPC ---" -ForegroundColor Yellow
# 'Configure RPC packet level privacy setting for incoming connections' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\RPC" -Name "EnablePacketPrivacy" -Value 1 -Type DWORD -Description "RPC packet level privacy setting for incoming connections"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\RPC" -Name "EnablePacketPrivacy" -ExpectedValue 1 -Description "RPC packet level privacy setting for incoming connections"

# 'Configure RPC connection settings: Protocol to use for outgoing RPC connections' is set to 'Enabled: RPC over TCP'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\RPC\ClientProtocols" -Name "DefaultProtocol" -Value "ncacn_ip_tcp" -Type String -Description "RPC outgoing connections: Protocol (TCP)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\RPC\ClientProtocols" -Name "DefaultProtocol" -ExpectedValue "ncacn_ip_tcp" -Description "RPC outgoing connections: Protocol (TCP)"

# 'Configure RPC connection settings: Use authentication for outgoing RPC connections' is set to 'Enabled: Default'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\RPC\ClientProtocols" -Name "UseAuthentication" -Value 1 -Type DWORD -Description "RPC outgoing connections: Use authentication" # 1 for Default
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\RPC\ClientProtocols" -Name "UseAuthentication" -ExpectedValue 1 -Description "RPC outgoing connections: Use authentication"

# 'Configure RPC listener settings: Protocols to allow for incoming RPC connections' is set to 'Enabled: RPC over TCP'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\RPC\ServerProtocols" -Name "DefaultProtocol" -Value "ncacn_ip_tcp" -Type String -Description "RPC incoming connections: Protocol (TCP)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\RPC\ServerProtocols" -Name "DefaultProtocol" -ExpectedValue "ncacn_ip_tcp" -Description "RPC incoming connections: Protocol (TCP)"

# 'Configure RPC listener settings: Authentication protocol to use for incoming RPC connections:' is set to 'Enabled: Negotiate' or higher"
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\RPC\ServerProtocols" -Name "AuthenticationProtocol" -Value 2 -Type DWORD -Description "RPC incoming connections: Authentication (Negotiate)" # 2 for Negotiate
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\RPC\ServerProtocols" -Name "AuthenticationProtocol" -ExpectedValue 2 -Description "RPC incoming connections: Authentication (Negotiate)"


# --- SMB Configuration ---
Write-Host "`n--- Configuring SMB ---" -ForegroundColor Yellow
# 'Configure SMB v1 client driver' is set to 'Enabled: Disable driver (recommended)'
Set-GPOption -Path "SYSTEM\CurrentControlSet\Services\mrxsmb10" -Name "Start" -Value 4 -Type DWORD -Description "SMB v1 client driver (Disable)" # 4 for Disabled
$GPOStatusReport += Get-GPOptionStatus -Path "SYSTEM\CurrentControlSet\Services\mrxsmb10" -Name "Start" -ExpectedValue 4 -Description "SMB v1 client driver (Disable)"

# 'Configure SMB v1 server' is set to 'Disabled'
Set-GPOption -Path "SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "Smb1" -Value 0 -Type DWORD -Description "SMB v1 server" # 0 for Disabled
$GPOStatusReport += Get-GPOptionStatus -Path "SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "Smb1" -ExpectedValue 0 -Description "SMB v1 server"


# --- Certificate Security ---
Write-Host "`n--- Configuring Certificate Security ---" -ForegroundColor Yellow
# 'Enable Certificate Padding' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Cryptography\Certificates" -Name "EnableCertPadding" -Value 1 -Type DWORD -Description "Enable Certificate Padding"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Cryptography\Certificates" -Name "EnableCertPadding" -ExpectedValue 1 -Description "Enable Certificate Padding"


# --- LSA Protection ---
Write-Host "`n--- Configuring LSA Protection ---" -ForegroundColor Yellow
# 'LSA Protection' is set to 'Enabled'
# This is usually configured via Device Guard settings or Credential Guard.
# Registry path: HKLM:\SYSTEM\CurrentControlSet\Control\Lsa
# Value Name: RunAsPPL (DWORD)
# Value Data: 1
Set-GPOption -Path "SYSTEM\CurrentControlSet\Control\Lsa" -Name "RunAsPPL" -Value 1 -Type DWORD -Description "LSA Protection"
$GPOStatusReport += Get-GPOptionStatus -Path "SYSTEM\CurrentControlSet\Control\Lsa" -Name "RunAsPPL" -ExpectedValue 1 -Description "LSA Protection"


# --- NetBT and Name Resolution ---
Write-Host "`n--- Configuring NetBT and Name Resolution ---" -ForegroundColor Yellow
# 'NetBT NodeType configuration' is set to 'Enabled: P-node (recommended)'
Set-GPOption -Path "SYSTEM\CurrentControlSet\Services\NetBT\Parameters" -Name "NodeType" -Value 2 -Type DWORD -Description "NetBT NodeType (P-node)" # 2 for P-node
$GPOStatusReport += Get-GPOptionStatus -Path "SYSTEM\CurrentControlSet\Services\NetBT\Parameters" -Name "NodeType" -ExpectedValue 2 -Description "NetBT NodeType (P-node)"

# 'MSS: (PerformRouterDiscovery) Allow IRDP to detect and configure Default Gateway addresses' is set to 'Disabled'
Set-GPOption -Path "SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name "PerformRouterDiscovery" -Value 0 -Type DWORD -Description "MSS: PerformRouterDiscovery"
$GPOStatusReport += Get-GPOptionStatus -Path "SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name "PerformRouterDiscovery" -ExpectedValue 0 -Description "MSS: PerformRouterDiscovery"

# 'MSS: (SafeDllSearchMode) Enable Safe DLL search mode' is set to 'Enabled'
Set-GPOption -Path "SYSTEM\CurrentControlSet\Control\Session Manager\SafeDllSearchMode" -Name "SafeDllSearchMode" -Value 1 -Type DWORD -Description "MSS: SafeDllSearchMode"
$GPOStatusReport += Get-GPOptionStatus -Path "SYSTEM\CurrentControlSet\Control\Session Manager\SafeDllSearchMode" -Name "SafeDllSearchMode" -ExpectedValue 1 -Description "MSS: SafeDllSearchMode"

# 'Configure NetBIOS settings' is set to 'Enabled: Disable NetBIOS name resolution on public networks'
# This setting is part of the 'Interface' subkeys for each network adapter.
# This GPO usually creates a specific subkey and sets a value like 1 for "Disable NetBIOS over TCP/IP" or similar.
# For simplicity, this script targets the general "NetbiosOptions" key, but real GPO applies per adapter if managed.
# This might require per-adapter configuration which is more complex than a single global key.
# A more direct control might be within DHCP options, but for local policy, this is generally the path.
# Setting it to 2 disables it for public networks only.
Set-GPOption -Path "SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces" -Name "NetbiosOptions" -Value 2 -Type DWORD -Description "NetBIOS name resolution on public networks"
$GPOStatusReport += Get-GPOptionStatus -Path "SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces" -Name "NetbiosOptions" -ExpectedValue 2 -Description "NetBIOS name resolution on public networks"


# 'Turn off multicast name resolution' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" -Name "EnableMulticast" -Value 0 -Type DWORD -Description "Turn off multicast name resolution" # 0 to disable (turn off)
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" -Name "EnableMulticast" -ExpectedValue 0 -Description "Turn off multicast name resolution"


# --- Authentication and Security ---
Write-Host "`n--- Configuring Authentication and Security ---" -ForegroundColor Yellow
# 'WDigest Authentication' is set to 'Disabled'
Set-GPOption -Path "SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest" -Name "UseLogonCredential" -Value 0 -Type DWORD -Description "WDigest Authentication" # 0 to disable
$GPOStatusReport += Get-GPOptionStatus -Path "SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest" -Name "UseLogonCredential" -ExpectedValue 0 -Description "WDigest Authentication"


# 'Hardened UNC Paths' is set to 'Enabled, with Require Mutual Authentication, Require Integrity, and Require Privacy set for all NETLOGON and SYSVOL shares'
# This is a complex GPO with multiple sub-keys for each path.
# First, enable the overall policy.
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" -Name "EnableHardenedPaths" -Value 1 -Type DWORD -Description "Hardened UNC Paths (Overall)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" -Name "EnableHardenedPaths" -ExpectedValue 1 -Description "Hardened UNC Paths (Overall)"

# Then, configure the specific paths. The value name is the UNC path. The value is a combination of flags.
# Value: 1 (Require Mutual Authentication) + 2 (Require Integrity) + 4 (Require Privacy) = 7
# For NETLOGON share
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" -Name "\\*\NETLOGON" -Value 7 -Type DWORD -Description "Hardened UNC Paths (NETLOGON)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" -Name "\\*\NETLOGON" -ExpectedValue 7 -Description "Hardened UNC Paths (NETLOGON)"

# For SYSVOL share
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" -Name "\\*\SYSVOL" -Value 7 -Type DWORD -Description "Hardened UNC Paths (SYSVOL)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" -Name "\\*\SYSVOL" -ExpectedValue 7 -Description "Hardened UNC Paths (SYSVOL)"


# --- IPv6 Configuration ---
Write-Host "`n--- Configuring IPv6 ---" -ForegroundColor Yellow
# 'Disable IPv6 (Ensure TCPIP6 Parameter 'DisabledComponents' is set to '0xff (255)')'
Set-GPOption -Path "SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" -Name "DisabledComponents" -Value 255 -Type DWORD -Description "Disable IPv6"
$GPOStatusReport += Get-GPOptionStatus -Path "SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" -Name "DisabledComponents" -ExpectedValue 255 -Description "Disable IPv6"


# --- Network Connections ---
Write-Host "`n--- Configuring Network Connections ---" -ForegroundColor Yellow
# 'Minimize the number of simultaneous connections to the Internet or a Windows Domain' is set to 'Enabled: 3 = Prevent Wi-Fi when on Ethernet'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\WcmSvc\GroupPolicy" -Name "fMinimizeConnections" -Value 3 -Type DWORD -Description "Minimize simultaneous connections (Wi-Fi on Ethernet)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\WcmSvc\GroupPolicy" -Name "fMinimizeConnections" -ExpectedValue 3 -Description "Minimize simultaneous connections (Wi-Fi on Ethernet)"


# --- Print Spooler ---
Write-Host "`n--- Configuring Print Spooler ---" -ForegroundColor Yellow
# 'Allow Print Spooler to accept client connections' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows NT\Printers" -Name "RpcUseRpcRouter" -Value 0 -Type DWORD -Description "Allow Print Spooler to accept client connections"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows NT\Printers" -Name "RpcUseRpcRouter" -ExpectedValue 0 -Description "Allow Print Spooler to accept client connections"


# --- Redirection Guard ---
Write-Host "`n--- Configuring Redirection Guard ---" -ForegroundColor Yellow
# 'Configure Redirection Guard' is set to 'Enabled: Redirection Guard Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\RedirectionGuard" -Name "EnableRedirectionGuard" -Value 1 -Type DWORD -Description "Configure Redirection Guard"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\RedirectionGuard" -Name "EnableRedirectionGuard" -ExpectedValue 1 -Description "Configure Redirection Guard"


Write-Host "`n--- Policy Application Summary ---" -ForegroundColor Green
Write-Host "All specified policies have been applied (or attempted) to the registry." -ForegroundColor Green
Write-Host "Please review the 'STATUS' lines above to verify current registry values." -ForegroundColor Green
Write-Host "For some policies, a 'gpupdate /force' and/or system reboot may be required for full effect." -ForegroundColor Green


# --- Exporting Status Report ---
$ReportFilePath = "$env:TEMP\GPO_Status_Report_$(Get-Date -Format 'yyyyMMdd_HHmmss')"

Write-Host "`n--- Exporting GPO Status Report ---" -ForegroundColor Yellow

# Export to CSV (Recommended for easy viewing in Excel)
$CSVPath = $ReportFilePath + ".csv"
try {
    $GPOStatusReport | Export-Csv -Path $CSVPath -NoTypeInformation -Encoding UTF8
    Write-Host "GPO status report exported to CSV: $CSVPath" -ForegroundColor Green
}
catch {
    Write-Error "Failed to export CSV report: $($_.Exception.Message)"
}

# Export to XML (Uncomment the following lines if you prefer XML)
# $XMLPath = $ReportFilePath + ".xml"
# try {
#     $GPOStatusReport | Export-Clixml -Path $XMLPath
#     Write-Host "GPO status report exported to XML: $XMLPath" -ForegroundColor Green
# }
# catch {
#     Write-Error "Failed to export XML report: $($_.Exception.Message)"
# }

Write-Host "`nScript execution complete." -ForegroundColor Green