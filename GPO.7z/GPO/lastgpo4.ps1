﻿# Requires Administrator privileges to run

Write-Host "Applying Local Group Policies..." -ForegroundColor Green

# Array to store the status of each GPO for export
$GPOStatusReport = @()

# Function to set a registry value, creating the path if it doesn't exist
function Set-GPOption {
    Param(
        [Parameter(Mandatory=$true)]
        [string]$Path,
        [Parameter(Mandatory=$true)]
        [string]$Name,
        [Parameter(Mandatory=$true)]
        $Value,
        [Parameter(Mandatory=$true)]
        [string]$Type,
        [Parameter(Mandatory=$false)]
        [string]$Description = "" # Optional description for status output
    )
    $FullKeyPath = "HKLM:\" + $Path
    try {
        if (-not (Test-Path $FullKeyPath)) {
            New-Item -Path $FullKeyPath -Force | Out-Null
            Write-Host "Created Registry Path: $FullKeyPath" -ForegroundColor DarkGray
        }
        Set-ItemProperty -Path $FullKeyPath -Name $Name -Value $Value -Type $Type -Force
        Write-Host "SET: '$($Description)' ($Name) to Value '$Value' in '$Path'" -ForegroundColor Cyan
    }
    catch {
        Write-Error "Failed to set policy '$Name'. Error: $($_.Exception.Message)"
    }
}

# Function to get and return the status of a registry-based GPO as an object
function Get-GPOptionStatus {
    Param(
        [Parameter(Mandatory=$true)]
        [string]$Path,
        [Parameter(Mandatory=$true)]
        [string]$Name,
        [Parameter(Mandatory=$true)]
        $ExpectedValue,
        [Parameter(Mandatory=$true)]
        [string]$Description
    )
    $FullKeyPath = "HKLM:\" + $Path
    $CurrentValue = $null
    $Status = "Not Found" # Default status
    $StatusColor = "Yellow"

    try {
        if (Test-Path $FullKeyPath) {
            $RegProperty = Get-ItemProperty -Path $FullKeyPath -Name $Name -ErrorAction SilentlyContinue
            if ($RegProperty -and $RegProperty.PSObject.Properties.Name -contains $Name) {
                $CurrentValue = $RegProperty.$Name
                if ($CurrentValue -eq $ExpectedValue) {
                    $Status = "Applied"
                    $StatusColor = "Green"
                } else {
                    $Status = "Mismatch"
                    $StatusColor = "Red"
                }
            } else {
                $Status = "Key Value Missing"
                $StatusColor = "Yellow"
            }
        } else {
            $Status = "Registry Path Missing"
            $StatusColor = "Red"
        }
    }
    catch {
        $Status = "Error: $($_.Exception.Message)"
        $StatusColor = "Red"
    }

    # Output to console
    Write-Host "STATUS: '$($Description)' ($Name)" -NoNewline
    Write-Host " | Current: '$($CurrentValue)'" -NoNewline
    Write-Host " | Expected: '$ExpectedValue'" -NoNewline
    Write-Host " | Result: $($Status)" -ForegroundColor $StatusColor

    # Create a custom object to return
    [PSCustomObject]@{
        Description    = $Description
        RegistryPath   = $FullKeyPath
        RegistryKeyName= $Name
        ExpectedValue  = $ExpectedValue
        CurrentValue   = $CurrentValue
        Status         = $Status
    }
}

# --- Account Policies ---
Write-Host "`n--- Configuring Account Policies ---" -ForegroundColor Yellow

# 'Allow Administrator account lockout' is set to 'Enabled'
# This is typically configured in the Security Policy Snap-in (secpol.msc)
# and influences the effective 'Account lockout threshold' policy.
# Direct registry modification is complex as it's part of LSA policy store.
# For simplicity and common implementation, if this was a separate registry key.
# However, this policy is often tied to the "Account lockout threshold" setting in the local security policy.
# The registry setting below, if present, is usually for setting specific thresholds, not just "Allow lockout".
# The actual enforcement of "Allow Administrator account lockout" means the Account lockout threshold is set to a non-zero value.
# I'll include a placeholder that might correlate, but acknowledge it's not a direct 1:1 registry key.
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "EnableAdminLockout" -Value 1 -Type DWORD -Description "Allow Administrator account lockout (Placeholder)"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "EnableAdminLockout" -ExpectedValue 1 -Description "Allow Administrator account lockout (Placeholder)"


# --- User Rights Assignment ---
Write-Host "`n--- Configuring User Rights Assignment ---" -ForegroundColor Yellow
# User Rights Assignment policies are best configured using secedit.exe or Local Security Policy MMC.
# Directly manipulating the registry for these is complex and risky as it involves SIDs in binary format.
# The paths below are illustrative of where these might *appear* after a GPO is applied by the system,
# but direct modification via Set-ItemProperty is not the standard or safest approach.
# For these policies, you would typically define them in a .inf file and import with secedit.
# Example for "Access this computer from the network" (SeNetworkLogonRight):
# LSA_Rights path: HKLM:\SECURITY\Policy\Accounts\S-1-5-32-544\ActSysAuditInfo
# The value is a binary SID list.
# For demonstration, I will use symbolic registry paths if available for simple policies.
# For complex ones, I'll indicate a programmatic approach isn't straightforward.

# 'Access this computer from the network' is set to 'Administrators, Authenticated Users'
# This is typically handled by 'SeNetworkLogonRight' in LSA. No direct DWORD in policies.
# A more robust way to set this via PowerShell is with the NTAccount class and LSA functions (more advanced).
# Example: Setting to specific groups involves complex SID conversions and LSA functions.
# Due to complexity of setting user rights via direct registry modification: SKIPPING direct registry.
# This would require using LSA APIs or secpol.msc/secedit.

# 'Allow log on locally' is set to 'Administrators'
# Similar to above, typically handled by 'SeInteractiveLogonRight' in LSA. SKIPPING.

# 'Back up files and directories' is set to 'Administrators'
# Similar to above, 'SeBackupPrivilege'. SKIPPING.

# 'Change the time zone' is set to 'Administrators, LOCAL SERVICE'
# Similar to above, 'SeTimeZonePrivilege'. SKIPPING.

# 'Debug programs' is set to 'Administrators'
# Similar to above, 'SeDebugPrivilege'. SKIPPING.

# 'Deny access to this computer from the network' to include 'Guests, Local account and member of Administrators group'
# Similar to above, 'SeDenyNetworkLogonRight'. SKIPPING.

# 'Manage auditing and security log' is set to 'Administrators'
# Similar to above, 'SeSecurityPrivilege'. SKIPPING.


# --- Interactive Logon Settings ---
Write-Host "`n--- Configuring Interactive Logon ---" -ForegroundColor Yellow
# 'Interactive logon: Don't display last signed-in' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "DontDisplayLastUserName" -Value 1 -Type DWORD -Description "Interactive logon: Don't display last signed-in"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "DontDisplayLastUserName" -ExpectedValue 1 -Description "Interactive logon: Don't display last signed-in"

# 'Interactive logon: Require Domain Controller Authentication to unlock workstation' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "ScForceOption" -Value 1 -Type DWORD -Description "Interactive logon: Require DC Auth to unlock workstation"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "ScForceOption" -ExpectedValue 1 -Description "Interactive logon: Require DC Auth to unlock workstation"


# --- Microsoft Network Server Settings ---
Write-Host "`n--- Configuring Microsoft Network Server ---" -ForegroundColor Yellow
# 'Microsoft network server: Amount of idle time required before suspending session' is set to '15 or fewer minute(s)'
# Value in seconds
Set-GPOption -Path "SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "AutoDisconnect" -Value (15 * 60) -Type DWORD -Description "MS Network Server: Idle time before suspending session (seconds)"
$GPOStatusReport += Get-GPOptionStatus -Path "SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "AutoDisconnect" -ExpectedValue (15 * 60) -Description "MS Network Server: Idle time before suspending session (seconds)"

# 'Microsoft network server: Server SPN target name validation level' is set to 'Accept if provided by client' or higher
# 0 = Off, 1 = Accept if provided by client, 2 = Accept and validate
Set-GPOption -Path "SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "SmbServerNameHardeningLevel" -Value 1 -Type DWORD -Description "MS Network Server: SPN target name validation level"
$GPOStatusReport += Get-GPOptionStatus -Path "SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "SmbServerNameHardeningLevel" -ExpectedValue 1 -Description "MS Network Server: SPN target name validation level"


# --- Network Access Settings ---
Write-Host "`n--- Configuring Network Access ---" -ForegroundColor Yellow
# 'Network access: Do not allow storage of passwords and credentials for network authentication' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "DisableCachingOfCredentials" -Value 1 -Type DWORD -Description "Network access: Do not allow storage of passwords and credentials"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "DisableCachingOfCredentials" -ExpectedValue 1 -Description "Network access: Do not allow storage of passwords and credentials"


# --- Network Security Settings ---
Write-Host "`n--- Configuring Network Security ---" -ForegroundColor Yellow
# 'Network Security: Allow PKU2U authentication requests to this computer to use online identities' is set to 'Disabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\NetworkSecurity" -Name "AllowPku2uOnlineIdentities" -Value 0 -Type DWORD -Description "Network Security: Allow PKU2U authentication requests to use online identities"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\NetworkSecurity" -Name "AllowPku2uOnlineIdentities" -ExpectedValue 0 -Description "Network Security: Allow PKU2U authentication requests to use online identities"

# 'Network security: Force logoff when logon hours expire' is set to 'Enabled'
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "ForceLogoffWhenLogonHoursExpire" -Value 1 -Type DWORD -Description "Network security: Force logoff when logon hours expire"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\System" -Name "ForceLogoffWhenLogonHoursExpire" -ExpectedValue 1 -Description "Network security: Force logoff when logon hours expire"

# 'Network security: Restrict NTLM: Audit Incoming NTLM Traffic' is set to 'Enable auditing for all accounts'
# 0 = Disable, 1 = Enable auditing for domain accounts, 2 = Enable auditing for all accounts
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\LSA" -Name "RestrictAuditIncomingNTLM" -Value 2 -Type DWORD -Description "Network security: Restrict NTLM: Audit Incoming NTLM Traffic"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\LSA" -Name "RestrictAuditIncomingNTLM" -ExpectedValue 2 -Description "Network security: Restrict NTLM: Audit Incoming NTLM Traffic"

# 'Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers' is set to 'Audit all' or higher
# 0 = Allow all, 1 = Audit all, 2 = Deny all
Set-GPOption -Path "SOFTWARE\Policies\Microsoft\Windows\LSA" -Name "RestrictOutgoingNTLMTraffic" -Value 1 -Type DWORD -Description "Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers"
$GPOStatusReport += Get-GPOptionStatus -Path "SOFTWARE\Policies\Microsoft\Windows\LSA" -Name "RestrictOutgoingNTLMTraffic" -ExpectedValue 1 -Description "Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers"


# --- Services Configuration ---
Write-Host "`n--- Configuring Services ---" -ForegroundColor Yellow
# 'Print Spooler (Spooler)' is set to 'Disabled'
# Stopping and disabling a service is done via Service Control Manager, not directly registry policy for GPO.
# However, the GPO equivalent often translates to setting the Start type to Disabled (4).
Set-GPOption -Path "SYSTEM\CurrentControlSet\Services\Spooler" -Name "Start" -Value 4 -Type DWORD -Description "Print Spooler Service" # 4 for Disabled
$GPOStatusReport += Get-GPOptionStatus -Path "SYSTEM\CurrentControlSet\Services\Spooler" -Name "Start" -ExpectedValue 4 -Description "Print Spooler Service"

# Additionally, you might want to stop the service immediately:
try {
    Stop-Service -Name "Spooler" -Force -ErrorAction SilentlyContinue
    Write-Host "Action: Stopped Print Spooler service." -ForegroundColor DarkYellow
}
catch {
    Write-Error "Failed to stop Print Spooler service: $($_.Exception.Message)"
}


Write-Host "`n--- Policy Application Summary ---" -ForegroundColor Green
Write-Host "All specified policies have been applied (or attempted) to the registry." -ForegroundColor Green
Write-Host "Please review the 'STATUS' lines above to verify current registry values." -ForegroundColor Green
Write-Host "For some policies, a 'gpupdate /force' and/or system reboot may be required for full effect." -ForegroundColor Green


# --- Exporting Status Report ---
$ReportFilePath = "$env:TEMP\GPO_Account_Security_Status_Report_$(Get-Date -Format 'yyyyMMdd_HHmmss')"

Write-Host "`n--- Exporting GPO Status Report ---" -ForegroundColor Yellow

# Export to CSV (Recommended for easy viewing in Excel)
$CSVPath = $ReportFilePath + ".csv"
try {
    $GPOStatusReport | Export-Csv -Path $CSVPath -NoTypeInformation -Encoding UTF8
    Write-Host "GPO status report exported to CSV: $CSVPath" -ForegroundColor Green
}
catch {
    Write-Error "Failed to export CSV report: $($_.Exception.Message)"
}

# Export to XML (Uncomment the following lines if you prefer XML)
# $XMLPath = $ReportFilePath + ".xml"
# try {
#     $GPOStatusReport | Export-Clixml -Path $XMLPath
#     Write-Host "GPO status report exported to XML: $XMLPath" -ForegroundColor Green
# }
# catch {
#     Write-Error "Failed to export XML report: $($_.Exception.Message)"
# }

Write-Host "`nScript execution complete." -ForegroundColor Green