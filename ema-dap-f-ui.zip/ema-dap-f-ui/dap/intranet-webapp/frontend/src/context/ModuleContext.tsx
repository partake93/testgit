import * as React from "react";
import { modules } from "../types/Modules";

type ModuleContextType = {
  selectedFilter: string;
  setSelectedFilter: React.Dispatch<React.SetStateAction<string>>;
  moduleList: modules[] | [];
  setModuleList: React.Dispatch<React.SetStateAction<modules[] | []>>
};

const ModuleContext = React.createContext<ModuleContextType | undefined>(
  undefined
);

export const ModuleContextProvider = ({
  children,
}: {
  children: React.ReactNode;
}) => {
  const [selectedFilter, setSelectedFilter] = React.useState("");
  const [moduleList, setModuleList] = React.useState<modules[] | []>(() => []);
  const value = React.useMemo(
    () => ({ selectedFilter, setSelectedFilter, moduleList, setModuleList }),
    [selectedFilter, moduleList]
  );
  return (
    <ModuleContext.Provider value={value}>
      {children}
    </ModuleContext.Provider>
  );
};

export const useModuleContext = () => {
  const context = React.useContext(ModuleContext);
  if (!context) {
    throw new Error(
      "useModuleContext must be used within an ModuleContextProvider"
    );
  }
  return context;
};
