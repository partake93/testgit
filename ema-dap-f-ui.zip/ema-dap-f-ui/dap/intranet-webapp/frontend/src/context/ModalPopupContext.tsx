import * as React from "react";
import MyModal from "../components/molecules/MyModal/MyModal";

type ModalType = "info" | "success" | "warning" | "danger";

interface ModalOptions {
  title?: string;
  message: string | React.ReactNode;
  type?: ModalType;
  actionButtonLabel?: string;
  action?: () => void;
  isItFullScreen?: boolean;
}

interface ModalPopupContextType {
  showModal: (options: ModalOptions) => void;
  closeModal: () => void;
}

const ModalPopupContext = React.createContext<
  ModalPopupContextType | undefined
>(undefined);

export const ModalPopupProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [modalOptions, setModalOptions] = React.useState<ModalOptions | null>(
    null
  );

  const showModal = (options: ModalOptions) => {
    setModalOptions(options);
  };

  const closeModal = () => {
    setModalOptions(null);
  };

  return (
    <ModalPopupContext.Provider value={{ showModal, closeModal }}>
      {modalOptions && (
        <MyModal
          show={true}
          onClose={closeModal}
          title={modalOptions.title}
          actionButtonLabel={modalOptions.actionButtonLabel}
          action={() => {
            modalOptions.action?.();
            closeModal();
          }}
          isItFullScreen={modalOptions.isItFullScreen}
        >
          <span className="text-white">{modalOptions.message}</span>
        </MyModal>
      )}
      {children}
    </ModalPopupContext.Provider>
  );
};

export const useModalPopup = (): ModalPopupContextType => {
  const context = React.useContext(ModalPopupContext);
  if (!context) {
    throw new Error("useModal must be used within a ModalProvider");
  }
  return context;
};
