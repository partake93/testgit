import * as React from 'react';
import { Alert } from 'react-bootstrap';
import Typography from '../components/atoms/typography/Typography';

type AlertType = 'success' | 'danger' | 'warning' | 'info';

interface AlertItem {
  id: number;
  message: string;
  variant: AlertType;
  timeout?: number;
}

interface AlertContextType {
  showAlert: (message: string, variant?: AlertType, timeoutMs?: number) => void;
}

const AlertContext = React.createContext<AlertContextType | undefined>(undefined);

export const AlertProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [alerts, setAlerts] = React.useState<AlertItem[]>([]);
  const idRef = React.useRef(0);
  const timeoutMap = React.useRef<Map<number, number>>(new Map());

  const showAlert = (message: string, variant: AlertType = 'info', timeoutMs = 3000) => {
    const id = ++idRef.current;
    const newAlert: AlertItem = { id, message, variant, timeout: timeoutMs };

    setAlerts((prev) => [...prev, newAlert]);

    // const timeoutId = window.setTimeout(() => {
    //   removeAlert(id);
    // }, timeoutMs);

    // timeoutMap.current.set(id, timeoutId);
  };

  const removeAlert = (id: number) => {
    setAlerts((prev) => prev.filter((alert) => alert.id !== id));
    const timeoutId = timeoutMap.current.get(id);
    if (timeoutId) {
      clearTimeout(timeoutId);
      timeoutMap.current.delete(id);
    }
  };

  React.useEffect(() => {
    return () => {
      // Cleanup on unmount
      timeoutMap.current.forEach((timeoutId) => clearTimeout(timeoutId));
    };
  }, []);

  return (
    <AlertContext.Provider value={{ showAlert }}>
      {/* Alert container */}
      {alerts.length > 0 && (
        <div className="fixed top-5 right-5 z-[9999] w-full max-w-sm space-y-3 overflow-y-auto max-h-[80vh]">
          {alerts.map(({ id, message, variant }) => (
            <Typography key={id} variant="smallcaption">
              <Alert
                variant={variant}
                dismissible
                onClose={() => removeAlert(id)}
                role="alert"
              >
                {message}
              </Alert>
            </Typography>
          ))}
        </div>
      )}
      {children}
    </AlertContext.Provider>
  );
};

export const useAlert = (): AlertContextType => {
  const context = React.useContext(AlertContext);
  if (!context) {
    throw new Error('useAlert must be used within an AlertProvider');
  }
  return context;
};
