import {
  createContext,
  useState,
  useMemo,
  useContext,
  Dispatch,
  SetStateAction,
  ReactNode,
} from "react";
import { UserInfo } from "../types/Auth";

type UserContextType = {
  user: UserInfo;
  setUser: Dispatch<SetStateAction<UserInfo>>;
  isAdmin: boolean;
  setIsAdmin: Dispatch<SetStateAction<boolean>>;
};

const UserContext = createContext<UserContextType | undefined>(undefined);

type UserContextProviderProps = {
  children: ReactNode;
};

export const UserContextProvider = ({ children }: UserContextProviderProps) => {
  const [user, setUser] = useState<UserInfo>({} as UserInfo);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const value = useMemo(
    () => ({ user, setUser, isAdmin, setIsAdmin }),
    [user, isAdmin]
  );
  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
};

// eslint-disable-next-line react-refresh/only-export-components
export const useUserContext = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error("useUserContext must be used within a UserContextProvider");
  }
  return context;
};
