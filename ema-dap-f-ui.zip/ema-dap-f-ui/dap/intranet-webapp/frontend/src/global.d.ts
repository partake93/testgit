// src/global.d.ts or src/types/styles.d.ts

declare module '*.module.scss' {
  const classes: { [key: string]: string };
  export default classes;
}
