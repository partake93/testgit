import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.scss";
import "./styles/background_color.scss";
import { AlertProvider } from "./context/AlertContext.tsx";
import { UserContextProvider } from "./context/UserContext.tsx";
import { ModalPopupProvider } from "./context/ModalPopupContext.tsx";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <UserContextProvider>
      <ModalPopupProvider>
        <AlertProvider>
          <App />
        </AlertProvider>
      </ModalPopupProvider>
    </UserContextProvider>
  </StrictMode>
);
