import {
  Category,
  Dashboard,
  DashboardUpdate,
  sortDashboards,
} from "../types/Dashboards";
import { apiRoutes } from "../utils/apiRoutes";
import api, { ApiResponse } from "./api/api";

export const getCategories = async (): Promise<ApiResponse<Category[]>> => {
  const res = await api.get(apiRoutes.dashboardCategories);
  return res.data;
};

export const getDashboardsList = async (): Promise<
  ApiResponse<Dashboard[]>
> => {
  const res = await api.get(apiRoutes.dashboards);
  return res.data;
};

export const starDashboard = async (id: number): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.starDashboard, { dashboard_id: id });
  return res.data as ApiResponse<{}>;
};

export const sortingDashboards = async (dashboards: {
  updates: sortDashboards[];
}): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.sortDashboard, dashboards);
  return res.data as ApiResponse<{}>;
};

export const updateDashboard = async (
  dashboard: DashboardUpdate,
  id: number
): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.updateDashboard(id), dashboard);
  return res.data as ApiResponse<{}>;
};

export const addDashboard = async (
  dashboard: DashboardUpdate
): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.addDashboard, dashboard);
  return res.data as ApiResponse<{}>;
};
