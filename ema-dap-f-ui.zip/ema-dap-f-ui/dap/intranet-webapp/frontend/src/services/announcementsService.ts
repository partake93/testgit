import { announcementForm, announcements, sortAnnouncement } from "../types/Announcement";
import { apiRoutes } from "../utils/apiRoutes";
import api, { ApiResponse } from "./api/api";

export const getAnnouncementsList = async (
  page: number
): Promise<ApiResponse<announcements[]>> => {
  const res = await api.get(apiRoutes.announcements(page));
  return res.data as ApiResponse<announcements[]>;
};

export const getPublishedAnnouncementsList = async (): Promise<
  ApiResponse<announcements[]>
> => {
  const res = await api.get(apiRoutes.publishedAnnouncements);
  return res.data as ApiResponse<announcements[]>;
};

export const getAnnouncementsById = async (
  id: number
): Promise<ApiResponse<announcements>> => {
  const res = await api.get(apiRoutes.announcementByID(id));
  return res.data as ApiResponse<announcements>;
};

export const addAnnouncement = async (
  announcement: announcementForm
): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.addAnnouncement, announcement);
  return res.data as ApiResponse<{}>;
};

export const editAnnouncement = async (
  announcement: announcementForm,
  id: number
): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.editAnnouncement(id), announcement);
  return res.data as ApiResponse<{}>;
};

export const deleteAnnouncement = async (
  id: number
): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.deleteAnnouncement(id));
  return res.data as ApiResponse<{}>;
};

export const sortAnnouncements = async (announcement: {
  updates: sortAnnouncement[];
}): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.sortAnnouncements, announcement);
  return res.data as ApiResponse<{}>;
};
