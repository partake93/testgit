import {
  ModuleRequest,
  ModuleRequestDetail,
  modules,
  RaiseModuleRequest,
  sortModules,
  Tag,
  updateModule,
} from "../types/Modules";
import { apiRoutes } from "../utils/apiRoutes";
import { formatDate1 } from "../utils/date";
import api, { ApiResponse } from "./api/api";

export const getModulesList = async (): Promise<ApiResponse<modules[]>> => {
  const res = await api.get(apiRoutes.modules);
  return res.data as ApiResponse<modules[]>;
};

export const getTagList = async (): Promise<ApiResponse<Tag[]>> => {
  const res = await api.get(apiRoutes.modulesTags);
  return res.data as ApiResponse<Tag[]>;
};

export const sortingModules = async (modules: {
  updates: sortModules[];
}): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.sortModules, modules);
  return res.data as ApiResponse<{}>;
};

export const getModulesById = async (
  id: number
): Promise<ApiResponse<modules>> => {
  const res = await api.get(apiRoutes.modulesById(id));
  return res.data as ApiResponse<modules>;
};

export const addModules = async (
  module: updateModule
): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.addModule, module);
  return res.data as ApiResponse<{}>;
};

export const editModule = async (
  module: updateModule,
  id: number
): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.editModule(id), module);
  return res.data as ApiResponse<{}>;
};

export const deleteModule = async (id: number): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.deleteModule(id));
  return res.data as ApiResponse<{}>;
};

export const fileupload = async (
  formData: FormData
): Promise<ApiResponse<{ id: number }>> => {
  const res = await api.post(apiRoutes.fileupload, formData, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });
  return res.data as ApiResponse<{ id: number }>;
};

export const RaiseRequest = async (
  request: RaiseModuleRequest
): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.riseModuleRequest, request);
  return res.data as ApiResponse<{}>;
};

export const getModuleRequest = async (
  page: number,
  status: string | null,
  startDate: Date | null,
  endDate: Date | null
): Promise<ApiResponse<ModuleRequest[]>> => {
  const res = await api.get(
    `${apiRoutes.getModuleRequests}?page=${page}${
      status && status !== null ? `&status=${status}` : ""
    }${
      startDate && startDate !== null
        ? `&startdate=${formatDate1(startDate)}`
        : ""
    }${endDate && endDate !== null ? `&enddate=${formatDate1(endDate)}` : ""}`
  );
  return res.data as ApiResponse<ModuleRequest[]>;
};

export const getModuleRequestById = async (
  id: number
): Promise<ApiResponse<ModuleRequestDetail>> => {
  const res = await api.get(apiRoutes.moduleRequestById(id));
  return res.data as ApiResponse<ModuleRequestDetail>;
};

export const moduleRequestAction = async (
  id: number,
  action: string
): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.moduleRequestAction(id), {
    action: action,
  });
  return res.data as ApiResponse<{}>;
};

export const moduleRequestsAction = async (
  action: string,
  ids: string[]
): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.moduleRequestsAction, {
    action: action,
    request_ids: ids,
  });
  return res.data as ApiResponse<{}>;
};

export const getFileByName = async (
  filename: string
): Promise<{ blob: Blob; filename: string }> => {
  const response = await api.get(`${apiRoutes.receiveFile(filename)}`, {
    responseType: "blob",
  });

  // Try to extract the original filename
  const disposition = response.headers["content-disposition"];
  let extractedFilename = filename;
  if (disposition && disposition.includes("filename=")) {
    const match = disposition.match(/filename="?([^"]+)"?/);
    if (match?.[1]) extractedFilename = match[1];
  }

  return {
    blob: response.data,
    filename: extractedFilename,
  };
};
