import {
  QuickActionsList
} from "../types/QuickActions";
import { apiRoutes } from "../utils/apiRoutes";
import api, { ApiResponse } from "./api/api";

export const addQuickAction = async (QA:{
  label: string, url: string
}): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.addQuickAction, QA);
  return res.data as ApiResponse<{}>;
};

export const getQuickActionsList = async (): Promise<
  ApiResponse<QuickActionsList[]>
> => {
  const res = await api.get(apiRoutes.quickActions);
  return res.data as ApiResponse<QuickActionsList[]>;
};

export const deleteQuickAction = async (
  id: number
): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.deleteQuickAction(id));
  return res.data as ApiResponse<{}>;
};

export const getQuickActionById = async (
  id: number
): Promise<ApiResponse<{}>> => {
  const res = await api.post(apiRoutes.quickActionById(id));
  return res.data as ApiResponse<{}>;
};
