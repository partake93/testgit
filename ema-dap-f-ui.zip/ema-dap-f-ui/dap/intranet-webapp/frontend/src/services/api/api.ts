import axios from "axios";
import { getEnv } from '../../utils/getEnv';

const api = axios.create({
  baseURL: `${getEnv('VITE_BACKEND_URL')}/api`,
  headers: {
    "Content-Type": "application/json",
  },
  withCredentials: true, // for cookies
});

export default api;

export interface ApiResponse<T> {
  status: string;
  message: string;
  data?: T;
  total_count?: number;
  total_pages?: number;
  current_page?: number;
}
