import api, { ApiResponse } from "./api/api";
import { Notification, NotificationContent, NotificationHeader } from "../types/Notification";
import { apiRoutes } from "../utils/apiRoutes";

export const getNotifications = async (page: number, classification: string|null, search: string|null, startDate: string|null, endDate: string|null): Promise<ApiResponse<Notification[]>> => {
    const res = await api.get(`${apiRoutes.notifications}?page=${page}${classification && classification != null ? `&classification=${classification}` : ''}${search && search!==null ? `&search=${search}` : ''}${startDate && startDate!==null ? `&start_date=${startDate}` : ''}${endDate && endDate!==null ? `&end_date=${endDate}` : ''}`);
    return res.data as ApiResponse<Notification[]>;
};

export const getNotificationsHeader = async (): Promise<ApiResponse<{notifications : NotificationHeader[]}>> => {
    const res = await api.get(apiRoutes.notificationsHeader);
    return res.data as ApiResponse<{notifications : NotificationHeader[]}>;
}

export const markNotificationAsRead = async (id: number): Promise<ApiResponse<{}>> => {
    const res = await api.post(apiRoutes.viewNotification,{ notification_id: id });
    return res.data as ApiResponse<{}>;
};

export const getNotificationById = async (id: string): Promise<ApiResponse<{notification: NotificationContent}>> => {
    const res = await api.get(apiRoutes.notificationById(id));
    return res.data as ApiResponse<{notification : NotificationContent}>;
};