import { LoginInputType, UserInfo } from "../types/Auth";
import { apiRoutes } from "../utils/apiRoutes";
import api, { ApiResponse } from "./api/api";

export const loginUser = async (loginInput: LoginInputType): Promise<ApiResponse<object>> => {
  const response = await api.post(apiRoutes.login, loginInput);
  return response.data as ApiResponse<object>;
}

export const logoutUser = async (): Promise<ApiResponse<object>> => {
  const response = await api.post(apiRoutes.logout);
  return response.data as ApiResponse<object>;
}

export const checkValidUser = async (): Promise<ApiResponse<UserInfo>> => {
  const response = await api.get(apiRoutes.userInfo);
  return response.data as ApiResponse<UserInfo>;
}