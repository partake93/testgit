import { IconName } from "../components/atoms/Icons/Icon.type";

export interface Tag {
  id: number;
  label: string;
}

export interface modules {
  id: number;
  label: string;
  icon_name: IconName;
  tooltip_text: string;
  url: string;
  order_index: number;
  default_visible: boolean;
  has_access: boolean;
  pending: boolean;
  editable: boolean;
  confirmation_step: boolean;
  confirmation_text: string;
  updated_at: Date;
  updated_by_first_name: string;
  updated_by_last_name: string;
  tags: Tag[];
}

export interface sortModules {
  module_id: string;
  newIndex: number;
}

export interface updateModule {
  label: string;
  icon_name: string;
  tooltip_text: string;
  default_visible: boolean;
  url: string;
  tags: number[];
  confirmation_step: boolean;
  confirmation_text: string;
}

export interface RaiseModuleRequest {
  module_id: number;
  purpose: string;
  justification: string;
  file_ids: number[];
}

export interface ModuleRequest {
  module_id: number;
  purpose: string;
  status: string;
  created_by: number;
  action_by: number;
  justification: string;
  id: number;
  created_at: Date;
  action_at: Date | null;
  first_name: string;
  last_name: string;
  module_name: string;
}

export interface ModuleRequestDetail {
  id: number;
  module_id: number;
  module_name: string;
  purpose: string;
  justification: string;
  status: string;
  created_at: Date;
  created_by: number;
  created_by_first_name: string;
  created_by_last_name: string;
  file_ids: {
    id: string;
    file_name: string;
    file_size: number;
  }[];
}

export const moduleRequestsStatus = {
  pending: "pending",
  approved: "approved",
  rejected: "rejected",
};

export const moduleRequestsStatusList = [
  moduleRequestsStatus.pending,
  moduleRequestsStatus.approved,
  moduleRequestsStatus.rejected,
];
