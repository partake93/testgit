export interface pagination {
  total_pages: number;
  current_page: number;
}