export interface APIerror {
  detail?: [
    {
      loc?: ["string", 0];
      msg?: "string";
      type?: "string";
    }
  ];
  message?: string
}
