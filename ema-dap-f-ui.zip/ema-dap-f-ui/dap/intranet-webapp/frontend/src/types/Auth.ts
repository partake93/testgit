export interface LoginInputType {
  email: string;
}

export interface UserInfo {
  email: string;
  first_name: string;
  last_name: string;
  is_admin: boolean;
  is_dap_user: boolean;
}
