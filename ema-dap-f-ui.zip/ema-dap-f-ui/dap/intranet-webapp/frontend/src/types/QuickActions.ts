import { IconName } from "../components/atoms/Icons/Icon.type";

export interface QuickActionsList {
  label: string;
  url: string;
  id?: number;
  order_index: number;
  module_id: null | number;
  icon_name: IconName;
}

export interface QuickActionsListApiResponseType {
  status: string;
  message: string;
  data: QuickActionsList[];
}
