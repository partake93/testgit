export interface Category {
  id: number;
  name: string;
}

export interface Dashboard {
  version: string;
  title: string;
  description: string;
  order_index: number;
  created_at: Date;
  created_by: number;
  notes: string;
  id: number;
  url: string;
  status: string;
  updated_at: Date;
  updated_by: number;
  is_starred: boolean;
  updated_by_first_name: string;
  updated_by_last_name: string;
  categories: Category[];
}

export interface sortDashboards {
  dashboard_id: number;
  newIndex: number;
}

export interface DashboardUpdate {
  title: string;
  description: string;
  notes: string;
  version: string;
  url: string;
  category_ids: number[];
}
