export interface Notification {
  id: number;
  inserted_at: Date;
  classification: string;
  is_viewed: boolean;
  details: string;
  error_log_id: string | null;
  zip_file_name: string | null;
  source_file_name: string | null;
  data_module: string | null;
  error_code: string | null;
  error_desc: string | null;
  request_id: number | null;
  items: {
    error_log_id: string;
    inserted_at: Date;
    classification: string | null;
    zip_file_name: string | null;
    source_file_name: string | null;
    data_module: string | null;
    error_code: string | null;
    error_desc: string | null;
  }[];
  content?: string;
}

export interface NotificationContent {
  error_log_id: number;
  content: string;
}

export interface NotificationHeader {
  is_viewed: boolean;
  error_code: string | null;
  source_file_name: string | null;
  details: string | null;
}
