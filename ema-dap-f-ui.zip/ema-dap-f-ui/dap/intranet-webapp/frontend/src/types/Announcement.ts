export interface announcementList {
  id: string;
  title: string;
  createdOrEditedBy: string;
  startDate: Date;
  endDate: Date;
  status: string;
  publishedIndex: number;
}

export interface announcements {
  url: string;
  id: number;
  start_date: Date;
  status: string;
  order_index: number;
  title: string;
  text: string;
  end_date: Date;
  first_name: string;
  last_name: string;
}

export const announcementStatus = {
  programmed: "programmed",
  draft: "draft",
  published: "published",
  expired: "expired",
};

export const announcementStatusList = [
  announcementStatus.published,
  announcementStatus.programmed,
  announcementStatus.draft,
  announcementStatus.expired,
];

export interface sortAnnouncement {
  announcement_id: string;
  newIndex: number;
}

export interface announcementForm {
  title: string;
  text: string;
  url: string;
  start_date: Date;
  end_date: Date;
  status: string;
}
