const auth = "auth";
const announcement = "announcements";
const dashboard = "dashboards";
const modules = "modules";
const quickActions = "quickactions";
const notifications = "notifications";
const requests = "requests";

export const apiRoutes = {
  login: `/${auth}/login`,
  logout: `/${auth}/logout`,
  userInfo: `/${auth}/user_info`,
  //######## Announcements Routes ######## 
  announcements:(page: number) => `/${announcement}/?page=${page}`,
  publishedAnnouncements: `/${announcement}/published`,
  announcementByID: (id: number) => `/${announcement}/${id}`,
  addAnnouncement: `/${announcement}/add`,
  editAnnouncement: (id: number) => `/${announcement}/${id}/edit`,
  deleteAnnouncement: (id: number) => `/${announcement}/${id}/delete`,
  sortAnnouncements: `/${announcement}/sort`,
  //######## Dashboard Routes ########
  dashboards: `/${dashboard}/`,
  starDashboard: `/${dashboard}/star`,
  sortDashboard: `/${dashboard}/sort`,
  updateDashboard: (id: number) => `/${dashboard}/${id}/update`,
  addDashboard: `/${dashboard}/add`,
  dashboardCategories: `/${dashboard}/categories`,
  //######## Modules Routes ########
  modules: `/${modules}/`,
  modulesById: (id: number) => `/${modules}/${id}`,
  addModule: `/${modules}/add`,
  editModule: (id: number) => `/${modules}/${id}/edit`,
  deleteModule: (id: number) => `/${modules}/${id}/delete`,
  sortModules: `/${modules}/sort`,
  modulesTags: `/${modules}/all_tags`,
  // ######## Module Request Routes ########
  riseModuleRequest: `/${requests}/raise`,
  getModuleRequests: `/${requests}/`,
  moduleRequestById: (id: number) => `/${requests}/${id}`,
  moduleRequestAction: (id: number) => `/${requests}/${id}/action`,
  moduleRequestsAction: `/${requests}/action`,
  //######## Quick Actions Routes ########
  quickActions: `/${quickActions}/`,
  addQuickAction: `/${quickActions}/add`,
  quickActionById: (id: number) => `/${quickActions}/${id}`,
  deleteQuickAction: (id: number) => `/${quickActions}/${id}/delete`,
  // ######## Notifications Routes ########
  notifications: `/${notifications}/`,
  notificationById: (id: string) => `/${notifications}/${id}`,
  notificationsHeader: `/${notifications}/header`,
  viewNotification: `/${notifications}/viewed`,
  // ######## File Upload Routes ########
  fileupload: `/uploads/`,
  receiveFile:(filename: string)=> `/uploads/file/${filename}`
}