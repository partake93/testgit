import { format } from "date-fns";

export const formatDate = (date: Date) => {
    return format(new Date(date), "dd MMM yyyy, HH:mm");
};

export const formatDate1 = (date: Date, ) => {
    return format(new Date(date), "yyyy-MM-dd");
};