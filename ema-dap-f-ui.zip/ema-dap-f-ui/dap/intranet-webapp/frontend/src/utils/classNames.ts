export const classNames = {
    dark: " text-black",
    light: " text-white",
    border_dark: " border border-black",
    border_light: " border border-white"
};