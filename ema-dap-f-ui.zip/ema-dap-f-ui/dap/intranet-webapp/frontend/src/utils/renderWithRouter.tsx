import { render } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

const renderWithRouter = (ui: any, options: any) => {
  return render(<MemoryRouter>{ui}</MemoryRouter>, options);
};

export default renderWithRouter;