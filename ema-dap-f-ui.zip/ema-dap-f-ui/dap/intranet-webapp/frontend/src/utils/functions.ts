export const isValidUrl = (url: string): boolean => {
  try {
    new URL(url);
    const urlRegex = /^(https?:\/\/)?([\w-]+\.)+[\w-]{2,}(\/[\w\-._~:/?#[\]@!$&'()*+,;=]*)?$/i;
    if (!urlRegex.test(url)) {
      return false;
    }
    return true;
  } catch (_) {
    return false;
  }
};