export const api_status = {
  success: "success",
  error: "error",
};

export const status_const = {
  info: "info",
  warning: "warning",
};

export const common_labels = {
  save: "Save",
  cancel: "Cancel",
  delete: "Delete",
  edit: "Edit",
  create: "Create",
  update: "Update",
  publish: "Publish",
  submit: "Submit",
  review: "Review",
  close: "Close",
  confirm: "Confirm",
  all: "All",
  view: "View",
  viewDetails: "View Details",
  up: "up",
  down: "down",
  add: "Add",
  approve: "Approve",
  reject: "Reject",
};

export const date_const = {
  endDateError: "End date must be after start date",
  startDateError: "Start date must be before end date",
  dateRequired: "Please fill the date",
  invalidDate: "Invalid date format",
  pastDateError: "Date cannot be in the past",
};

export const error_const = {
  generic: "An error occurred.",
  notFound: "The requested {resource} was not found.",
  unauthorized: "You are not authorized to perform this action.",
  forbidden: "You do not have permission to access this resource.",
  validationError: "There were validation errors. Please check your input.",
  unknown: "Unknown error occurred",
  apiError: "An error occurred while communicating with the server.",
  failed: "Failed", // Failed message prefix
  apiFailedCustom: (message: string) =>
    `Failed: ${message || error_const.apiError}`,
  selectAtLeastOne: "Please select at least one item",
};

export const modules_const = {
  modules: "Modules",
  manageModules: "Manage Modules",
  accessRequest: "Access Request",
  add: "Add Module",
  moduleNotFound: "Module not found",
  moduleDeleted: "Module deleted successfully",
  moduleUpdated: "Module updated successfully",
  moduleCreated: "Module created successfully",
  moduleNameRequired: "Module name is required",
  moduleDescriptionRequired: "Module description is required",
  moduleTagsRequired: "At least one tag is required",
  tagsNotFound: "Tags not found",

  titleError: "Please fill the Title",
  urlError: "Please provide the valid URL",
  tooltipError: "Please fill the Tooltip",
  categoryRequired: "Please select at least one Category",
  iconRequired: "Please select a valid Icon",
  request: "Requests",
  requestDetailsError: "Failed to fetch request details",
  requestActionSuccess: "Request {action} successfully",
  commentRequired: "Please provide a comment",
  noRequestsFound: "No requests found",
};

export const file_const = {
  success: "File uploaded successfully",
  failed: "File upload failed",
  multipleFilesFailed: "Some files failed to upload",
};

export const module_request_const = {
  selctModule: "Please select a module",
  purposeError: "Please provide a purpose for the request",
  justificationError:
    "Please provide a justification or Use Case for the request",
  documentationError: "Please provide documentation for the request",
  success: "Module request submitted successfully",
  failed: "Module request submission failed",
};

export const dashboard_const = {
  dashboards: "Dashboards",
  manageDashboards: "Manage Dashboards",
  add: "Add Dashboard",
  dashboardNotFound: "Dashboard not found",
  categoriesNotFound: "Categories not found",
  dashboardDeleted: "Dashboard deleted successfully",
  dashboardUpdated: "Dashboard updated successfully",
  dashboardCreated: "Dashboard created successfully",
  goToDashboard: "Go to Dashboard",
  removeQuickActions: "Dashboard removed from Quick Actions successfully",
  addQuickActions: "Dashboard added to Quick Actions successfully",
  categoriesFailed: "Failed to fetch categories",
  titleError: "Please enter a valid title",
  versionError: "Please enter a valid version",
  urlError: "Please enter a valid Link",
  descriptionError: "Please enter a valid Description",
  notesError: "Please enter a valid Notes",
  categoryError: "Please select at least one category",
};

export const announcement_const = {
  announcements: "Announcements",
  manageAnnouncements: "Manage Announcements",
  add: "Add Announcement",
  announcementNotFound: "Announcement not found",
  announcementDeleted: "Announcement deleted successfully",
  announcementUpdated: "Announcement updated successfully",
  announcementCreated: "Announcement created successfully",
  titleError: "Please enter a valid title",
  textError1: "Text must be at least 10 characters long.",
  textError: "Please enter a valid description",
  startDateError: "Please select a valid start date",
  endDateError: "Please select a valid end date",
  announcementError: "Failed to fetch announcements",
};

export const notification_const = {
  notifications: "Notifications",
  logNotFound:
    "This notification does not have an error log ID associated with it.",
  logEmpty: "No data available for this log ID.",
  failed: "Failed to fetch notifications",
  notFound: "No notifications found",
  clearFilterDesc: "Clear all filters",
};
