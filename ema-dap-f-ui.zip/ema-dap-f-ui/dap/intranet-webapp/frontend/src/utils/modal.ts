export const modalString = {
    announcementDeleteTitle: "Are you sure you want to delete this announcement?",
    quickActionDeleteTitle: "Are you sure you want to delete this Quick Action?",
    moduleDeleteTitle: "Are you sure you want to delete this Module?",
    actionBody: "This action cannot be undone",
    textEditorTitle: "Insert a URL",
    quickActionAdd: "Add New Quick Action"
}