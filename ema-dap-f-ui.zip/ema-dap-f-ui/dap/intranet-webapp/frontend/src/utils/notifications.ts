import { useEffect, useState, useRef, useCallback } from 'react';
import { useErrorManager } from './manageApiError';
import { APIerror } from '../types/Error';

type UsePollingOptions<T> = {
  fetchFn: () => Promise<T>;
  interval?: number;
  onData?: (data: T) => void;
};

export function useNotifications<T>({ fetchFn, interval = 300, onData }: UsePollingOptions<T>) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const errorManager = useErrorManager();

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const result = await fetchFn();
      setData(result);
      onData?.(result);
    } catch (err) {
        errorManager(err as Error | APIerror);
        setData(null);
    } finally {
      setLoading(false);
    }
  }, [fetchFn, onData]);

  useEffect(() => {
    fetchData(); // Initial fetch
    timerRef.current = setInterval(fetchData, (interval*1000));

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [fetchData, interval]);

  return { data, loading };
}
