import axios from "axios";
import { APIerror } from "../types/Error";
import { useModalPopup } from "../context/ModalPopupContext";
import { api_status, error_const } from "./constants";

export const useErrorManager = () => {
  const { showModal } = useModalPopup();
  return (error: Error | APIerror) => {
    let err = error_const.unknown;
    if (axios.isAxiosError(error)) {
      err = error.response?.data.message || error_const.apiError;
    } else {
      err = (error as APIerror)?.detail?.[0]?.msg || (error as Error).message;
    }
    showModal({
      title: api_status.error,
      message: err,
      type: "danger",
      isItFullScreen: true
    });
  };
};
