  import { routes } from "./routes";

export const defaultModulesNames = ["dashboards", "user management", "requests", "public datasets", "manual upload"];

export const defaultModules: {label: string, url: string}[] = [
    { label: "Dashboards", url: routes.dashboards},
    { label: "Requests", url: routes.moduleRequestList }
];