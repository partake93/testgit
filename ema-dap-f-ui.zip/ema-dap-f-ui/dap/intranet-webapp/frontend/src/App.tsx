import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import Home from './components/pages/Home.tsx';
import Layout from './components/templates/Layout.tsx';
import PageNotFound from './components/pages/PageNotFound.tsx';
import { Routes, Route, BrowserRouter as Router } from 'react-router';
import { routes } from './utils/routes.ts';
import Login from './components/pages/Login.tsx';
import Notifications from './components/pages/Notifications.tsx';
import "react-datetime/css/react-datetime.css";
import AnnouncementForm from './components/pages/announcements/AnnouncementsForm/AnnouncementsForm.tsx';
import ModulesManagement from './components/pages/modules/ModulesManagement/ModulesManagement.tsx';
import Dashboards from './components/pages/dashboards/Dashboards/Dashboards.tsx';
import ManageDashboards from './components/pages/dashboards/ManageDashboards/ManageDashboards.tsx';
import ModulesForm from './components/pages/modules/ModulesForm/ModulesForm.tsx';
import ModulesRequest from './components/pages/modules/ModulesRequest/ModulesRequest.tsx';
import ManageAnnouncements from './components/pages/announcements/ManageAnnouncements/ManageAnnouncements.tsx';
import ModulesRequestsManagement from './components/pages/modules/ModulesRequestsManagement/ModulesRequestsManagement.tsx';
import ModuleRequestDetails from './components/pages/modules/ModuleRequestDetails/ModuleRequestDetails.tsx';

const App = () => {

  return (
    <>
      <Router>
        <Routes>
          <Route path={routes.login} element={<Login />} /> 
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route path={routes.announcementsManagement} element={<ManageAnnouncements />} />
            <Route path={routes.addAnnouncements} element={<AnnouncementForm />} />
            <Route path={routes.viewAnnouncements} element={<AnnouncementForm />} />
            <Route path={routes.modulesManagement} element={<ModulesManagement />} />
            <Route path={routes.addModules} element={<ModulesForm />} />
            <Route path={routes.viewModules} element={<ModulesForm />} />
            <Route path={routes.dashboards} element={<Dashboards />} />
            <Route path={routes.dashboardsManagement} element={<ManageDashboards />} />
            <Route path={routes.notifications} element={<Notifications />} />
            <Route path={routes.moduleRequest} element={<ModulesRequest />} />
            <Route path={routes.moduleRequestList} element={<ModulesRequestsManagement />} />
            <Route path={routes.moduleRequestDetails} element={<ModuleRequestDetails />} />
            {/* Catch-all route for 404 Not Found */}
            <Route path="*" element={<PageNotFound />} />
          </Route>
        </Routes>
      </Router>
    </>
  );
};

export default App;