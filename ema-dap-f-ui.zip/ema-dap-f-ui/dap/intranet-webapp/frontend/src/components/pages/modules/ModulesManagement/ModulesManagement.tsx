import * as React from "react";
import * as service from "../../../../services/modulesService";
import { useNavigate } from "react-router-dom";
import { APIerror } from "../../../../types/Error";
import { modules, sortModules } from "../../../../types/Modules";
import {
  api_status,
  error_const,
  modules_const,
  common_labels,
  status_const,
} from "../../../../utils/constants";
import { useErrorManager } from "../../../../utils/manageApiError";
import { routes } from "../../../../utils/routes";
import Icons from "../../../atoms/Icons/Icons";
import Typography from "../../../atoms/typography/Typography";
import Loading from "../../../Organisms/Loading/Loading";
import SectionHeader from "../../../Organisms/SectionHeader";
import { formatDate } from "../../../../utils/date";
import { useModalPopup } from "../../../../context/ModalPopupContext";
import Button from "../../../molecules/Button/Button";

const ModulesManagement = () => {
  const [modulesList, setModulesList] = React.useState<modules[]>([]);
  const [isLoading, setLoading] = React.useState<boolean>(false);
  const [isLoading1, setIsLoading1] = React.useState<boolean>(false);

  const navigate = useNavigate();
  const { showModal } = useModalPopup();
  const errorManager = useErrorManager();

  const sortListModules = async (
    updates: sortModules[],
    updatedList: modules[]
  ) => {
    try {
      setIsLoading1(true);
      const res = await service.sortingModules({ updates: updates });
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      setModulesList(sortTheList([...updatedList]));
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading1(false);
    }
  };

  const getModulesList = async () => {
    try {
      setLoading(true);
      const res = await service.getModulesList();
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      if (!res.data || res.data.length === 0) {
        showModal({
          message: modules_const.moduleNotFound,
          title: status_const.info,
        });
        return;
      }
      setModulesList(sortTheList(res.data));
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    getModulesList();
  }, []);

  const sortTheList = (data: modules[]) => {
    if (data.length > 0) {
      const sort: modules[] = [...data].sort(
        (a, b) => a.order_index - b.order_index
      );
      return sort;
    }
    return data;
  };

  const changeIndex = (action: string, index: number) => {
    const updates: sortModules[] = [];
    const updatedList = [...modulesList];
    if (action == common_labels.up) {
      if (index != 0) {
        const topRowIndex = index - 1;
        if (
          updatedList[index]?.order_index &&
          updatedList[topRowIndex]?.order_index
        ) {
          const orderIndex = updatedList[index].order_index;
          const topRowOrderIndex = updatedList[topRowIndex].order_index;
          updatedList[index].order_index = topRowOrderIndex;
          updatedList[topRowIndex].order_index = orderIndex;
          updates.push({
            module_id: updatedList[index].id.toString(),
            newIndex: topRowOrderIndex,
          });
          updates.push({
            module_id: updatedList[topRowIndex].id.toString(),
            newIndex: orderIndex,
          });
        }
      }
    } else {
      if (index + 1 != updatedList.length) {
        const bottomRowIndex = index + 1;
        if (
          updatedList[index].order_index != undefined &&
          updatedList[bottomRowIndex].order_index != undefined
        ) {
          const orderIndex = updatedList[index].order_index;
          const bottomRowOrderIndex = updatedList[bottomRowIndex].order_index;
          updatedList[index].order_index = bottomRowOrderIndex;
          updatedList[bottomRowIndex].order_index = orderIndex;
          updates.push({
            module_id: updatedList[index].id.toString(),
            newIndex: bottomRowOrderIndex,
          });
          updates.push({
            module_id: updatedList[bottomRowIndex].id.toString(),
            newIndex: orderIndex,
          });
        }
      }
    }
    if (updates.length === 2) {
      sortListModules(updates, updatedList);
    }
  };

  const isButtonDisabled = (action: string, index: number) => {
    let disabled: boolean = false;
    if (action == common_labels.up) {
      disabled = index == 0;
    } else {
      disabled = index + 1 == modulesList.length;
    }
    return disabled;
  };

  const navigator = (type: string, id?: number) => {
    if (type == common_labels.add) {
      navigate(routes.addModules);
    } else {
      navigate(`${routes.modulesManagement}/${id}`);
    }
  };

  return (
    <>
      <SectionHeader
        title={modules_const.manageModules}
        hasNavigation={true}
        navigateTo={routes.home}
        variant="header01"
        hasButton={true}
        className="text-white"
        button={{
          label: modules_const.add,
          variant: "lead02",
          hasBorder: false,
          hasIcon: true,
          iconOnLeft: true,
          className: "text-secondary-04",
          icon: { name: "plusWithCircle", color: "#57B4FF", size: 20 },
          onClick: () => navigator(common_labels.add),
        }}
      />
      {isLoading ? (
        <Loading isFullPage={false} className="min-h-60!" />
      ) : (
        <>
          <div className="w-full overflow-x-auto!">
            <div className="overflow-x-auto table w-full text-white">
              <table className="min-w-[900px] w-full table-auto text-white">
                <thead>
                  <tr>
                    <th></th>
                    <th>
                      <Typography variant="lead02" as="span">
                        Module
                      </Typography>
                    </th>
                    <th>
                      <Typography variant="lead02" as="span">
                        Default
                      </Typography>
                    </th>
                    <th>
                      <Typography variant="lead02" as="span">
                        Category
                      </Typography>
                    </th>
                    <th>
                      <Typography variant="lead02" as="span">
                        Created/Last Edited
                      </Typography>
                    </th>
                    <th>
                      <Typography variant="lead02" as="span">
                        Created/Last Edited by
                      </Typography>
                    </th>
                    <th>
                      <Typography variant="lead02" as="span">
                        Action
                      </Typography>
                    </th>
                  </tr>
                </thead>
                <tbody className="max-h-2/3 overflow-y-auto">
                  {modulesList.length > 0 &&
                    modulesList.map((x, i) => {
                      return (
                        <tr key={x.id}>
                          <td className="p-0!">
                            <div className="flex flex-col">
                              <button
                                className="cursor-pointer m-1"
                                onClick={() => {
                                  if (!isButtonDisabled(common_labels.up, i)) {
                                    changeIndex(common_labels.up, i);
                                  }
                                }}
                              >
                                <Icons
                                  name="upArrow"
                                  size={8}
                                  color={
                                    isButtonDisabled(common_labels.up, i)
                                      ? "#ffffff80"
                                      : "#fff"
                                  }
                                />
                              </button>
                              <button
                                className="cursor-pointer m-1"
                                onClick={() => {
                                  if (
                                    !isButtonDisabled(common_labels.down, i)
                                  ) {
                                    changeIndex(common_labels.down, i);
                                  }
                                }}
                              >
                                <Icons
                                  name="downArrow"
                                  size={8}
                                  color={
                                    isButtonDisabled(common_labels.down, i)
                                      ? "#ffffff80"
                                      : "#fff"
                                  }
                                />
                              </button>
                            </div>
                          </td>
                          <td>
                            <Typography variant="label01" as="span">
                              {x.label}
                            </Typography>
                          </td>
                          <td>
                            <Typography variant="label01" as="span">
                              {x.default_visible ? "Yes" : "No"}
                            </Typography>
                          </td>
                          <td>
                            <Typography variant="label01" as="span">
                              {x.tags.length > 0
                                ? x.tags.map((y) => y.label).join(", ")
                                : "-"}
                            </Typography>
                          </td>
                          <td>
                            <Typography variant="label01" as="span">
                              {x.updated_at
                                ? formatDate(new Date(x.updated_at))
                                : "-"}
                            </Typography>
                          </td>
                          <td>
                            <Typography variant="label01" as="span">
                              {x.updated_by_first_name || x.updated_by_last_name
                                ? `${x.updated_by_first_name} ${x.updated_by_last_name}`
                                : "-"}
                            </Typography>
                          </td>
                          <td>
                            {x.editable && (
                              <Button
                                variant="label01"
                                className="text-secondary-04"
                                label={common_labels.edit}
                                hasBorder={false}
                                hasIcon={true}
                                iconOnLeft={false}
                                isActive={true}
                                icon={{
                                  name: "arrowRight",
                                  color: "#57B4FF",
                                  size: 10,
                                }}
                                onClick={() =>
                                  navigator(common_labels.view, x.id)
                                }
                              />
                            )}
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
          {modulesList.length === 0 && (
            <div className="flex justify-center items-center h-20">
              <Typography variant="lead01" className="text-white">
                {modules_const.moduleNotFound}
              </Typography>
            </div>
          )}
        </>
      )}
      {isLoading1 && <Loading varient={true} />}
    </>
  );
};

export default ModulesManagement;
