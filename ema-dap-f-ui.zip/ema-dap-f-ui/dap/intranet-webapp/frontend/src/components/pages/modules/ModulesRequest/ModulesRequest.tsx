import * as React from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useUserContext } from "../../../../context/UserContext";
import {
  getModulesList,
  fileupload,
  RaiseRequest,
} from "../../../../services/modulesService";
import { APIerror } from "../../../../types/Error";
import { modules } from "../../../../types/Modules";
import {
  api_status,
  modules_const,
  module_request_const,
  file_const,
  common_labels,
  error_const,
} from "../../../../utils/constants";
import { useErrorManager } from "../../../../utils/manageApiError";
import { routes } from "../../../../utils/routes";
import Icons from "../../../atoms/Icons/Icons";
import Typography from "../../../atoms/typography/Typography";
import Loading from "../../../Organisms/Loading/Loading";
import SectionHeader from "../../../Organisms/SectionHeader";
import { useModalPopup } from "../../../../context/ModalPopupContext";
import InputBox from "../../../atoms/InputBox/InputBox";
import MyModal from "../../../molecules/MyModal/MyModal";
import Button from "../../../molecules/Button/Button";

type formFieldesValidation = {
  purpose: boolean;
  justification: boolean;
  module: boolean;
};

const ModulesRequest = () => {
  const [moduleList, setModuleList] = React.useState<modules[]>([]);
  const [selected, setSelected] = React.useState<string>("");
  const [purpose, setPurpose] = React.useState<string>("");
  const [justification, setJustification] = React.useState<string>("");
  const [files, setFiles] = React.useState<File[]>([]);
  const [isLoading, setLoading] = React.useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const dropRef = React.useRef<HTMLDivElement>(null);

  const [showError, setShowError] = React.useState<formFieldesValidation>({
    purpose: false,
    justification: false,
    module: false,
  });
  const [errormodal, setErrorModal] = React.useState<string[]>([]);

  const { user } = useUserContext();
  const errorManager = useErrorManager();
  const { showModal } = useModalPopup();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  React.useEffect(() => {
    fetchModules();
  }, []);

  const fetchModules = async () => {
    try {
      const response = await getModulesList();
      if (response.status === api_status.success) {
        if (!response.data || response.data.length === 0) {
          // showModal({message: modules_const.moduleNotFound, title: status_const.info});
          return;
        }
        setModuleList([...response.data].filter((m) => !m.has_access));
        const id = searchParams.get("id");
        if (id) {
          const module = response.data.find((m) => m.id === parseInt(id));
          if (module) {
            setSelected(module.label);
          } else {
            showModal({
              message: modules_const.moduleNotFound,
              title: api_status.error,
            });
          }
        }
      } else {
        errorManager(response.message as Error | APIerror);
      }
    } catch (error) {
      errorManager(error as Error | APIerror);
    }
  };

  const changeModule = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setSelected(value);
  };

  // Handle file input
  const handleFiles = (newFiles: FileList | null) => {
    if (newFiles) {
      const fileArray = Array.from(newFiles);
      setFiles((prev) => [...prev, ...fileArray]);
    }
  };

  // Handle file paste
  React.useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      if (e.clipboardData?.files.length) {
        handleFiles(e.clipboardData.files);
      }
    };
    window.addEventListener("paste", handlePaste);
    return () => window.removeEventListener("paste", handlePaste);
  }, []);

  // Handle drop events
  React.useEffect(() => {
    const dropArea = dropRef.current;
    if (!dropArea) return;

    const handleDrop = (e: DragEvent) => {
      e.preventDefault();
      handleFiles(e.dataTransfer?.files || null);
    };

    const handleDragOver = (e: DragEvent) => {
      e.preventDefault();
    };

    dropArea.addEventListener("drop", handleDrop);
    dropArea.addEventListener("dragover", handleDragOver);

    return () => {
      dropArea.removeEventListener("drop", handleDrop);
      dropArea.removeEventListener("dragover", handleDragOver);
    };
  }, []);

  const formatFileSize = (size: number) => {
    const i = Math.floor(Math.log(size) / Math.log(1024));
    return (
      (size / Math.pow(1024, i)).toFixed(1) +
      " " +
      ["B", "KB", "MB", "GB", "TB"][i]
    );
  };

  const handleSubmit = () => {
    const errorFields: formFieldesValidation = {
      purpose: false,
      justification: false,
      module: false,
    };
    if (!selected || selected === "") {
      errorFields.module = true;
      setErrorModal((payload) => [
        ...payload,
        module_request_const.selctModule,
      ]);
    }
    if (!purpose || purpose.trim() === "") {
      errorFields.purpose = true;
      setErrorModal((payload) => [
        ...payload,
        module_request_const.purposeError,
      ]);
    }
    if (!justification || justification.trim() === "") {
      errorFields.justification = true;
      setErrorModal((payload) => [
        ...payload,
        module_request_const.justificationError,
      ]);
    }
    if (files.length === 0) {
      setErrorModal((payload) => [
        ...payload,
        module_request_const.documentationError,
      ]);
    }
    setShowError(errorFields);
    if (
      errorFields.module ||
      errorFields.purpose ||
      errorFields.justification ||
      files.length === 0
    ) {
      return;
    }
    handleFileupload();
  };

  const handleFileupload = async () => {
    try {
      setLoading(true);
      const fileIds: number[] = [];
      for (const file of files) {
        const formData = new FormData();
        formData.append("domain_name", selected);
        formData.append("table_name", selected);
        formData.append("action_name", purpose);
        formData.append("justification", justification);
        formData.append("file", file);
        const response = await fileupload(formData);
        if (response.status === api_status.success) {
          showModal({
            message: module_request_const.success,
            title: api_status.success,
          });
          if (response.data && response.data.id) {
            fileIds.push(response.data.id);
            if (fileIds.length === files.length) {
              submitRequest(fileIds);
            }
          }
        } else {
          showModal({
            message: `${module_request_const.failed}: ${
              response.message || error_const.apiError
            }`,
            title: api_status.error,
          });
        }
      }
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setLoading(false);
    }
  };

  const submitRequest = async (fileIds: number[]) => {
    const errorFields: formFieldesValidation = {
      purpose: false,
      justification: false,
      module: false,
    };
    if (!selected || selected === "") {
      errorFields.module = true;
      setErrorModal((payload) => [
        ...payload,
        module_request_const.selctModule,
      ]);
    }
    if (!purpose || purpose.trim() === "") {
      errorFields.purpose = true;
      setErrorModal((payload) => [
        ...payload,
        module_request_const.purposeError,
      ]);
    }
    if (!justification || justification.trim() === "") {
      errorFields.justification = true;
      setErrorModal((payload) => [
        ...payload,
        module_request_const.justificationError,
      ]);
    }
    if (files.length === 0) {
      setErrorModal((payload) => [
        ...payload,
        module_request_const.documentationError,
      ]);
    }
    if (fileIds.length !== files.length) {
      setErrorModal((payload) => [...payload, file_const.multipleFilesFailed]);
    }
    setShowError(errorFields);
    if (
      errorFields.module ||
      errorFields.purpose ||
      errorFields.justification ||
      files.length === 0 ||
      fileIds.length !== files.length
    ) {
      return;
    }
    try {
      setLoading(true);
      const res = await RaiseRequest({
        module_id: moduleList.find((m) => m.label === selected)?.id || 0,
        purpose: purpose,
        justification: justification,
        file_ids: fileIds,
      });
      if (res.status === api_status.success) {
        showModal({
          message: module_request_const.success,
          title: api_status.success,
        });
        // Reset form fields
        setSelected("");
        setPurpose("");
        setJustification("");
        setFiles([]);
        navigate(routes.home);
      } else {
        showModal({
          message: `${module_request_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
      }
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <SectionHeader
        title={modules_const.accessRequest}
        hasNavigation={true}
        navigateTo={routes.home}
        variant="header01"
        hasButton={false}
        className="text-white"
      />
      <div>
        <Typography variant="smallcaption" className="px-0.5 my-1.5">
          <select
            onChange={changeModule}
            className={`text-white border-1 rounded-full px-2 py-2 ${
              showError.module ? "border-red-500!" : ""
            } focus:outline-none`}
            value={selected}
          >
            <option value="" disabled>
              Select Module
            </option>
            {moduleList.map((module) => (
              <option
                key={module.id}
                value={module.label}
                className="text-black"
              >
                {module.label}
              </option>
            ))}
          </select>
        </Typography>
      </div>
      <div className="text-white px-5.5 py-2.5 border-2 flex flex-col gap-y-2 bg-[#8AB6EA1A] rounded-xl">
        <div className="flex flex-col gap-y-2">
          <Typography variant="lead02">
            <strong>User</strong>
          </Typography>
          <Typography variant="label01">
            {user?.first_name} {user?.last_name}
          </Typography>
        </div>
        <div className="flex flex-col gap-y-2">
          <Typography variant="lead02">
            <strong>Purpose of Request</strong>
          </Typography>
          <div className="w-full">
            <InputBox
              varient="label01"
              name={"purpose" + Math.random()}
              className="w-full h-20 bg-transparent border-1 rounded-lg p-2"
              placeholder="Describe the purpose of your request here..."
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              error={showError.purpose}
              required={true}
              isInput={false}
            />
          </div>
        </div>
        <div className="flex flex-col gap-y-2">
          <Typography variant="lead02">
            <strong>Justification / Use Case</strong>
          </Typography>
          <div className="w-full">
            <InputBox
              varient="label01"
              name={"justification" + Math.random()}
              className="w-full h-20 bg-transparent border-1 rounded-lg p-2"
              placeholder="Provide justification or use case for the module request..."
              value={justification}
              onChange={(e) => setJustification(e.target.value)}
              error={showError.justification}
              required={true}
              isInput={false}
            />
          </div>
        </div>
        <div className="flex flex-col gap-y-2">
          <Typography variant="lead02">
            <strong>Supporting Documents</strong>
          </Typography>
          <Typography variant="label01">
            <div className="md:flex gap-2 w-full bg-transparent rounded-lg">
              <div
                ref={dropRef}
                onClick={() => fileInputRef.current?.click()}
                className={`min-w-2/5 ${
                  files.length > 0 ? "w-fit" : "w-full"
                } flex justify-center items-center border-1 border-dashed rounded-md text-center h-fit cursor-pointer hoverObj`}
              >
                <div className="flex flex-col items-center justify-center w-full h-fit p-0.5">
                  <span>
                    <Icons name="upload" size={25} />
                  </span>
                  <span>Click to add files</span>
                  <span>or</span>
                  <span>Drag and drop, or paste files here</span>
                </div>
                <input
                  type="file"
                  multiple
                  ref={fileInputRef}
                  onChange={(e) => handleFiles(e.target.files)}
                  className="hidden"
                />
              </div>

              {files.length > 0 && (
                <Typography
                  variant="lead01"
                  className="grid grid-cols-[repeat(auto-fit,_minmax(167px,_1fr))] gap-1 w-full h-full overflow-y-auto p-2 max-h-40"
                >
                  {files.map((file, idx) => {
                    const fileURL = URL.createObjectURL(file);
                    return (
                      <span
                        key={idx}
                        className="grid grid-cols-8 bg-neutral-200 h-fit"
                      >
                        <span className="col-span-1 flex justify-center items-center">
                          <Icons name="file" size={20} color="#005BA9" />
                        </span>
                        <span className="col-span-6 text-[#005BA9]">
                          <span className="line-clamp-1" title={file.name}>{file.name}</span>
                          <Typography
                            variant="xsmallcaption"
                            className="text-gray-500"
                          >
                            {/* ({Math.round(file.size / 1024)} KB) */}(
                            {formatFileSize(file.size)})
                          </Typography>
                        </span>
                        <span className="col-span-1 flex justify-center items-center">
                          <a href={fileURL} download={file.name}>
                            <Icons name="download" size={15} color="#005BA9" />
                          </a>
                        </span>
                      </span>
                    );
                  })}
                </Typography>
              )}
            </div>
          </Typography>
        </div>
      </div>
      <div className="flex justify-end gap-2 my-2.5">
        <Button
          variant="header04"
          label={common_labels.cancel}
          className="button px-3.5 py-1.5 rounded-lg bg-primary-50 text-[#005BA9]! hoverObj border-0"
          onClick={() => navigate(routes.home)}
        />
        <Button
          variant="header04"
          label={common_labels.submit}
          className="button px-3.5 py-1.5 rounded-lg bg-primary-600 hoverObj border-0"
          onClick={() => handleSubmit()}
        />
      </div>
      <MyModal
        show={errormodal.length > 0}
        onClose={() => setErrorModal([])}
        title="Please fix the Issues"
        isItFullScreen={false}
      >
        <ul>
          {errormodal.map((error, index) => (
            <Typography
              key={index}
              variant="bodyregular"
              as="li"
              className="list-disc text-white"
            >
              {error}
            </Typography>
          ))}
        </ul>
      </MyModal>
      {isLoading && <Loading varient={true} />}
    </>
  );
};

export default ModulesRequest;
