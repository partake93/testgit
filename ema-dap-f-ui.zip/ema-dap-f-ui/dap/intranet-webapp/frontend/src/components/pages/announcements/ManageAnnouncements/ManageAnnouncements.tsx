import * as React from "react";
import * as service from "../../../../services/announcementsService";
import Typography from "../../../atoms/typography/Typography";
import SectionHeader from "../../../Organisms/SectionHeader";
import {
  announcements,
  announcementStatus,
  announcementStatusList,
  sortAnnouncement,
} from "../../../../types/Announcement";
import { formatDate } from "../../../../utils/date";
import StatusTag from "../../../molecules/StatusTag/StatusTag";
import Icons from "../../../atoms/Icons/Icons";
import { useNavigate } from "react-router-dom";
import { routes } from "../../../../utils/routes";
import Pagination from "../../../Organisms/Pagination";
import { APIerror } from "../../../../types/Error";
import Loading from "../../../Organisms/Loading/Loading";
import { useErrorManager } from "../../../../utils/manageApiError";
import { useModalPopup } from "../../../../context/ModalPopupContext";
import {
  announcement_const,
  api_status,
  common_labels,
  error_const,
} from "../../../../utils/constants";
import Button from "../../../molecules/Button/Button";

const ManageAnnouncements = () => {
  const [announcementsList, setAnnouncementsList] = React.useState<
    announcements[]
  >([]);
  const [currentPage, setCurrentPage] = React.useState<number>(1);
  const [totalPages, setTotalPages] = React.useState<number>(1);
  const [isLoading, setLoading] = React.useState<boolean>(false);
  const [isLoading1, setIsLoading1] = React.useState<boolean>(false);

  const errorManager = useErrorManager();
  const navigate = useNavigate();
  const { showModal } = useModalPopup();

  const getAnnouncementsList = async () => {
    try {
      setLoading(true);
      const res = await service.getAnnouncementsList(currentPage);
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      if (!res.data || res.data.length === 0) {
        // showModal({message: "No announcements available",title: "info"});
        setAnnouncementsList([]);
        setTotalPages(1);
        return;
      }
      setTotalPages(res.total_pages || 1);
      setAnnouncementsList(sortTheList(res.data));
    } catch (error) {
      errorManager(error as Error | APIerror);
    }

    setLoading(false);
  };

  React.useEffect(() => {
    getAnnouncementsList();
  }, [currentPage]);

  const sortTheList = (data: announcements[]) => {
    // const data: announcementList[] = [...announcementsList];
    if (data.length > 0) {
      let sort: announcements[] = data.sort(
        (a, b) =>
          announcementStatusList.indexOf(a.status) -
          announcementStatusList.indexOf(b.status)
      );
      sort = sort.sort((a, b) => {
        if (
          a.status == announcementStatus.published &&
          b.status == announcementStatus.published
        ) {
          // if(a.order_index && b.order_index)
          return a.order_index - b.order_index;
        }
        return 0;
      });
      return sort;
    }
    return data;
  };

  const changeIndex = (action: string, index: number) => {
    const updates: sortAnnouncement[] = [];
    const updatedList = [...announcementsList];
    if (action == common_labels.up) {
      if (index != 0) {
        const topRowIndex = index - 1;
        if (
          updatedList[index]?.order_index &&
          updatedList[topRowIndex]?.order_index
        ) {
          const orderIndex = updatedList[index].order_index;
          const topRowOrderIndex = updatedList[topRowIndex].order_index;
          updatedList[index].order_index = topRowOrderIndex;
          updatedList[topRowIndex].order_index = orderIndex;
          updates.push({
            announcement_id: updatedList[index].id + "",
            newIndex: topRowOrderIndex,
          });
          updates.push({
            announcement_id: updatedList[topRowIndex].id + "",
            newIndex: orderIndex,
          });
        }
      }
    } else {
      if (
        index + 1 !=
        updatedList.filter((x) => x.status == announcementStatus.published)
          .length
      ) {
        const bottomRowIndex = index + 1;
        if (
          updatedList[index].order_index != undefined &&
          updatedList[bottomRowIndex].order_index != undefined
        ) {
          const orderIndex = updatedList[index].order_index;
          const bottomRowOrderIndex = updatedList[bottomRowIndex].order_index;
          updatedList[index].order_index = bottomRowOrderIndex;
          updatedList[bottomRowIndex].order_index = orderIndex;
          updates.push({
            announcement_id: updatedList[index].id + "",
            newIndex: bottomRowOrderIndex,
          });
          updates.push({
            announcement_id: updatedList[bottomRowIndex].id + "",
            newIndex: orderIndex,
          });
        }
      }
    }
    if (updates.length === 2) {
      updateAnnouncements(updates, updatedList);
    }
  };

  const updateAnnouncements = async (
    updates: sortAnnouncement[],
    updatedList: announcements[]
  ) => {
    try {
      setIsLoading1(true);
      const res = await service.sortAnnouncements({ updates: updates });
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      setAnnouncementsList(sortTheList([...updatedList]));
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading1(false);
    }
  };

  const isButtonDisabled = (action: string, index: number) => {
    let disabled: boolean = false;
    if (action == common_labels.up) {
      disabled = index == 0;
    } else {
      disabled =
        index + 1 ==
        announcementsList.filter(
          (x) => x.status == announcementStatus.published
        ).length;
    }
    return disabled;
  };

  const navigator = (type: string, id?: number) => {
    if (type == common_labels.add) {
      navigate(routes.addAnnouncements);
    } else {
      navigate(`${routes.announcementsManagement}/${id}`);
    }
  };

  const handlePageChange = (pageNumber: number) => {
    if (pageNumber !== currentPage) {
      setCurrentPage(pageNumber);
    }
  };

  return (
    <>
      <SectionHeader
        title={announcement_const.manageAnnouncements}
        hasNavigation={true}
        navigateTo={routes.home}
        variant="header01"
        hasButton={true}
        className="text-white"
        button={{
          label: announcement_const.add,
          variant: "lead02",
          hasBorder: false,
          hasIcon: true,
          iconOnLeft: true,
          className: "text-secondary-04",
          icon: { name: "plusWithCircle", color: "#57B4FF", size: 20 },
          onClick: () => navigator(common_labels.add),
        }}
      />
      {isLoading ? (
        <Loading isFullPage={false} className="min-h-60!" />
      ) : (
        <div className="w-full overflow-x-auto">
          <div className="overflow-x-auto table w-full text-white">
            <table>
              <thead>
                <tr>
                  <th></th>
                  <th>
                    <Typography variant="lead02" as="span">
                      Announcement Title
                    </Typography>
                  </th>
                  <th>
                    <Typography variant="lead02" as="span">
                      Created/Modified by
                    </Typography>
                  </th>
                  <th>
                    <Typography variant="lead02" as="span">
                      Start Date
                    </Typography>
                  </th>
                  <th>
                    <Typography variant="lead02" as="span">
                      End Date
                    </Typography>
                  </th>
                  <th>
                    <Typography variant="lead02" as="span">
                      Status
                    </Typography>
                  </th>
                  <th>
                    <Typography variant="lead02" as="span">
                      Action
                    </Typography>
                  </th>
                </tr>
              </thead>
              <tbody className="max-h-2/3 overflow-y-auto">
                {announcementsList.length > 0 &&
                  announcementsList.map((x, i) => {
                    return (
                      <tr key={i}>
                        <td className="p-0!">
                          {x.status == announcementStatus.published && (
                            <div className="flex flex-col">
                              <button
                                className="cursor-pointer m-1"
                                onClick={() => {
                                  if (!isButtonDisabled(common_labels.up, i)) {
                                    changeIndex(common_labels.up, i);
                                  }
                                }}
                              >
                                <Icons
                                  name="upArrow"
                                  size={8}
                                  color={
                                    isButtonDisabled(common_labels.up, i)
                                      ? "#ffffff80"
                                      : "#fff"
                                  }
                                />
                              </button>
                              <button
                                className="cursor-pointer m-1"
                                onClick={() => {
                                  if (
                                    !isButtonDisabled(common_labels.down, i)
                                  ) {
                                    changeIndex(common_labels.down, i);
                                  }
                                }}
                              >
                                <Icons
                                  name="downArrow"
                                  size={8}
                                  color={
                                    isButtonDisabled(common_labels.down, i)
                                      ? "#ffffff80"
                                      : "#fff"
                                  }
                                />
                              </button>
                            </div>
                          )}
                        </td>
                        <td>
                          <Typography variant="label01" as="span">
                            {/* {x.title} */}
                            <span
                              dangerouslySetInnerHTML={{ __html: x.title }}
                            ></span>
                          </Typography>
                        </td>
                        <td>
                          <Typography variant="label01" as="span">
                            {x.first_name} {x.last_name}
                          </Typography>
                        </td>
                        <td>
                          <Typography variant="label01" as="span">
                            {formatDate(x.start_date)}
                          </Typography>
                        </td>
                        <td>
                          <Typography variant="label01" as="span">
                            {formatDate(x.end_date)}
                          </Typography>
                        </td>
                        <td>
                          <StatusTag
                            label={x.status.toLocaleUpperCase()}
                            variant="smallcaption"
                            className={getBGcolor(x.status) + " px-0.5"}
                          />
                        </td>
                        <td>
                          <Button
                            variant="label01"
                            className="text-secondary-04"
                            label={getButtonLabel(x.status)}
                            hasBorder={false}
                            hasIcon={true}
                            iconOnLeft={false}
                            isActive={true}
                            icon={{
                              name: "arrowRight",
                              color: "#57B4FF",
                              size: 10,
                            }}
                            onClick={() => navigator(common_labels.view, x.id)}
                          />
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}
      <Pagination
        page={{ current_page: currentPage, total_pages: totalPages }}
        handlePageChange={handlePageChange}
      />
      {isLoading1 && <Loading varient={true} />}
    </>
  );
};

export default ManageAnnouncements;

const getButtonLabel = (status: string) => {
  if (announcementStatus.published == status) {
    return common_labels.review;
  } else if (
    announcementStatus.programmed == status ||
    announcementStatus.draft == status
  ) {
    return common_labels.edit;
  } else {
    return common_labels.view;
  }
};

const getBGcolor = (status: string) => {
  if (announcementStatus.published == status) {
    return "bg-success-500";
  } else if (announcementStatus.programmed == status) {
    return "bg-secondary-04 text-black";
  } else if (announcementStatus.draft == status) {
    return "bg-status-yellow-500 text-black";
  } else {
    return "bg-secondary-01";
  }
};
