import * as React from "react";
import * as service from "../../../../services/announcementsService";
import { announcements, announcementStatus } from "../../../../types/Announcement";
import { useModalPopup } from "../../../../context/ModalPopupContext";
import { useErrorManager } from "../../../../utils/manageApiError";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { routes } from "../../../../utils/routes";
import { announcement_const, api_status, date_const, error_const } from "../../../../utils/constants";
import { formatDate } from "../../../../utils/date";
import { APIerror } from "../../../../types/Error";
import { modalString } from "../../../../utils/modal";
import Icons from "../../../atoms/Icons/Icons";
import Typography from "../../../atoms/typography/Typography";
import CustomDateRangePicker from "../../../molecules/CustomDateRangePicker/CustomDateRangePicker";
import MyEditor from "../../../molecules/MyEditor/MyEditor";
import MyModal from "../../../molecules/MyModal/MyModal";
import Loading from "../../../Organisms/Loading/Loading";
import SectionHeader from "../../../Organisms/SectionHeader";
import Button from "../../../molecules/Button/Button";
// import DateTimeRangePicker from "../../../molecules/DateTimeRangePicker/DateTimeRangePicker";

const AnnouncementForm = () => {
  const [selectedAnnouncement, setSelectedAnnouncement] =
    React.useState<announcements>();
  const [title, setTitle] = React.useState<string>("");
  const [startDate, setStartDate] = React.useState<string>("");
  const [endDate, setEndDate] = React.useState<string>("");
  const [description, setDescription] = React.useState<string>("");
  const [showError, setShowError] = React.useState<boolean>(false);
  const [showError1, setShowError1] = React.useState<boolean>(false);
  const [deleteModalShow, setDeleteModalShow] = React.useState<boolean>(false);
  const [errormodal, setErrorModal] = React.useState<string[]>([]);
  const [isLoading, setIsLoading] = React.useState<boolean>(false);

  const { showModal } = useModalPopup();
  const errorManager = useErrorManager();
  const location = useLocation();
  const isAddForm = React.useRef(true);
  const { announcementId } = useParams();
  const navigate = useNavigate();

  React.useEffect(() => {
    isAddForm.current = location.pathname.includes(routes.addAnnouncements);
    if (!isAddForm.current) {
      fetchAnnouncement();
    }
  }, [location.pathname, announcementId]);

  const fetchAnnouncement = async () => {
    try {
      setIsLoading(true);
      const res = await service.getAnnouncementsById(Number(announcementId));
      if (res.status === api_status.success && res.data) {
        setSelectedAnnouncement(res.data);
        setTitle(res.data.title);
        setDescription(res.data.text);
        setStartDate(formatDate(new Date(res.data.start_date)));
        setEndDate(formatDate(new Date(res.data.end_date)));
      } else {
        errorManager(
          new Error(
            `${announcement_const.announcementError}: ${res.message || error_const.apiError}`
          )
        );
      }
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading(false);
    }
  };

  const saveDate = (startDate: string, endDate: string) => {
    setStartDate(startDate);
    setEndDate(endDate);
  };

  const handleAnnouncements = (type: string) => {
    let errorDesc = false;
    let errorDate = false;

    if (description.trim() === "" || description === "<p></p>") {
      setErrorModal((prev) => [...prev, announcement_const.textError]);
      errorDesc = true;
    }else if (description.trim().length < 10) {
      setErrorModal((prev) => [
        ...prev,
        announcement_const.textError1,
      ]);
      errorDesc = true;
    }
    if (startDate === "" || endDate === "") {
      setErrorModal((prev) => [...prev, date_const.dateRequired]);
      errorDate = true;
    }
    if (startDate && endDate && new Date(startDate) > new Date(endDate)) {
      setErrorModal((prev) => [
        ...prev,
        date_const.startDateError,
      ]);
      errorDate = true;
    }

    setShowError(errorDesc);
    setShowError1(errorDate);

    if (errorDesc || errorDate) {
      return;
    }

    if (isAddForm.current) {
      addAnnouncements(type);
    } else {
      editAnnouncements(type);
    }
  };

  const addAnnouncements = async (type: string) => {
    try {
      setIsLoading(true);
      const res = await service.addAnnouncement({
        title: title,
        text: description,
        start_date: new Date(startDate),
        end_date: new Date(endDate),
        status: type,
        url: "   ",
      });

      if (res.status !== api_status.success) {
        showModal({message:`${error_const.failed}:  ${res.message || error_const.apiError}`, title:api_status.error});
        return;
      }
      if (res.status === api_status.success) {
        showModal({message: res.message, title: api_status.success});
        navigate(routes.announcementsManagement);
      }
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading(false);
    }
  };

  const editAnnouncements = async (type: string) => {
    try {
      setIsLoading(true);
      if (selectedAnnouncement) {
        const res = await service.editAnnouncement(
          {
            title: title,
            text: description,
            start_date: new Date(startDate),
            end_date: new Date(endDate),
            status: type,
            url: selectedAnnouncement?.url,
          },
          Number(announcementId)
        );
        if (res.status !== api_status.success) {
          showModal({message: `${error_const.failed}:  ${res.message || error_const.apiError}`, title:api_status.error});
          return;
        }
        if (res.status === api_status.success) {
          showModal({message: res.message, title: api_status.success});
          navigate(routes.announcementsManagement);
        }
      }
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading(false);
    }
  };

  const deleteAnnouncement = async () => {
    try {
      setIsLoading(true);
      const res = await service.deleteAnnouncement(Number(announcementId));
      if (res.status !== api_status.success) {
        showModal({message: `${error_const.failed}:  ${res.message || error_const.apiError}`, title:api_status.error});
        return;
      }
      if (res.status === api_status.success) {
        showModal({message: res.message, title: api_status.success});
        navigate(routes.announcementsManagement);
      }
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading(false);
      setDeleteModalShow(false);
    }
  };

  return (
    <>
      <SectionHeader
        title={announcement_const.manageAnnouncements}
        hasNavigation={true}
        navigateTo={routes.announcementsManagement}
        variant="header01"
        hasButton={false}
        className="text-white"
      />
      <div className="text-white px-3.5 py-2.5 border-2 bg-[#8AB6EA1A] rounded-xl">
        <div className="grid grid-cols-1 md:grid-cols-8 items-center gap-2 md:gap-4">
          <span className="md:col-span-2">
            <Typography
              variant="lead02"
              as="span"
              className="flex items-center"
            >
              Announcement title
              <span className="p-1 cursor-pointer">
                <Icons name="questionMark" size={15} />
              </span>
            </Typography>
          </span>
          <span className="md:col-span-6 w-full">
            <MyEditor
              onUpdate={(content) => setTitle(content)}
              value={title}
              {...(selectedAnnouncement && {
                isActive: !(
                  selectedAnnouncement.status.toLocaleLowerCase() ===
                  announcementStatus.expired
                ),
              })}
            />
          </span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-8 items-center gap-2 md:gap-4">
          <span className="md:col-span-2">
            <Typography
              variant="lead02"
              as="span"
              className="flex items-center"
            >
              Announcement text*
              <span className="p-1 cursor-pointer">
                <Icons name="questionMark" size={15} />
              </span>
            </Typography>
          </span>
          <span className="md:col-span-6 w-full">
            <MyEditor
              CHARACTER_LIMIT={300}
              onUpdate={(content) => setDescription(content)}
              value={description}
              showError={showError}
              {...(selectedAnnouncement && {
                isActive: !(
                  selectedAnnouncement.status.toLocaleLowerCase() ===
                  announcementStatus.expired
                ),
              })}
            />
          </span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-8 items-center gap-2 md:gap-4 my-1.5">
          <span className="md:col-span-2">
            <Typography
              variant="lead02"
              as="span"
              className="flex items-center"
            >
              Custom Live time & date*
              <span className="p-1 cursor-pointer">
                <Icons name="questionMark" size={15} />
              </span>
            </Typography>
          </span>
          <span className="md:col-span-6 w-full">
            <Typography variant="bodyregular" as="span">
              <CustomDateRangePicker
                saveDate={saveDate}
                start_date={startDate}
                end_date={endDate}
                clearDate={() => {
                  setStartDate("");
                  setEndDate("");
                }}
                showError={showError1}
                {...(selectedAnnouncement && {
                  isActive: !(
                    selectedAnnouncement.status.toLocaleLowerCase() ===
                    announcementStatus.expired
                  ),
                })}
                allowPastDates={false}
              />
              {/* <DateTimeRangePicker onChange={() => {}} /> */}
            </Typography>
          </span>
        </div>
        <div className="border-t-1 pt-1.5">
          <SectionHeader
            title="Preview"
            variant="header03"
            hasNavigation={false}
            hasButton={false}
          />
          <div className="w-full shadow-md bg-white text-black rounded-md px-[1rem] py-[0.75rem] min-h-30">
            <div className="w-full">
              <Typography
                variant="header02"
                as="span"
                className="line-clamp-1 leading-[120%] space-y-[1px] tracking-[0%]"
              >
                <span dangerouslySetInnerHTML={{ __html: title }}></span>
              </Typography>
              <Typography
                variant="bodyregular"
                as="span"
                className="line-clamp-3 pt-[0.25rem]"
              >
                <span dangerouslySetInnerHTML={{ __html: description }}></span>
              </Typography>
            </div>
          </div>
          <div className="flex flex-col md:flex-row justify-between my-2.5 gap-3 md:gap-0">
            <div className="flex gap-2 justify-center md:justify-start">
              <Button
                label="Cancel"
                variant="header04"
                hasBorder={false}
                hasIcon={false}
                isActive={true}
                onClick={() => navigate(routes.announcementsManagement)}
                className="rounded-full! px-6.5 py-1.5 bg-[#DAE8FB] text-primary-400"
              />
              <Button
                variant="header04"
                hasBorder={false}
                isActive={!isAddForm.current}
                hasIcon={true}
                icon={{ name: "trash", size: 12, color: "#005BA9" }}
                onClick={() => setDeleteModalShow(true)}
                className="rounded-full! px-1.5 py-[0.5rem] bg-[#DAE8FB]"
              />
            </div>
            <div className="flex gap-2 justify-center md:justify-end">
              <Button
                label="Save as Draft"
                variant="header04"
                hasBorder={false}
                hasIcon={false}
                isActive={
                  selectedAnnouncement?.status !== announcementStatus.expired
                }
                onClick={() => handleAnnouncements(announcementStatus.draft)}
                className="rounded-full! px-6.5 py-1.5 bg-[#DAE8FB] text-primary-400"
              />
              <Button
                label="Save and Publish"
                variant="header04"
                hasBorder={false}
                hasIcon={false}
                isActive={
                  selectedAnnouncement?.status !== announcementStatus.expired
                }
                onClick={() =>
                  handleAnnouncements(announcementStatus.published)
                }
                className="rounded-full! px-6.5 py-1.5 bg-primary-400 text-white"
              />
            </div>
          </div>
        </div>
        <MyModal
          show={deleteModalShow}
          onClose={() => setDeleteModalShow(false)}
          title={modalString.announcementDeleteTitle}
          actionButtonLabel="Delete"
          action={deleteAnnouncement}
          isItFullScreen={true}
        >
          <span>{modalString.actionBody}</span>
        </MyModal>
        <MyModal
          show={errormodal.length > 0}
          onClose={() => setErrorModal([])}
          title="Please fix the Issues"
          isItFullScreen={true}
        >
          <ul>
            {errormodal.map((error, index) => (
              <Typography
                key={index}
                variant="bodyregular"
                as="li"
                className="list-disc"
              >
                {error}
              </Typography>
            ))}
          </ul>
        </MyModal>
      </div>
      {isLoading && <Loading varient={true} />}
    </>
  );
};

export default AnnouncementForm;