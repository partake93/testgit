import * as React from "react";
import * as service from "../../../../services/modulesService";
import {
  api_status,
  common_labels,
  error_const,
  modules_const,
} from "../../../../utils/constants";
import SectionHeader from "../../../Organisms/SectionHeader";
import { routes } from "../../../../utils/routes";
import Loading from "../../../Organisms/Loading/Loading";
import { ModuleRequestDetail } from "../../../../types/Modules";
import { useNavigate, useParams } from "react-router-dom";
import { useModalPopup } from "../../../../context/ModalPopupContext";
import { useErrorManager } from "../../../../utils/manageApiError";
import { APIerror } from "../../../../types/Error";
import Typography from "../../../atoms/typography/Typography";
import Icons from "../../../atoms/Icons/Icons";
import { formatDate } from "../../../../utils/date";
import Button from "../../../molecules/Button/Button";

const ModuleRequestDetails = () => {
  const [requestDetails, setRequestDetails] =
    React.useState<ModuleRequestDetail>();
  const [isLoading, setIsLoading] = React.useState<boolean>(false);

  const { showModal } = useModalPopup();
  const errorManager = useErrorManager();
  const navigate = useNavigate();
  const { requestId } = useParams();

  React.useEffect(() => {
    if (requestId) {
      fetchRequestDetails(Number(requestId));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [requestId]);

  const fetchRequestDetails = async (id: number) => {
    try {
      setIsLoading(true);
      const res = await service.getModuleRequestById(id);
      if (res.status === api_status.error) {
        showModal({
          message: `${modules_const.requestDetailsError}: ${
            res.message || "API Error"
          }`,
          title: api_status.error,
        });
      }
      setRequestDetails(res.data);
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAction = async (action: string) => {
    try {
      setIsLoading(true);
      const res = await service.moduleRequestAction(
        requestId ? Number(requestId) : 0,
        action
      );
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      showModal({
        message: `${modules_const.requestActionSuccess.replace(
          "{action}",
          action == common_labels.approve ? "approved" : "rejected"
        )}`,
        title: api_status.success,
      });
      if (res.status === api_status.success) {
        navigate(routes.moduleRequestList);
      }
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownload = async (filename: string) => {
    try {
      const { blob, filename: downloadedFilename } =
        await service.getFileByName(filename);
      if (!blob) {
        showModal({
          message: `${error_const.failed}: File not found`,
          title: api_status.error,
        });
        return;
      }
      // console.log("blob: ", blob);

      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", downloadedFilename);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      errorManager(error as Error | APIerror);
    }
  };

  const formatFileSize = (size: number) => {
    const i = Math.floor(Math.log(size) / Math.log(1024));
    return (
      (size / Math.pow(1024, i)).toFixed(1) +
      " " +
      ["B", "KB", "MB", "GB", "TB"][i]
    );
  };

  return (
    <>
      <SectionHeader
        title={modules_const.request}
        hasNavigation={true}
        navigateTo={routes.moduleRequestList}
        variant="header01"
        hasButton={false}
        className="text-white"
      />
      <div className="text-white px-3.5 py-2.5 border-2 bg-[#8AB6EA1A] rounded-xl">
        <div className="flex sm:flex-wrap flex-nowrap">
          <div className="flex flex-col sm:w-full w-6/10 gap-y-2 px-4">
            <div className="flex flex-col">
              <Typography variant="lead02">
                <strong>User</strong>
              </Typography>
              <Typography variant="label01">
                {requestDetails?.created_by_first_name}{" "}
                {requestDetails?.created_by_last_name}
              </Typography>
            </div>
            <div className="flex flex-col">
              <Typography variant="lead02">
                <strong>Purpose of Request</strong>
              </Typography>
              <Typography variant="label01">
                {requestDetails?.purpose}
              </Typography>
            </div>
            <div className="flex flex-col">
              <Typography variant="lead02">
                <strong>Justification / Use Case</strong>
              </Typography>
              <Typography variant="label01">
                {requestDetails?.justification}
              </Typography>
            </div>
            <div className="flex flex-col">
              <Typography variant="lead02">
                <strong>Supporting Documents</strong>
              </Typography>
              <Typography
                variant="label01"
                className="grid md:grid-cols-3 sm:grid-cols-2 grid-cols-[repeat(auto-fit,_minmax(167px,_1fr))] gap-1 w-full h-full overflow-y-auto p-2 max-h-40"
              >
                {requestDetails?.file_ids &&
                requestDetails.file_ids.length > 0 ? (
                  requestDetails.file_ids.map((file, idx) => (
                    <span
                      key={idx + "" + Math.random()}
                      className="grid grid-cols-8 bg-neutral-200 h-fit cursor-pointer"
                      role="button"
                      onClick={() => handleDownload(file.file_name)}
                    >
                      <span className="col-span-1 flex justify-center items-center">
                        <Icons name="file" size={20} color="#005BA9" />
                      </span>
                      <span className="col-span-6 text-[#005BA9]">
                        <span className="line-clamp-1" title={file.file_name}>
                        {file.file_name}</span>
                        <Typography
                          variant="xsmallcaption"
                          className="text-gray-500"
                        >
                          {/* ({Math.round(file.size / 1024)} KB) */}(
                          {formatFileSize(file.file_size)})
                        </Typography>
                      </span>
                      <span className="col-span-1 flex justify-center items-center">
                        <Icons name="download" size={15} color="#005BA9" />
                      </span>
                    </span>
                  ))
                ) : (
                  <Typography variant="label01">
                    No supporting documents provided.
                  </Typography>
                )}
              </Typography>
            </div>
          </div>
          <div className="flex flex-col w-full md:w-4/10 md:border-s-1 px-4 gap-2">
            <div className="flex flex-row items-center">
              <Typography variant="lead02" as="span" className="w-1/2">
                <strong>Request ID</strong>
              </Typography>
              <Typography variant="label01" as="span" className="px-1">
                {requestId}
              </Typography>
            </div>
            <div className="flex flex-row items-center">
              <Typography variant="lead02" className="w-1/2">
                <strong>Module/Tool</strong>
              </Typography>
              <Typography variant="label01" as="span" className="px-1">
                {requestDetails?.module_name}
              </Typography>
            </div>
            <div className="flex flex-row items-center">
              <Typography variant="lead02" as="span" className="w-1/2">
                <strong>Submitted Date</strong>
              </Typography>
              <Typography variant="label01" as="span" className="px-1">
                {requestDetails?.created_at &&
                  formatDate(requestDetails?.created_at)}
              </Typography>
            </div>
          </div>
        </div>
      </div>
      {requestDetails?.status === "Pending" ? (
        <>
          <div className="flex flex-nowrap gap-2 justify-end w-full my-2">
            <Button
              label={common_labels.reject}
              variant="header04"
              hasBorder={false}
              hasIcon={false}
              onClick={() => handleAction(common_labels.reject)}
              className="rounded-full! px-6.5 py-1.5 bg-[#DAE8FB] text-primary-400"
            />
            <Button
              label={common_labels.approve}
              variant="header04"
              hasBorder={false}
              hasIcon={false}
              onClick={() => handleAction(common_labels.approve)}
              className="rounded-full! px-6.5 py-1.5 bg-primary-400 text-white"
            />
          </div>
        </>
      ) : (
        <div className="flex flex-col items-end justify-center mt-4">
          <Typography variant="label01" className="text-gray-500">
            Request {requestDetails?.status.toLowerCase()}.
          </Typography>
        </div>
      )}
      {isLoading && <Loading varient={true} />}
    </>
  );
};

export default ModuleRequestDetails;
