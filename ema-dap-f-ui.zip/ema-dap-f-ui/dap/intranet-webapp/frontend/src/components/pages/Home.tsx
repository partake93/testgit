import Announcement from "../Organisms/Announcement/Announcement";
import ModulesGrid from "../templates/ModulesGrid/ModulesGrid";
import QuickActions from "../Organisms/QuickActions/QuickActions";

const Home = () => {
  return (
    <>
      <Announcement />
      <div className="flex flex-col md:flex-row gap-6 py-6 w-full">
        <div className="w-full md:w-3/5 lg:w-2/3 shadow-sm rounded-md">
          <ModulesGrid />
        </div>
        <div className="w-full md:w-2/5 lg:w-1/3 shadow-sm rounded-md">
          <QuickActions />
        </div>
      </div>
    </>
  );
};

export default Home;
