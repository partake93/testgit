import * as React from 'react';

const PageNotFound: React.FC<{}> = () => {
  return (
    <div className='flex justify-center text-white items-center h-full'>
      <h1>404: </h1>
      <h2>Oops! We can't seem to find the page you're looking for.</h2>
    </div>
  );
};
export default PageNotFound;