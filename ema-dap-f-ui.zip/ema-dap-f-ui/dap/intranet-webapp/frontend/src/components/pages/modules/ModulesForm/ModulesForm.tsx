import * as React from "react";
import * as service from "../../../../services/modulesService";
import { useLocation, useParams, useNavigate } from "react-router-dom";
import { APIerror } from "../../../../types/Error";
import { modules, Tag } from "../../../../types/Modules";
import {
  api_status,
  error_const,
  modules_const,
  common_labels,
} from "../../../../utils/constants";
import { isValidUrl } from "../../../../utils/functions";
import { useErrorManager } from "../../../../utils/manageApiError";
import { modalString } from "../../../../utils/modal";
import { routes } from "../../../../utils/routes";
import CustomMultiSelect from "../../../atoms/Dropdown/Dropdown";
import { isIconName, iconNameSet } from "../../../atoms/Icons/Icon";
import Icons from "../../../atoms/Icons/Icons";
import Typography from "../../../atoms/typography/Typography";
import MyModal from "../../../molecules/MyModal/MyModal";
import SectionHeader from "../../../Organisms/SectionHeader";
import ToggleButton from "../../../atoms/ToggleButton/ToggleButton";
import { useModalPopup } from "../../../../context/ModalPopupContext";
import InputBox from "../../../atoms/InputBox/InputBox";
import Button from "../../../molecules/Button/Button";
import Loading from "../../../Organisms/Loading/Loading";

type formFieldesValidation = {
  title: boolean;
  url: boolean;
  tooltip: boolean;
  comment?: boolean;
  category?: boolean;
};

const ModulesForm = () => {
  const [selectedModule, setSelectedModule] = React.useState<modules>();
  const [title, setTitle] = React.useState("");
  const [URL, setURL] = React.useState("");
  const [tooltip, setTooltip] = React.useState("");
  const [tagOptions, setTagOptions] = React.useState<Tag[]>([]);
  const [selectedTags, setSelectedTags] = React.useState<Tag[]>([]);
  const [defaultSts, setDefaultSts] = React.useState(true);
  const [selectedIcon, setSelectedIcon] = React.useState("");
  const [isChecked, setIsChecked] = React.useState<boolean>(false);
  const [comment, setComments] = React.useState("");
  const [modalShow, setModalShow] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(false);

  const [showError, setShowError] = React.useState<formFieldesValidation>({
    title: false,
    url: false,
    tooltip: false,
    category: false,
  });
  const [errormodal, setErrorModal] = React.useState<string[]>([]);

  const errorManager = useErrorManager();
  const { showModal } = useModalPopup();
  const isAddForm = React.useRef(true);
  const location = useLocation();
  const { moduleId } = useParams();
  const navigate = useNavigate();

  React.useEffect(() => {
    isAddForm.current = location.pathname.includes(routes.addModules);
    if (!isAddForm.current) {
      fetchModule();
    }
  }, [location.pathname, moduleId]);

  React.useEffect(() => {
    getTags();
  }, []);

  const getTags = async () => {
    try {
      const res = await service.getTagList();
      if (res.status !== api_status.success) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      if (!res.data || res.data.length === 0) {
        // showModal({message: modules_const.tagsNotFound, title: status_const.info});
        return;
      }
      setTagOptions(res.data);
    } catch (error) {
      errorManager(error as Error | APIerror);
    }
  };

  const fetchModule = async () => {
    try {
      setIsLoading(true);
      const res = await service.getModulesById(Number(moduleId));
      if (res.status !== api_status.success) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title,
        });
        return;
      }
      if (!res.data) {
        // showModal({message: modules_const.moduleNotFound, title: status_const.info});
        navigate(routes.modulesManagement);
        return;
      }
      setSelectedModule(res.data);
      setTitle(res.data.label ?? "");
      setURL(res.data.url ?? "");
      setTooltip(res.data.tooltip_text ?? "");
      setSelectedTags(res.data.tags ?? []);
      setDefaultSts(res.data.default_visible);
      setSelectedIcon(res.data.icon_name ?? "");
      setIsChecked(res.data.confirmation_step ?? false);
      setComments(res.data.confirmation_text ?? "");
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    const errorFields: formFieldesValidation = {
      title: false,
      url: false,
      tooltip: false,
      category: false,
    };
    const errormodal: string[] = [];
    if (title.trim() === "" || title.trim().length < 3) {
      errormodal.push(modules_const.titleError);
      errorFields.title = true;
    }
    if (!isValidUrl(URL)) {
      errorFields.url = true;
      errormodal.push(modules_const.urlError);
    }
    if (tooltip.trim() === "") {
      errorFields.tooltip = true;
      errormodal.push(modules_const.tooltipError);
    }
    if (selectedTags.length === 0) {
      errorFields.category = true;
      errormodal.push(modules_const.categoryRequired);
    }
    if (!isIconName(selectedIcon)) {
      errormodal.push(modules_const.iconRequired);
    }
    if (isChecked && comment.trim() === "") {
      errormodal.push(modules_const.commentRequired);
      errorFields.comment = true;
    }

    setShowError(errorFields);
    setErrorModal(errormodal);

    if (errormodal.length > 0) {
      return;
    } else {
      if (isAddForm.current) {
        addModules();
      } else {
        editModules();
      }
    }
  };

  const addModules = async () => {
    try {
      setIsLoading(true);
      const res = await service.addModules({
        label: title,
        url: URL,
        tooltip_text: tooltip,
        tags: selectedTags.map((tag) => tag.id),
        default_visible: defaultSts,
        icon_name: isIconName(selectedIcon) ? selectedIcon : "package",
        confirmation_step: isChecked,
        confirmation_text: isChecked ? comment : "",
      });
      if (res.status !== api_status.success) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      if (res.status === api_status.success) {
        showModal({ message: res.message, title: api_status.success });
        navigate(routes.modulesManagement);
      }
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading(false);
    }
  };

  const editModules = async () => {
    try {
      setIsLoading(true);
      if (selectedModule) {
        const res = await service.editModule(
          {
            label: title,
            url: URL,
            tooltip_text: tooltip,
            tags: selectedTags.map((tag) => tag.id),
            default_visible: defaultSts,
            icon_name: isIconName(selectedIcon) ? selectedIcon : "package",
            confirmation_step: isChecked,
            confirmation_text: isChecked ? comment : "",
          },
          Number(moduleId)
        );
        if (res.status === api_status.error) {
          showModal({
            message: `${error_const.failed}: ${
              res.message || error_const.apiError
            }`,
            title: api_status.error,
          });
          return;
        }
        if (res.status === api_status.success) {
          showModal({ message: res.message, title: api_status.success });
          navigate(routes.modulesManagement);
        }
      }
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading(false);
    }
  };

  const deleteModule = async () => {
    try {
      setIsLoading(true);
      const res = await service.deleteModule(Number(moduleId));
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      if (res.status === api_status.success) {
        showModal({ message: res.message, title: api_status.success });
        navigate(routes.modulesManagement);
      }
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading(false);
      setModalShow(false);
    }
  };

  const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setIsChecked(event.target.checked);
    if (!event.target.checked) {
      setComments("");
    }
  };

  return (
    <>
      <SectionHeader
        title={modules_const.manageModules}
        hasNavigation={true}
        navigateTo={routes.modulesManagement}
        variant="header01"
        hasButton={false}
        className="text-white"
      />
      <div className="text-white px-4 py-4 sm:px-8 md:px-15.5 md:py-2.5 border-2 flex flex-col gap-y-3 bg-[#8AB6EA1A] rounded-xl max-h-[90vh] overflow-auto w-full">
        {/* Responsive grid: 2 columns on md+, 1 column on mobile */}
        <div className="grid grid-cols-1 md:grid-cols-8 items-center gap-y-2 gap-x-4">
          <Typography
            variant="lead02"
            as="span"
            className="md:col-span-2 flex items-center"
          >
            Module title
            <span className="p-1 cursor-pointer">
              <Icons name="questionMark" size={15} />
            </span>
          </Typography>
          <span className="w-full md:col-span-6">
            <InputBox
              name={`titleInputBox${Math.random()}`}
              error={showError.title}
              value={title ?? ""}
              onChange={(e) => setTitle(e.target.value)}
              className="bg-[#8AB6EA1A] border-gray-300 border-1 rounded-md w-full py-1.5 px-2.5"
            />
          </span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-8 items-center gap-y-2 gap-x-4">
          <Typography
            variant="lead02"
            as="span"
            className="md:col-span-2 flex items-center"
          >
            Link URL
            <span className="p-1 cursor-pointer">
              <Icons name="questionMark" size={15} />
            </span>
          </Typography>
          <span className="w-full md:col-span-6">
            <InputBox
              name={`urlInputBox${Math.random()}`}
              error={showError.url}
              value={URL ?? ""}
              onChange={(e) => setURL(e.target.value)}
              className="bg-[#8AB6EA1A] border-gray-300 border-1 rounded-md w-full py-1.5 px-2.5"
            />
          </span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-8 items-center gap-y-2 gap-x-4">
          <Typography
            variant="lead02"
            as="span"
            className="md:col-span-2 flex items-center"
          >
            Tooltip
            <span className="p-1 cursor-pointer">
              <Icons name="questionMark" size={15} />
            </span>
          </Typography>
          <span className="w-full md:col-span-6">
            <InputBox
              name={`tooltipInputBox${Math.random()}`}
              error={showError.tooltip} message="Tooltip is required"
              value={tooltip ?? ""}
              onChange={(e) => setTooltip(e.target.value)}
              isInput={false}
              className="bg-[#8AB6EA1A] border-gray-300 border-1 rounded-md w-full py-1.5 px-2.5"
              maxLength={30}
            />
          </span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-8 items-center gap-y-2 gap-x-4">
          <Typography
            variant="lead02"
            as="span"
            className="md:col-span-2 flex items-center"
          >
            Category
            <span className="p-1 cursor-pointer">
              <Icons name="questionMark" size={15} />
            </span>
          </Typography>
          <Typography
            variant="bodyregular"
            as="span"
            className="w-full md:col-span-6"
          >
            <CustomMultiSelect<Tag>
              options={tagOptions}
              selected={selectedTags}
              onChange={setSelectedTags}
              getId={(tag) => tag.id}
              getLabel={(tag) => tag.label}
              error={showError.category}
            />
          </Typography>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-8 items-center gap-y-2 gap-x-4">
          <Typography
            variant="lead02"
            as="span"
            className="md:col-span-2 flex items-center"
          >
            Default
            <span className="p-1 cursor-pointer">
              <Icons name="questionMark" size={15} />
            </span>
          </Typography>
          <Typography
            variant="bodyregular"
            as="span"
            className="w-full md:col-span-6"
          >
            <ToggleButton value={defaultSts} onChange={setDefaultSts} />
          </Typography>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-8 items-center gap-y-2 gap-x-4">
          <Typography
            variant="lead02"
            as="span"
            className="md:col-span-2 flex items-center"
          >
            Icon
            <span className="p-1 cursor-pointer">
              <Icons name="questionMark" size={15} />
            </span>
          </Typography>
          <span className="w-full md:col-span-6">
            <span className="flex flex-wrap gap-1.5 max-h-32 overflow-auto">
              {Array.from(iconNameSet).map((x) => (
                <Button
                  key={x}
                  hasBorder={false}
                  hasIcon={true}
                  icon={{ name: x, size: 20, color: "#005BA9" }}
                  onClick={() => setSelectedIcon(x)}
                  className={`px-0.5 py-1.5 bg-[#DAE8FB] rounded-full! hover:opacity-100! ${
                    selectedIcon == x ? "opacity-100" : "opacity-50"
                  }`}
                />
              ))}
            </span>
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-8 items-center gap-y-2 gap-x-4">
          <span className="md:col-span-2"></span>
          <Typography
            variant="bodyregular"
            as="span"
            className="w-full md:col-span-6 flex items-center gap-2"
          >
            <input
              type="checkbox"
              checked={isChecked}
              onChange={handleCheckboxChange}
              name="confirmationStepCheckbox"
              className="cursor-pointer"
              id="confirmationStepCheckbox"
              data-testid="confirmationStepCheckbox"
            />
            <label htmlFor="confirmationStepCheckbox">
              <span className="flex items-center cursor-pointer">
                Add Confirmation Step
                <span className="p-1 cursor-pointer">
                  <Icons name="questionMark" size={15} />
                </span>
              </span>
            </label>
          </Typography>
        </div>
        {isChecked && (
          <div className="grid grid-cols-1 md:grid-cols-8 items-center gap-y-2 gap-x-4">
            <span className="md:col-span-2"></span>
            <span className="md:col-span-6">
              <InputBox
                name={`commentInputBox${Math.random()}`}
                className="bg-[#8AB6EA1A] border-gray-300 border-1 rounded-md w-full py-1.5 px-2.5"
                placeholder="Add Comments"
                value={comment ?? ""}
                error={showError.comment ?? false}
                onChange={(e) => setComments(e.target.value)}
              />
            </span>
          </div>
        )}
        {/* Action buttons */}
        <div className="flex flex-col md:flex-row justify-between my-2.5 gap-2">
          <div className="flex gap-2 sm:justify-end">
            <Button
              label={common_labels.cancel}
              variant="header04"
              hasBorder={false}
              hasIcon={false}
              isActive={true}
              onClick={() => navigate(routes.modulesManagement)}
              className="rounded-full! px-6.5 py-1.5 bg-[#DAE8FB] text-primary-400"
            />
            <Button
              variant="header04"
              hasBorder={false}
              isActive={!isAddForm.current}
              hasIcon={true}
              icon={{ name: "trash", size: 12, color: "#005BA9" }}
              onClick={() => setModalShow(true)}
              className="rounded-full! px-1.5 py-[0.5rem] bg-[#DAE8FB]"
            />
          </div>
          <div className="flex gap-2 sm:justify-end">
            <Button
              label={`${
                isAddForm.current ? common_labels.publish : common_labels.update
              } Module`}
              variant="header04"
              hasBorder={false}
              hasIcon={false}
              onClick={() => handleSave()}
              className="rounded-full! px-6.5 py-1.5 bg-primary-400 text-white"
            />
          </div>
        </div>
        {/* Modals */}
        <MyModal
          show={modalShow}
          onClose={() => setModalShow(false)}
          title={modalString.moduleDeleteTitle}
          actionButtonLabel={common_labels.delete}
          action={deleteModule}
          isItFullScreen={true}
        >
          <span>{modalString.actionBody}</span>
        </MyModal>
      </div>
      <MyModal
        show={errormodal.length > 0}
        onClose={() => setErrorModal([])}
        title="Please fix the Issues"
        isItFullScreen={true}
      >
        <ul>
          {errormodal.map((error, index) => (
            <Typography
              key={index}
              variant="bodyregular"
              as="li"
              className="list-disc text-white"
            >
              {error}
            </Typography>
          ))}
        </ul>
      </MyModal>
          {isLoading && (
            <Loading varient={true} />
          )}
    </>
  );
};

export default ModulesForm;
