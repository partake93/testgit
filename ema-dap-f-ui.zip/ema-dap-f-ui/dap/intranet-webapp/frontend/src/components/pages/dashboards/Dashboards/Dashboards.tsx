import * as React from "react";
import * as service from "../../../../services/dashboardService";
import { useNavigate } from "react-router-dom";
import { useModalPopup } from "../../../../context/ModalPopupContext";
import { useUserContext } from "../../../../context/UserContext";
import { Dashboard, Category } from "../../../../types/Dashboards";
import { APIerror } from "../../../../types/Error";
import {
  common_labels,
  api_status,
  error_const,
  dashboard_const,
} from "../../../../utils/constants";
import { useErrorManager } from "../../../../utils/manageApiError";
import { routes } from "../../../../utils/routes";
import DashboardTile from "../../../molecules/DashboardTile/DashboardTile";
import Loading from "../../../Organisms/Loading/Loading";
import SectionHeader from "../../../Organisms/SectionHeader";
import Button from "../../../molecules/Button/Button";

const Dashboards = () => {
  const [selectedFilter, setSelectedFilter] = React.useState<string>("");
  const [dashboardsList, setDashboardsList] = React.useState<Dashboard[]>([]);
  const [allDashboardsList, setAllDashboardsList] = React.useState<Dashboard[]>(
    []
  );
  const [categories, setCategories] = React.useState<Category[]>([
    { id: 0, name: common_labels.all },
  ]);
  const [isLoading, setIsLoading] = React.useState<boolean>(false);
  const [isLoading1, setIsLoading1] = React.useState<boolean>(false);

  const { isAdmin } = useUserContext();

  const errorManager = useErrorManager();
  const navigate = useNavigate();
  const { showModal } = useModalPopup();

  React.useEffect(() => {
    getCategories();
    getDashboards();
  }, []);

  const getCategories = async () => {
    try {
      const res = await service.getCategories();
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      if (!res.data || res.data.length === 0) {
        // showModal({message: "No categories available",title: "info"});
        return;
      }
      const allCategory = [{ id: 0, name: common_labels.all }, ...res.data];
      setCategories(allCategory);
      setSelectedFilter(common_labels.all);
    } catch (error) {
      errorManager(error as Error | APIerror);
    }
  };

  const getDashboards = async () => {
    try {
      setIsLoading(true);
      const res = await service.getDashboardsList();
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      if (!res.data || res.data.length === 0) {
        // showModal({message: "No Dashboards available",title: "info"});
        setDashboardsList([]);
        setAllDashboardsList([]);
        return;
      }
      const dashboards = res.data.sort((a, b) => a.order_index - b.order_index);
      setDashboardsList(dashboards);
      setAllDashboardsList(dashboards);
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleStar = async (id: number) => {
    try {
      if (isLoading1) return; // Prevent multiple clicks
      setIsLoading1(true);
      const res = await service.starDashboard(id);
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      if (res.status === api_status.success) {
        const is_starred = allDashboardsList.find(
          (dashboard) => dashboard.id === id
        )?.is_starred;
        const updatedAllDashboards = [...allDashboardsList].map((dashboard) => {
          if (dashboard.id === id) {
            return { ...dashboard, is_starred: !dashboard.is_starred };
          }
          return dashboard;
        });
        const updatedDashboards = [...dashboardsList].map((dashboard) => {
          if (dashboard.id === id) {
            return { ...dashboard, is_starred: !dashboard.is_starred };
          }
          return dashboard;
        });
        setDashboardsList(updatedDashboards);
        setAllDashboardsList(updatedAllDashboards);
        showModal({
          message: is_starred
            ? dashboard_const.removeQuickActions
            : dashboard_const.addQuickActions,
          title: api_status.success,
        });
      }
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading1(false);
    }
  };

  const filterSelect = (value: string) => {
    setSelectedFilter(value);
    if (value === common_labels.all) {
      setDashboardsList([...allDashboardsList]);
      return;
    }
    const filtered = allDashboardsList.filter((x) =>
      x.categories.some((category) => category.name === value)
    );
    setDashboardsList(filtered);
  };

  return (
    <>
      <SectionHeader
        title={dashboard_const.dashboards}
        hasNavigation={true}
        navigateTo={routes.home}
        variant="header01"
        hasButton={true}
        className="text-white"
        {...(isAdmin && {
          button: {
            label: dashboard_const.manageDashboards,
            onClick: () => navigate(routes.dashboardsManagement),
            variant: "header04",
            isActive: true,
            isDark: true,
            hasBorder: true,
            hasIcon: true,
            icon: { name: "gear", size: 10 },
            iconOnLeft: true,
            className: "button px-[1rem] py-0.5",
          },
        })}
      />
      {isLoading ? (
        <Loading isFullPage={false} className="h-90!" />
      ) : (
        <>
          <div className="flex flex-wrap gap-2 text-white my-2.5">
            {categories.map((x: Category) => (
              <Button
                key={x.id}
                variant="captionregular"
                onClick={() => filterSelect(x.name)}
                label={x.name}
                hasBorder={true}
                hasIcon={false}
                isActive={true}
                isDark={true}
                className={`button px-1.5 py-0.5 ${
                  selectedFilter == x.name && "selected"
                }`}
              />
            ))}
          </div>
          {dashboardsList && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {dashboardsList.length > 0 ? (
                dashboardsList.map((x: Dashboard) => {
                  return (
                    <DashboardTile
                      key={x.id}
                      dashboard={x}
                      starFunc={toggleStar}
                    />
                  );
                })
              ) : (
                <div className="text-white p-4">
                  {dashboard_const.dashboardNotFound} for selected category.
                </div>
              )}
            </div>
          )}
        </>
      )}
      {isLoading1 && <Loading varient={true} />}
    </>
  );
};

export default Dashboards;
