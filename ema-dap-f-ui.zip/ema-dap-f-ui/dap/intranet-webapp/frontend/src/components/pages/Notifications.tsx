import * as React from "react";
import * as service from "../../services/notificationsService";
import Pagination from "../Organisms/Pagination";
import { Notification } from "../../types/Notification";
import SectionHeader from "../Organisms/SectionHeader";
import Loading from "../Organisms/Loading/Loading";
import Typography from "../atoms/typography/Typography";
import { formatDate } from "../../utils/date";
import StatusTag from "../molecules/StatusTag/StatusTag";
import { useErrorManager } from "../../utils/manageApiError";
import CustomDateRangePicker from "../molecules/CustomDateRangePicker/CustomDateRangePicker";
import Icons from "../atoms/Icons/Icons";
import PopOver from "../Organisms/PopOver";
import { useModalPopup } from "../../context/ModalPopupContext";
import {
  api_status,
  common_labels,
  error_const,
  notification_const,
  status_const,
} from "../../utils/constants";
import Button from "../molecules/Button/Button";
import { useNavigate } from "react-router-dom";
import { routes } from "../../utils/routes";

const Notifications = () => {
  const [notifications, setNotifications] = React.useState<Notification[]>([]);
  const [allNotifications, setAllNotifications] = React.useState<
    Notification[]
  >([]);
  const [expandedRowId, setExpandedRowId] = React.useState<number | null>(null);
  const [expandedSubItemIds, setExpandedSubItemIds] = React.useState<{
    [notificationId: number]: string | null;
  }>({});

  const [notViewedOnly, setNotViewedOnly] = React.useState(false);
  const [classifications] = React.useState<string[]>([
    common_labels.all,
    "warning",
    "need attention",
    "information",
  ]);
  const [selectedClassification, setSelectedClassification] =
    React.useState<string>(common_labels.all);
  const [startDate, setStartDate] = React.useState("");
  const [endDate, setEndDate] = React.useState("");
  const [search, setSearch] = React.useState<string>("");

  const navigate = useNavigate();

  const { showModal } = useModalPopup();
  const [currentPage, setCurrentPage] = React.useState(1);
  const [totalPages, setTotalPages] = React.useState(1);
  const [isLoading, setLoading] = React.useState(false);
  const errorManager = useErrorManager();

  React.useEffect(() => {
    getNotifications();
  }, [currentPage, selectedClassification, startDate, endDate]);

  React.useEffect(() => {
    if (notViewedOnly) {
      const filteredNotifications = allNotifications.filter(
        (n) => n.is_viewed === false
      );
      setNotifications(filteredNotifications);
    } else {
      setNotifications(allNotifications);
    }
  }, [notViewedOnly, allNotifications]);

  const saveDate = (startDate: string, endDate: string) => {
    setStartDate(startDate);
    setEndDate(endDate);
  };

  const getNotifications = async () => {
    try {
      setLoading(true);
      const classificationFilter =
        selectedClassification === common_labels.all
          ? null
          : selectedClassification;
      const searchKey =
        search.trim() == "" ? null : search.trim();
      const start =
        startDate.trim() === "" ? null : new Date(startDate).toISOString();
      const end =
        endDate.trim() === "" ? null : new Date(endDate).toISOString();
      const res = await service.getNotifications(
        currentPage,
        classificationFilter,
        searchKey,
        start != null ? start : null,
        end != null ? end : null
      );
      if (res.status !== api_status.success) {
        errorManager(
          new Error(
            `${notification_const.failed}: ${
              res.message || error_const.apiError
            }`
          )
        );
        return;
      }
      if (!res.data || res.data.length === 0) {
        setNotifications([]);
        setTotalPages(1);
        return;
      }
      setNotifications(res.data);
      setAllNotifications(res.data);
      setTotalPages(res.total_pages || 1);
    } catch (error) {
      errorManager(error as Error);
    }
    setLoading(false);
  };

  const handleExpandRow = (notification: Notification) => {
    const isAlreadyOpen = expandedRowId === notification.id;
    setExpandedRowId(isAlreadyOpen ? null : notification.id);
    if (notification.is_viewed === false) {
      // Mark the notification as viewed
      service.markNotificationAsRead(notification.id);
      setNotifications((prev) =>
        prev.map((n) =>
          n.id === notification.id ? { ...n, is_viewed: true } : n
        )
      );
      setAllNotifications((prev) =>
        prev.map((n) =>
          n.id === notification.id ? { ...n, is_viewed: true } : n
        )
      );
    }
    if (notification.request_id && notification.request_id > 0) {
      navigate(`${routes.moduleRequest}${notification.request_id}`);
      return;
    }
    if (notification.classification.toLocaleLowerCase() === "need attention") {
      if (
        notification.error_log_id == null ||
        notification.error_log_id === undefined
      ) {
        showModal({
          message: notification_const.logNotFound,
          title: status_const.info,
        });
      }
    }
  };

  const handleExpandSubItem = (notificationId: number, subItemId: string) => {
    setExpandedSubItemIds((prev) => ({
      ...prev,
      [notificationId]: prev[notificationId] === subItemId ? null : subItemId,
    }));
  };

  const handlePageChange = (pageNumber: number) => {
    if (pageNumber !== currentPage) {
      setCurrentPage(pageNumber);
    }
  };

  const getNotificationText = (x: Notification) =>
    x.details == null ? `${x.error_code}` : x.details;

  return (
    <>
      <SectionHeader
        title={notification_const.notifications}
        hasNavigation={true}
        variant="header01"
        hasButton={false}
        className="text-white"
      />
      {isLoading ? (
        <Loading isFullPage={false} className="min-h-60!" />
      ) : (
        <>
          <div className="flex flex-col md:flex-row flex-wrap my-1.5 gap-2 items-stretch md:items-center text-white">
            <div className="flex gap-1 items-center px-1.5 py-0.5">
              <Button
                variant="captionregular"
                onClick={() => setNotViewedOnly(false)}
                label={common_labels.all}
                hasBorder={true}
                hasIcon={false}
                isActive={true}
                isDark={true}
                className={`button px-1.5 py-0.5 ${
                  !notViewedOnly && "selected"
                }`}
              />
              <Button
                variant="captionregular"
                onClick={() => setNotViewedOnly(true)}
                label="Not Viewed"
                hasBorder={true}
                hasIcon={false}
                isActive={true}
                isDark={true}
                className={`button px-1.5 py-0.5 ${
                  notViewedOnly && "selected"
                }`}
              />
            </div>

            <div className="flex gap-1 items-center border-s-2 px-1.5 py-0.5">
              {classifications.map((classification) => (
                <Button
                  key={classification}
                  variant="captionregular"
                  onClick={() => setSelectedClassification(classification)}
                  label={
                    classification.charAt(0).toUpperCase() +
                    classification.slice(1)
                  }
                  hasBorder={true}
                  hasIcon={false}
                  isDark={true}
                  className={`button px-1.5 py-0.5 ${
                    selectedClassification === classification && "selected"
                  }`}
                />
              ))}
            </div>
            <div className="flex gap-1 items-center border-s-2 px-1.5 py-0.5">
              <Typography
                variant="smallcaption"
                as="span"
                className="w-full md:min-w-60"
              >
                <CustomDateRangePicker
                  saveDate={saveDate}
                  start_date={startDate}
                  end_date={endDate}
                  isPill={true}
                  clearDate={() => {
                    setStartDate("");
                    setEndDate("");
                  }}
                />
              </Typography>
            </div>
            <div className="flex gap-1 items-center border-s-2 px-1.5 py-0.5">
              <Typography variant="smallcaption" as="span">
                <div className="flex items-center border rounded-full border-gray-600 w-full px-2">
                  <span
                    className="text-gray-400 mx-0.5"
                    role="button"
                    onClick={() => {
                      setCurrentPage(1);
                      getNotifications();
                    }}
                  >
                    <Icons name="search" size={12} />
                  </span>
                  <input
                    type="text"
                    placeholder="Search..."
                    value={search}
                    className="bg-transparent text-white placeholder-gray-400 focus:outline-none w-full py-0.5 pl-0 pr-3"
                    onChange={(e) => (setSearch(e.target.value))}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        setCurrentPage(1);
                        getNotifications();
                      }
                    }}
                  />
                </div>
              </Typography>
            </div>
            <div className="flex gap-1 items-center border-s-2 px-1.5 py-0.5">
              <PopOver
                trigger="hover"
                description={notification_const.clearFilterDesc}
                isTooltip={true}
              >
                <Button
                  variant="captionregular"
                  onClick={() => {
                    setCurrentPage(1);
                    setSelectedClassification(common_labels.all);
                    setNotViewedOnly(false);
                    setStartDate("");
                    setEndDate("");
                    setSearch("");
                    getNotifications();
                  }}
                  hasBorder={true}
                  hasIcon={true}
                  isActive={true}
                  icon={{
                    name: "clearFilter",
                    size: 15,
                  }}
                  className="button py-1 rounded-full"
                />
              </PopOver>
            </div>
          </div>
          <div className="w-full overflow-x-auto">
            <div className="overflow-x-auto table w-full text-white">
              <table className="min-w-[700px] w-full">
                <thead>
                  <tr>
                    <th></th>
                    <th>
                      <Typography variant="lead02" as="span">
                        Notification
                      </Typography>
                    </th>
                    <th>
                      <Typography variant="lead02" as="span">
                        File
                      </Typography>
                    </th>
                    <th>
                      <Typography variant="lead02" as="span">
                        Source File
                      </Typography>
                    </th>
                    <th>
                      <Typography variant="lead02" as="span">
                        Timestamp of Failure
                      </Typography>
                    </th>
                    <th>
                      <Typography variant="lead02" as="span">
                        Classification
                      </Typography>
                    </th>
                    <th>
                      <Typography variant="lead02" as="span">
                        Action
                      </Typography>
                    </th>
                  </tr>
                </thead>
                <tbody className="max-h-2/3 overflow-y-auto">
                  {notifications.length === 0 && (
                    <tr>
                      <td colSpan={7} className="text-center py-4">
                        <Typography variant="bodyregular" as="span">
                          {notification_const.notFound}
                        </Typography>
                      </td>
                    </tr>
                  )}
                  {notifications.length > 0 &&
                    notifications.map((x) => {
                      return (
                        <React.Fragment key={x.id}>
                          <tr>
                            <td>
                              {!x.is_viewed && (
                                <span className="red-dot"></span>
                              )}
                            </td>
                            <td colSpan={x.details !== null ? 3 : 1}>
                              <Typography
                                variant="lead01"
                                as="span"
                                className="flex items-center justify-start w-full"
                              >
                                {getNotificationText(x) === undefined ||
                                getNotificationText(x) === "undefined" ? (
                                  ""
                                ) : (
                                  <>
                                    <span>{getNotificationText(x)}</span>
                                    {x.details === null && (
                                      <span className="mx-2">
                                        <PopOver
                                          trigger="hover"
                                          isTooltip={true}
                                          description={`<strong>Error Description:</strong> ${
                                            x.error_desc + ""
                                          } <br> <strong>Module:</strong> ${
                                            x.data_module
                                          }`}
                                        >
                                          <Icons name="support" size={12} />
                                        </PopOver>
                                      </span>
                                    )}
                                  </>
                                )}
                              </Typography>
                            </td>
                            {x.details === null && (
                              <>
                                <td>
                                  <Typography variant="label01" as="span">
                                    {x.zip_file_name ? x.zip_file_name : "-"}
                                  </Typography>
                                </td>
                                <td>
                                  <Typography variant="label01" as="span">
                                    {x.source_file_name}
                                  </Typography>
                                </td>
                              </>
                            )}
                            <td>
                              <Typography variant="label01" as="span">
                                {formatDate(x.inserted_at)}
                              </Typography>
                            </td>
                            <td>
                              <StatusTag
                                label={x.classification.toLocaleUpperCase()}
                                variant="smallcaption"
                                className={getBGcolor(x.classification)}
                              />
                            </td>
                            <td>
                              <Button
                                variant="label01"
                                className="text-secondary-04"
                                label={common_labels.viewDetails}
                                hasBorder={false}
                                hasIcon={true}
                                iconOnLeft={false}
                                isActive={true}
                                icon={{
                                  name: "arrowRight",
                                  color: "#57B4FF",
                                  size: 10,
                                }}
                                onClick={() => {
                                  handleExpandRow(x);
                                }}
                              />
                            </td>
                          </tr>
                          {expandedRowId === x.id &&
                          x.classification.toLocaleLowerCase() !==
                            "need attention"
                            ? x.items &&
                              x.items.length > 0 && (
                                <tr>
                                  <td
                                    colSpan={7}
                                    className="p-2 bg-[#8AB6EA1A]"
                                  >
                                    <div className="overflow-x-auto table w-full text-white">
                                      <table>
                                        <thead>
                                          <tr>
                                            <th>
                                              <Typography
                                                variant="bodyregular"
                                                as="span"
                                              >
                                                Error Log Id
                                              </Typography>
                                            </th>
                                            <th>
                                              <Typography
                                                variant="bodyregular"
                                                as="span"
                                              >
                                                Error Code
                                              </Typography>
                                            </th>
                                            <th>
                                              <Typography
                                                variant="bodyregular"
                                                as="span"
                                              >
                                                Date
                                              </Typography>
                                            </th>
                                            <th>
                                              <Typography
                                                variant="bodyregular"
                                                as="span"
                                              >
                                                Description
                                              </Typography>
                                            </th>
                                            <th>
                                              <Typography
                                                variant="bodyregular"
                                                as="span"
                                              >
                                                Source File Name
                                              </Typography>
                                            </th>
                                            <th>
                                              <Typography
                                                variant="bodyregular"
                                                as="span"
                                              >
                                                Action
                                              </Typography>
                                            </th>
                                          </tr>
                                        </thead>
                                        <tbody className="max-h-2/3 overflow-y-auto">
                                          {x.items.map((y) => (
                                            <React.Fragment
                                              key={y.error_log_id}
                                            >
                                              <tr>
                                                <td className="rounded-0">
                                                  <Typography
                                                    variant="captionregular"
                                                    as="span"
                                                  >
                                                    {y.error_log_id}
                                                  </Typography>
                                                </td>
                                                <td>
                                                  <Typography
                                                    variant="captionregular"
                                                    as="span"
                                                  >
                                                    {y.error_code}
                                                  </Typography>
                                                </td>
                                                <td>
                                                  <Typography
                                                    variant="captionregular"
                                                    as="span"
                                                  >
                                                    {formatDate(y.inserted_at)}
                                                  </Typography>
                                                </td>
                                                <td>
                                                  <Typography
                                                    variant="captionregular"
                                                    as="span"
                                                  >
                                                    {y.error_desc}
                                                  </Typography>
                                                </td>
                                                <td>
                                                  <Typography
                                                    variant="captionregular"
                                                    as="span"
                                                  >
                                                    {y.source_file_name}
                                                  </Typography>
                                                </td>
                                                <td className="rounded-0">
                                                  <Button
                                                    variant="captionregular"
                                                    className="text-secondary-04"
                                                    label={
                                                      common_labels.viewDetails
                                                    }
                                                    hasBorder={false}
                                                    hasIcon={true}
                                                    iconOnLeft={false}
                                                    isActive={true}
                                                    icon={{
                                                      name: "arrowRight",
                                                      color: "#57B4FF",
                                                      size: 10,
                                                    }}
                                                    onClick={() =>
                                                      handleExpandSubItem(
                                                        x.id,
                                                        y.error_log_id
                                                      )
                                                    }
                                                  />
                                                </td>
                                              </tr>

                                              {expandedSubItemIds[x.id] ===
                                                y.error_log_id && (
                                                <tr>
                                                  <td
                                                    colSpan={6}
                                                    className="bg-[#3B3B3B] p-2"
                                                  >
                                                    <CreateTableByData
                                                      err_log_id={
                                                        y.error_log_id
                                                      }
                                                    />
                                                  </td>
                                                </tr>
                                              )}
                                            </React.Fragment>
                                          ))}
                                        </tbody>
                                      </table>
                                    </div>
                                  </td>
                                </tr>
                              )
                            : expandedRowId === x.id &&
                              x.error_log_id && (
                                <tr>
                                  <td
                                    colSpan={7}
                                    className="text-center bg-[#8AB6EA1A]"
                                  >
                                    <CreateTableByData
                                      err_log_id={x.error_log_id}
                                    />
                                  </td>
                                </tr>
                              )}
                        </React.Fragment>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
      <Pagination
        page={{ current_page: currentPage, total_pages: totalPages }}
        handlePageChange={handlePageChange}
      />
    </>
  );
};

export default Notifications;

const getBGcolor = (status: string) => {
  if ("need attention" == status.toLocaleLowerCase()) {
    return "bg-secondary-01 text-white";
  } else {
    return "bg-neutral-200 text-black";
  }
};

const CreateTableByData = ({ err_log_id }: { err_log_id: string }) => {
  const [data, setData] = React.useState<any[] | null>(null);
  const [keys, setKeys] = React.useState<string[]>([]);
  const errorManager = useErrorManager();

  React.useEffect(() => {
    // if (!err_log_id) return;

    const fetchDataByLogId = async () => {
      try {
        const res = await service.getNotificationById(err_log_id);
        if (res.status !== api_status.success) {
          errorManager(
            new Error(
              `${notification_const.failed}: ${
                res.message || error_const.apiError
              }`
            )
          );
          return;
        }
        if (!res.data || !res.data.notification) {
          errorManager(new Error(notification_const.notFound));
          return;
        }

        // Check if content is null or empty
        const content = res.data.notification.content;
        // content = '[{"id": 1, "error_log_id": "E12345", "error_code": "500", "inserted_at": "2023-10-01T12:00:00Z", "error_desc": "Internal server error", "source_file_name": "sourceFile1.js", "zip_file_name": "file1.zip", "data_module": "Module1", "classification": "Need Attention"}, {"id": 2, "error_log_id": "E67890", "error_code": "404", "inserted_at": "2023-10-02T12:30:00Z", "error_desc": "Not Found", "source_file_name": "sourceFile2.js", "zip_file_name": "file2.zip", "data_module": "Module2", "classification": "Resolved"}, {"id": 2, "error_log_id": "E67890", "error_code": "404", "inserted_at": "2023-10-02T12:30:00Z", "error_desc": "Not Found", "source_file_name": "sourceFile2.js", "zip_file_name": "file2.zip", "data_module": "Module2", "classification": "Resolved"}]';
        if (!content) {
          setData([]);
          setKeys([]);
          return;
        }

        const parsedData = JSON.parse(content);
        setData(parsedData);
        setKeys(Object.keys(parsedData[0])); // Assuming the first item defines the table columns
      } catch (error) {
        errorManager(error as Error);
      }
    };

    fetchDataByLogId();
  }, [err_log_id]);

  // If data is still null (loading) or content is empty, show loading or a fallback message
  if (data === null) {
    return <Loading isFullPage={false} className="min-h-40!" />;
  }

  if (data.length === 0) {
    return (
      <div className="text-center text-white">
        <Typography variant="bodyregular" as="span">
          {notification_const.logEmpty}
        </Typography>
      </div>
    );
  }

  return (
    <div
      className="overflow-auto text-white"
      style={{ maxWidth: `1200px`, maxHeight: `400px` }}
    >
      <table className="table-auto w-full border-collapse">
        <thead>
          <tr>
            {keys.map((key) => (
              <th key={key}>
                <Typography variant="bodyregular" as="span">
                  {key}
                </Typography>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => (
            <tr key={item.id || index}>
              {keys.map((key) => (
                <td key={key} className="rounded-0">
                  <Typography variant="captionregular" as="span">
                    {item[key]}
                  </Typography>
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
