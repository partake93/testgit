import * as React from "react";
import * as service from "../../../../services/dashboardService";
import { useModalPopup } from "../../../../context/ModalPopupContext";
import {
  Category,
  Dashboard,
  sortDashboards,
  DashboardUpdate,
} from "../../../../types/Dashboards";
import { APIerror } from "../../../../types/Error";
import {
  api_status,
  error_const,
  dashboard_const,
  common_labels,
} from "../../../../utils/constants";
import { isValidUrl } from "../../../../utils/functions";
import { useErrorManager } from "../../../../utils/manageApiError";
import { routes } from "../../../../utils/routes";
import CustomMultiSelect from "../../../atoms/Dropdown/Dropdown";
import Icons from "../../../atoms/Icons/Icons";
import InputBox from "../../../atoms/InputBox/InputBox";
import Typography from "../../../atoms/typography/Typography";
import MyModal from "../../../molecules/MyModal/MyModal";
import Loading from "../../../Organisms/Loading/Loading";
import SectionHeader from "../../../Organisms/SectionHeader";
import { formatDate } from "../../../../utils/date";
import Button from "../../../molecules/Button/Button";

type formFieldesValidation = {
  title: boolean;
  version: boolean;
  url: boolean;
  description: boolean;
  notes: boolean;
  categories: boolean;
};

const ManageDashboards = () => {
  const [categories, setCategories] = React.useState<Category[]>([]);
  const [formState, setFormState] = React.useState<Record<number, Dashboard>>(
    {}
  );
  const [showError, setShowError] = React.useState<formFieldesValidation>({
    description: false,
    notes: false,
    title: false,
    url: false,
    version: false,
    categories: false,
  });
  const [errormodal, setErrorModal] = React.useState<string[]>([]);
  const [dashboardList, setDashboardList] = React.useState<Dashboard[]>([]);
  const [expandedRowId, setExpandedRowId] = React.useState<number | null>(null);
  const [isLoading, setLoading] = React.useState(false);
  const [loading2, setLoading2] = React.useState(false);

  const TEMP_ID = Number.MIN_SAFE_INTEGER;

  const { showModal } = useModalPopup();
  const errorManager = useErrorManager();

  const getDashboardList = async () => {
    try {
      setLoading(true);
      const res = await service.getDashboardsList();
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      if (!res.data || res.data.length === 0) {
        // showModal({ message: "No dashboards available", title: "info" });
        return;
      }
      setDashboardList(sortTheList(res.data));
    } catch (error) {
      errorManager(error as APIerror);
    } finally {
      setLoading(false);
    }
  };

  const getCategories = async () => {
    try {
      setLoading(true);
      const res = await service.getCategories();
      if (res.status === api_status.error) {
        showModal({
          message: `${dashboard_const.categoriesFailed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      if (!res.data || res.data.length === 0) {
        // showModal({ message: "No Categories available", title: "info" });
        return;
      }
      setCategories(res.data);
    } catch (error) {
      errorManager(error as APIerror);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    getDashboardList();
    getCategories();
  }, []);

  const sortTheList = (data: Dashboard[]) => {
    if (data.length > 0) {
      const sort: Dashboard[] = [...data].sort(
        (a, b) => a.order_index - b.order_index
      );
      return sort;
    }
    return data;
  };

  const changeIndex = (action: string, index: number) => {
    const updates: sortDashboards[] = [];
    const updatedList = [...dashboardList];
    if (action == common_labels.up) {
      if (index != 0) {
        const topRowIndex = index - 1;
        if (
          updatedList[index]?.order_index &&
          updatedList[topRowIndex]?.order_index
        ) {
          const orderIndex = updatedList[index].order_index;
          const topRowOrderIndex = updatedList[topRowIndex].order_index;
          updatedList[index].order_index = topRowOrderIndex;
          updatedList[topRowIndex].order_index = orderIndex;
          updates.push({
            dashboard_id: updatedList[index].id,
            newIndex: topRowOrderIndex,
          });
          updates.push({
            dashboard_id: updatedList[topRowIndex].id,
            newIndex: orderIndex,
          });
        }
      }
    } else {
      if (index + 1 != updatedList.length) {
        const bottomRowIndex = index + 1;
        if (
          updatedList[index].order_index != undefined &&
          updatedList[bottomRowIndex].order_index != undefined
        ) {
          const orderIndex = updatedList[index].order_index;
          const bottomRowOrderIndex = updatedList[bottomRowIndex].order_index;
          updatedList[index].order_index = bottomRowOrderIndex;
          updatedList[bottomRowIndex].order_index = orderIndex;
          updates.push({
            dashboard_id: updatedList[index].id,
            newIndex: bottomRowOrderIndex,
          });
          updates.push({
            dashboard_id: updatedList[bottomRowIndex].id,
            newIndex: orderIndex,
          });
        }
      }
    }
    if (updates.length === 2) {
      shortDashboards(updates, updatedList);
    }
  };

  const shortDashboards = async (
    updates: sortDashboards[],
    updatedList: Dashboard[]
  ) => {
    try {
      setLoading2(true);
      const res = await service.sortingDashboards({ updates: updates });
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      setDashboardList(sortTheList([...updatedList]));
    } catch (error) {
      errorManager(error as APIerror);
    } finally {
      setLoading2(false);
    }
  };

  const updateDashboard = (id: number) => {
    const data = formState[id];
    if (!data) return;
    const { isValid, errorFields, errors } = validateDashboard(data);

    setShowError(errorFields);
    setErrorModal(errors);

    if (!isValid) return;
    const payload: DashboardUpdate = {
      title: data.title,
      version: data.version || "",
      url: data.url || "",
      description: data.description || "",
      notes: data.notes || "",
      category_ids: data.categories.map((category) => category.id),
    };
    if (id === TEMP_ID) {
      addDashboard(payload, data);
    } else {
      editDashboard(payload, id);
    }
  };

  const addDashboard = async (payload: DashboardUpdate, data: Dashboard) => {
    try {
      setLoading2(true);
      const res = await service.addDashboard(payload);
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      showModal({
        message: `${dashboard_const.dashboardCreated}`,
        title: api_status.success,
      });
      handleExpandRow(data);
      getDashboardList();
    } catch (error) {
      errorManager(error as APIerror);
    } finally {
      setLoading2(false);
    }
  };

  const editDashboard = async (payload: DashboardUpdate, id: number) => {
    try {
      setLoading2(true);
      const res = await service.updateDashboard(payload, id);
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      showModal({
        message: `${dashboard_const.dashboardUpdated}: ${res.message}`,
        title: api_status.success,
      });
      setExpandedRowId(null);
      getDashboardList();
    } catch (error) {
      errorManager(error as APIerror);
    } finally {
      setLoading2(false);
    }
  };

  const isButtonDisabled = (action: string, index: number) => {
    let disabled: boolean = false;
    if (action == common_labels.up) {
      disabled = index == 0;
    } else {
      disabled = index + 1 == dashboardList.length;
    }
    return disabled;
  };

  const validateDashboard = (
    data: Dashboard
  ): {
    isValid: boolean;
    errorFields: formFieldesValidation;
    errors: string[];
  } => {
    const errors: string[] = [];
    const errorFields: formFieldesValidation = {
      title: false,
      version: false,
      url: false,
      description: false,
      notes: false,
      categories: false
    };

    if (!data.title.trim() || data.title.length < 3) {
      errors.push(dashboard_const.titleError);
      errorFields.title = true;
    }
    if (data.version.trim() === "" && !/^\d+(\.\d+)*$/.test(data.version)) {
      errors.push(dashboard_const.versionError);
      errorFields.version = true;
    }
    if(!data.categories || data.categories.length === 0) {}
    if (!isValidUrl(data.url)) {
      errors.push(dashboard_const.urlError);
      errorFields.url = true;
    }
    if (!data.description.trim() || data.description.length < 3) {
      errors.push(dashboard_const.descriptionError);
      errorFields.description = true;
    }
    if (!data.notes.trim() || data.notes.length < 3) {
      errors.push(dashboard_const.notesError);
      errorFields.notes = true;
    }
    if (!data.categories || data.categories.length === 0) {
      errors.push(dashboard_const.categoryError);
      errorFields.categories = true;
    }

    return {
      isValid: errors.length === 0,
      errorFields,
      errors,
    };
  };

  const updateFormField = (
    id: number,
    field: keyof Dashboard,
    value: string | Category[]
  ) => {
    setFormState((prev) => ({
      ...prev,
      [id]: {
        ...prev[id],
        [field]: value,
      },
    }));
  };

  const removeAddedRow = () => {
    setDashboardList((prev) => prev.filter((x) => x.id !== TEMP_ID));
  };

  const handleAddDashboard = () => {
    removeAddedRow();
    if (dashboardList.some((x) => x.id === TEMP_ID)) return;
    const newDashboard: Dashboard = {
      id: TEMP_ID,
      title: "",
      version: "",
      url: "",
      description: "",
      notes: "",
      categories: [],
      created_at: new Date(),
      updated_at: new Date(),
      updated_by_first_name: "You",
      order_index: dashboardList.length,
      created_by: 0,
      status: "",
      updated_by: 0,
      is_starred: false,
      updated_by_last_name: "",
    };

    setDashboardList((prev) => [...prev, newDashboard]);

    setFormState((prev) => ({
      ...prev,
      [TEMP_ID]: newDashboard,
    }));

    setExpandedRowId(TEMP_ID);
  };

  const handleExpandRow = (dashboard: Dashboard) => {
    // if(dashboard.id === TEMP_ID) {
    removeAddedRow();
    // }
    const isAlreadyOpen = expandedRowId === dashboard.id;
    setExpandedRowId(isAlreadyOpen ? null : dashboard.id);

    if (!isAlreadyOpen) {
      setFormState((prev) => ({
        ...prev,
        [dashboard.id]: dashboard,
      }));
    }
    setShowError({
      title: false,
      version: false,
      url: false,
      description: false,
      notes: false,
      categories: false,
    });
  };

  return (
    <>
      <SectionHeader
        title={dashboard_const.manageDashboards}
        hasNavigation={true}
        navigateTo={routes.dashboards}
        variant="header01"
        hasButton={true}
        className="text-white"
        button={{
          label: dashboard_const.add,
          variant: "lead02",
          hasBorder: false,
          hasIcon: true,
          iconOnLeft: true,
          className: "text-secondary-04",
          icon: { name: "plusWithCircle", color: "#57B4FF", size: 20 },
          onClick: handleAddDashboard,
        }}
      />
      {isLoading ? (
        <Loading isFullPage={false} className="min-h-60!" />
      ) : (
        <div className="w-full h-full overflow-x-auto">
          <div className="overflow-x-auto table w-full text-white">
            <table>
              <thead>
                <tr>
                  <th></th>
                  <th>
                    <Typography variant="lead02" as="span">
                      Dashboard
                    </Typography>
                  </th>
                  <th className="w-80">
                    <Typography variant="lead02" as="span">
                      Category
                    </Typography>
                  </th>
                  <th>
                    <Typography variant="lead02" as="span">
                      Created/Last Edited
                    </Typography>
                  </th>
                  <th>
                    <Typography variant="lead02" as="span">
                      Created/Last Edited by
                    </Typography>
                  </th>
                  <th>
                    <Typography variant="lead02" as="span">
                      Action
                    </Typography>
                  </th>
                </tr>
              </thead>
              <tbody className="max-h-2/3 overflow-y-auto">
                {dashboardList.length > 0 &&
                  dashboardList.map((x, i) => {
                    return (
                      <React.Fragment key={x.id}>
                        <tr>
                          <td className="p-0!">
                            <div className="flex flex-col">
                              <button
                                className="cursor-pointer m-1"
                                onClick={() => {
                                  if (!isButtonDisabled(common_labels.up, i)) {
                                    changeIndex(common_labels.up, i);
                                  }
                                }}
                              >
                                <Icons
                                  name="upArrow"
                                  size={8}
                                  color={
                                    isButtonDisabled(common_labels.up, i)
                                      ? "#ffffff80"
                                      : "#fff"
                                  }
                                />
                              </button>
                              <button
                                className="cursor-pointer m-1"
                                onClick={() => {
                                  if (
                                    !isButtonDisabled(common_labels.down, i)
                                  ) {
                                    changeIndex(common_labels.down, i);
                                  }
                                }}
                              >
                                <Icons
                                  name="downArrow"
                                  size={8}
                                  color={
                                    isButtonDisabled(common_labels.down, i)
                                      ? "#ffffff80"
                                      : "#fff"
                                  }
                                />
                              </button>
                            </div>
                          </td>
                          <td>
                            <Typography variant="label01" as="span">
                              {x.title}
                            </Typography>
                          </td>
                          <td>
                            <Typography variant="label01" as="span">
                              {x.categories.length > 0
                                ? x.categories.map((y) => y.name).join(", ")
                                : "-"}
                            </Typography>
                          </td>
                          <td>
                            <Typography variant="label01" as="span">
                              {formatDate(x.updated_at)}
                            </Typography>
                          </td>
                          <td>
                            <Typography variant="label01" as="span">
                              {`${x.updated_by_first_name} ${x.updated_by_last_name}`}
                            </Typography>
                          </td>
                          <td>
                            <Button
                              variant="label01"
                              className="text-secondary-04"
                              label={
                                expandedRowId === x.id
                                  ? common_labels.close
                                  : common_labels.edit
                              }
                              hasBorder={false}
                              hasIcon={true}
                              iconOnLeft={false}
                              isActive={true}
                              icon={{
                                name: "arrowRight",
                                color: "#57B4FF",
                                size: 10,
                              }}
                              onClick={() => handleExpandRow(x)}
                            />
                          </td>
                        </tr>
                        {expandedRowId === x.id && (
                          <tr>
                            <td colSpan={6} className="p-2.5">
                              {/* Responsive expanded form */}
                              <div className="w-full flex flex-col gap-2">
                                <div className="w-full flex flex-wrap flex-col gap-4 md:grid md:grid-cols-7 md:gap-2">
                                  {/* Dashboard Title, Version, and Actions in one row */}
                                  <div className="w-full flex flex-col md:items-center gap-1 md:grid md:grid-cols-8 md:gap-2 md:col-span-8">
                                    {/* Dashboard label */}
                                    <Typography
                                      variant="header04"
                                      className="flex flex-wrap items-center md:col-span-1"
                                    >
                                      Dashboard
                                      <span className="p-1 cursor-pointer">
                                        <Icons name="questionMark" size={15} />
                                      </span>
                                    </Typography>
                                    {/* Dashboard input - shifted right by starting at col 2 and spanning 3 columns */}
                                    <span className="w-full md:col-start-2 md:col-span-3 md:mt-0">
                                      <InputBox
                                        name={`titleInputBox-${x.id}`}
                                        error={showError.title}
                                        value={formState[x.id]?.title || ""}
                                        onChange={(e) =>
                                          updateFormField(x.id, "title", e.target.value)
                                        }
                                        autoFocus={true}
                                        className="bg-[#8AB6EA1A] border-gray-300 border border-solid rounded-md w-full py-1.5 px-2.5"
                                      />
                                    </span>
                                    {/* Version label */}
                                    <Typography
                                      variant="header04"
                                      className="flex flex-wrap items-center md:justify-center md:col-span-1"
                                    >
                                      <span className="flex flex-wrap items-center">
                                        Version
                                        <span className="p-1 cursor-pointer">
                                          <Icons
                                            name="questionMark"
                                            size={15}
                                          />
                                        </span>
                                      </span>
                                    </Typography>
                                    {/* Version input */}
                                    <span className="w-full md:col-span-2 md:mt-0">
                                      <InputBox
                                        name={`versionInputBox${
                                          x.id
                                        }${Math.random()}`}
                                        error={showError.version}
                                        value={formState[x.id]?.version || ""}
                                        onChange={(e) =>
                                          updateFormField(
                                            x.id,
                                            "version",
                                            e.target.value
                                          )
                                        }
                                        className="bg-[#8AB6EA1A] border-gray-300 border-1 rounded-md w-full py-1.5 px-2.5"
                                      />
                                    </span>
                                    {/* Actions for desktop */}
                                    <div className="hidden md:flex flex-wrap items-center justify-end gap-2 md:col-span-1 md:justify-center md:items-center mt-2 md:mt-0">
                                      <Button
                                        label="Cancel"
                                        hasBorder={false}
                                        hasIcon={false}
                                        variant="hyperlink"
                                        className="text-secondary-04 px-1.5"
                                        onClick={() => handleExpandRow(x)}
                                      />
                                      <Button
                                        label="Save"
                                        hasBorder={false}
                                        hasIcon={false}
                                        variant="hyperlink"
                                        className="text-secondary-04 px-1.5"
                                        onClick={() => updateDashboard(x.id)}
                                      />
                                    </div>
                                  </div>
                                </div>
                                {/* Category */}
                                <div className="w-full flex flex-col gap-1 md:grid md:grid-cols-8 md:gap-2">
                                  <Typography
                                    variant="header04"
                                    className="flex flex-wrap items-center md:col-span-1"
                                  >
                                    Category
                                    <span className="p-1 cursor-pointer">
                                      <Icons name="questionMark" size={15} />
                                    </span>
                                  </Typography>
                                  <Typography
                                    variant="bodyregular"
                                    as="span"
                                    className="w-full md:col-span-6 md:mt-0"
                                  >
                                    <CustomMultiSelect<Category>
                                      options={categories}
                                      selected={
                                        formState[x.id]?.categories || []
                                      }
                                      onChange={(selected) =>
                                        updateFormField(
                                          x.id,
                                          "categories",
                                          selected
                                        )
                                      }
                                      getId={(category) => category.id}
                                      getLabel={(category) => category.name}
                                      className="w-full py-1.5 px-2.5"
                                      error={
                                        showError.categories
                                      }
                                    />
                                  </Typography>
                                </div>
                                {/* Link */}
                                <div className="w-full flex flex-col gap-1 md:grid md:grid-cols-8 md:gap-2">
                                  <Typography
                                    variant="header04"
                                    className="flex flex-wrap items-center md:col-span-1"
                                  >
                                    Link
                                    <span className="p-1 cursor-pointer">
                                      <Icons name="questionMark" size={15} />
                                    </span>
                                  </Typography>
                                  <span className="w-full md:col-span-6 md:mt-0">
                                    <InputBox
                                      name={`urlInputBox${
                                        x.id
                                      }${Math.random()}`}
                                      error={showError.url}
                                      value={formState[x.id]?.url || ""}
                                      onChange={(e) =>
                                        updateFormField(
                                          x.id,
                                          "url",
                                          e.target.value
                                        )
                                      }
                                      className="bg-[#8AB6EA1A] border-gray-300 border-1 rounded-md w-full py-1.5 px-2.5"
                                    />
                                  </span>
                                </div>
                                {/* Description */}
                                <div className="w-full flex flex-col md:items-center gap-1 md:grid md:grid-cols-8 md:gap-2">
                                  <Typography
                                    variant="header04"
                                    className="flex flex-wrap items-center md:col-span-1"
                                  >
                                    Description
                                    <span className="p-1 cursor-pointer">
                                      <Icons name="questionMark" size={15} />
                                    </span>
                                  </Typography>
                                  <span className="w-full md:col-span-6 md:mt-0">
                                    <InputBox
                                      isInput={false}
                                      name={`descriptionInputBox${
                                        x.id
                                      }${Math.random()}`}
                                      error={showError.description}
                                      value={formState[x.id]?.description || ""}
                                      onChange={(e) =>
                                        updateFormField(
                                          x.id,
                                          "description",
                                          e.target.value
                                        )
                                      }
                                      className="bg-[#8AB6EA1A] border-gray-300 border-1 rounded-md w-full py-1.5 px-2.5"
                                    />
                                  </span>
                                </div>
                                {/* Notes */}
                                <div className="w-full flex flex-col gap-1 md:grid md:grid-cols-8 md:gap-2">
                                  <Typography
                                    variant="header04"
                                    className="flex items-center md:col-span-1"
                                  >
                                    Notes
                                    <span className="p-1 cursor-pointer">
                                      <Icons name="questionMark" size={15} />
                                    </span>
                                  </Typography>
                                  <span className="w-full md:col-span-6 md:mt-0">
                                    <InputBox
                                      isInput={false}
                                      name={`notesInputBox${
                                        x.id
                                      }${Math.random()}`}
                                      error={showError.notes}
                                      value={formState[x.id]?.notes || ""}
                                      onChange={(e) =>
                                        updateFormField(
                                          x.id,
                                          "notes",
                                          e.target.value
                                        )
                                      }
                                      className="bg-[#8AB6EA1A] border-gray-300 border-1 rounded-md w-full py-1.5 px-2.5"
                                    />
                                  </span>
                                </div>
                              </div>
                              {/* Actions for mobile (bottom of form) */}
                              <div className="flex md:hidden flex-row items-center gap-2 mt-2">
                                <Button
                                  label="Cancel"
                                  hasBorder={false}
                                  hasIcon={false}
                                  variant="hyperlink"
                                  className="text-secondary-04 px-1.5"
                                  onClick={() => handleExpandRow(x)}
                                />
                                <Button
                                  label="Save"
                                  hasBorder={false}
                                  hasIcon={false}
                                  variant="hyperlink"
                                  className="text-secondary-04 px-1.5"
                                  onClick={() => updateDashboard(x.id)}
                                />
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}
      <MyModal
        show={errormodal.length > 0}
        onClose={() => setErrorModal([])}
        title="Please fix the Issues"
        isItFullScreen={true}
      >
        <ul>
          {errormodal.map((error, index) => (
            <Typography
              key={index}
              variant="bodyregular"
              as="li"
              className="list-disc text-white"
            >
              {error}
            </Typography>
          ))}
        </ul>
      </MyModal>
      {loading2 && <Loading varient={true} />}
    </>
  );
};

export default ManageDashboards;
