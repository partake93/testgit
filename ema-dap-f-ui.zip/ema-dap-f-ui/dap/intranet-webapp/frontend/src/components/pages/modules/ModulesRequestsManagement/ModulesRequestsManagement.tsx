import * as React from "react";
import * as service from "../../../../services/modulesService";
import {
  ModuleRequest,
  moduleRequestsStatus,
  moduleRequestsStatusList,
} from "../../../../types/Modules";
import {
  api_status,
  common_labels,
  error_const,
  modules_const,
} from "../../../../utils/constants";
import { formatDate } from "../../../../utils/date";
import Typography from "../../../atoms/typography/Typography";
import StatusTag from "../../../molecules/StatusTag/StatusTag";
import Pagination from "../../../Organisms/Pagination";
import { useErrorManager } from "../../../../utils/manageApiError";
import { useNavigate } from "react-router-dom";
import { useModalPopup } from "../../../../context/ModalPopupContext";
import { APIerror } from "../../../../types/Error";
import { routes } from "../../../../utils/routes";
import SectionHeader from "../../../Organisms/SectionHeader";
import Loading from "../../../Organisms/Loading/Loading";
import CustomDateRangePicker from "../../../molecules/CustomDateRangePicker/CustomDateRangePicker";
import Button from "../../../molecules/Button/Button";

const ModulesRequestsManagement = () => {
  const [requestsList, setRequestsList] = React.useState<ModuleRequest[]>([]);
  const [statusFilter] = React.useState<string[]>([
    common_labels.all,
    ...moduleRequestsStatusList,
  ]);
  const [selectedStatus, setSelectedStatus] = React.useState<string>(
    common_labels.all
  );
  const [startDate, setStartDate] = React.useState("");
  const [endDate, setEndDate] = React.useState("");
  const [currentPage, setCurrentPage] = React.useState(1);
  const [totalPages, setTotalPages] = React.useState(1);
  const [isLoading, setLoading] = React.useState<boolean>(false);
  const [isLoading1, setIsLoading1] = React.useState<boolean>(false);
  const [selectedRows, setSelectedRows] = React.useState<number[]>([]);

  const errorManager = useErrorManager();
  const navigate = useNavigate();
  const { showModal } = useModalPopup();

  const getRequestsList = async () => {
    try {
      setLoading(true);
      const sts = selectedStatus === common_labels.all ? null : selectedStatus;
      const start = startDate.trim() === "" ? null : startDate;
      const end = endDate.trim() === "" ? null : endDate;
      const res = await service.getModuleRequest(
        currentPage,
        sts,
        start != null ? new Date(start) : null,
        end != null ? new Date(end) : null
      );
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      if (!res.data || res.data.length === 0) {
        // showModal({message: "No Requests available",title: "info"});
        setRequestsList([]);
        setTotalPages(1);
        return;
      }
      setTotalPages(res.total_pages || 1);
      setRequestsList(
        [...res.data].sort(
          (a, b) =>
            moduleRequestsStatusList.indexOf(a.status.toLocaleLowerCase()) -
            moduleRequestsStatusList.indexOf(b.status.toLocaleLowerCase())
        )
      );
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    getRequestsList();
  }, [currentPage, selectedStatus, startDate, endDate]);

  const handlePageChange = (pageNumber: number) => {
    if (pageNumber !== currentPage) {
      setCurrentPage(pageNumber);
    }
  };

  const saveDate = (startDate: string, endDate: string) => {
    setStartDate(startDate);
    setEndDate(endDate);
  };

  const handleSelectRow = (id: number) => {
    setSelectedRows((prev) =>
      prev.includes(id) ? prev.filter((rowId) => rowId !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedRows.length === requestsList.length) {
      setSelectedRows([]);
    } else {
      setSelectedRows(requestsList.filter((x) => x.status.toLocaleLowerCase() ===
                            moduleRequestsStatus.pending.toLocaleLowerCase()).map((x) => x.id));
    }
  };

  const handleAction = async (action: string) => {
    if (selectedRows.length === 0) {
      showModal({
        message: error_const.selectAtLeastOne,
        title: api_status.error,
      });
      return;
    }
    try {
      setIsLoading1(true);
      const requestIds: string[] = selectedRows.map((x) => x.toString());
      const res = await service.moduleRequestsAction(action, requestIds);
      if (res.status === api_status.error) {
        showModal({
          message: `${error_const.failed}: ${
            res.message || error_const.apiError
          }`,
          title: api_status.error,
        });
        return;
      }
      showModal({
        message: `${modules_const.requestActionSuccess.replace(
          "{action}",
          action === common_labels.approve ? "approved" : "rejected"
        )}`,
        title: api_status.success,
      });
      if (res.status === api_status.success) {
        setSelectedRows([]);
        getRequestsList();
      }
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setIsLoading1(false);
    }
  };

  return (
    <>
      <SectionHeader
        title={modules_const.request}
        hasNavigation={true}
        navigateTo={routes.home}
        variant="header01"
        hasButton={false}
        className="text-white"
      />
      {isLoading ? (
        <Loading isFullPage={false} className="min-h-60!" />
      ) : (
        <>
          <div className="flex sm:flex-row flex-col gap-2 items-center text-white">
            <div className="flex gap-1 items-center px-1.5 py-0.5">
              {statusFilter.map((status) => (
                <Button
                  key={status + Math.random()}
                  variant="captionregular"
                  onClick={() => setSelectedStatus(status)}
                  label={status.charAt(0).toUpperCase() + status.slice(1)}
                  hasBorder={true}
                  hasIcon={false}
                  isDark={true}
                  className={`button px-2 py-0.5 ${
                    selectedStatus === status && "selected"
                  }`}
                />
              ))}
            </div>
            <div className="flex gap-1 items-center border-s-2 px-2 py-0.5">
              <Typography variant="smallcaption" as="span" className="w-70">
                <CustomDateRangePicker
                  saveDate={saveDate}
                  start_date={startDate}
                  end_date={endDate}
                  isPill={true}
                  clearDate={() => {
                    setStartDate("");
                    setEndDate("");
                  }}
                />
              </Typography>
            </div>
          </div>
          <div className="overflow-x-auto table w-full text-white">
            <table className="min-w-[700px] w-full table-auto">
              <thead>
                <tr>
                  <th>
                    {requestsList.length > 0 &&
                      requestsList.filter(
                        (req) =>
                          req.status.toLocaleLowerCase() ===
                          moduleRequestsStatus.pending.toLocaleLowerCase()
                      ).length > 0 && (
                        <input
                          type="checkbox"
                          checked={
                            requestsList.length > 0 &&
                            selectedRows.length === requestsList.filter(x => x.status.toLocaleLowerCase() ===
                            moduleRequestsStatus.pending.toLocaleLowerCase()).length
                          }
                          onChange={handleSelectAll}
                          aria-label="Select all"
                        />
                      )}
                  </th>
                  <th>
                    <Typography variant="lead02" as="span">
                      User
                    </Typography>
                  </th>
                  <th>
                    <Typography variant="lead02" as="span">
                      Request ID
                    </Typography>
                  </th>
                  <th>
                    <Typography variant="lead02" as="span">
                      Module/Dashboard
                    </Typography>
                  </th>
                  <th>
                    <Typography variant="lead02" as="span">
                      Submited Date
                    </Typography>
                  </th>
                  <th>
                    <Typography variant="lead02" as="span">
                      Status
                    </Typography>
                  </th>
                  <th>
                    <Typography variant="lead02" as="span">
                      Action
                    </Typography>
                  </th>
                </tr>
              </thead>
              <tbody className="max-h-2/3 overflow-y-auto">
                {requestsList.length > 0 &&
                  requestsList.map((x, i) => {
                    return (
                      <tr key={i}>
                        <td>
                          {x.status.toLocaleLowerCase() ===
                            moduleRequestsStatus.pending.toLocaleLowerCase() && (
                            <input
                              type="checkbox"
                              checked={selectedRows.includes(x.id)}
                              onChange={() => handleSelectRow(x.id)}
                              aria-label={`Select row ${x.id}`}
                            />
                          )}
                        </td>
                        <td>
                          <Typography variant="label01" as="span">
                            {x.first_name} {x.last_name}
                          </Typography>
                        </td>
                        <td>
                          <Typography variant="label01" as="span">
                            {x.id}
                          </Typography>
                        </td>
                        <td>
                          <Typography variant="label01" as="span">
                            {x.module_name}
                          </Typography>
                        </td>
                        <td>
                          <Typography variant="label01" as="span">
                            {formatDate(x.created_at)}
                          </Typography>
                        </td>
                        <td>
                          <StatusTag
                            label={x.status.toLocaleUpperCase()}
                            variant="smallcaption"
                            className={getBGcolor(x.status) + " px-0.5"}
                          />
                        </td>
                        <td>
                          <Button
                            variant="label01"
                            className="text-secondary-04"
                            label={getButtonLabel(x.status)}
                            hasBorder={false}
                            hasIcon={true}
                            iconOnLeft={false}
                            isActive={true}
                            icon={{
                              name: "arrowRight",
                              color: "#57B4FF",
                              size: 10,
                            }}
                            onClick={() =>
                              navigate(`${routes.moduleRequest}${x.id}`)
                            }
                          />
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
          {requestsList.length === 0 ? (
            <div className="flex justify-center items-center h-20">
              <Typography variant="lead01" className="text-white">
                {modules_const.noRequestsFound}
              </Typography>
            </div>
          ) : (
            <div className="w-full flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="w-full flex justify-center">
                <Pagination
                  page={{ current_page: currentPage, total_pages: totalPages }}
                  handlePageChange={handlePageChange}
                />
              </div>
              <div className="flex sm:flex-wrap flex-nowrap gap-2 justify-center md:justify-end w-full md:w-auto">
                <Button
                  label={common_labels.reject}
                  variant="header04"
                  hasBorder={false}
                  hasIcon={false}
                  isActive={selectedRows.length > 0}
                  onClick={() => handleAction(common_labels.reject)}
                  className="rounded-full! px-6.5 py-1.5 bg-[#DAE8FB] text-primary-400"
                />
                <Button
                  label={common_labels.approve}
                  variant="header04"
                  hasBorder={false}
                  hasIcon={false}
                  isActive={selectedRows.length > 0}
                  onClick={() => handleAction(common_labels.approve)}
                  className="rounded-full! px-6.5 py-1.5 bg-primary-400 text-white"
                />
              </div>
            </div>
          )}
        </>
      )}
      {isLoading1 && <Loading varient={true} />}
    </>
  );
};

export default ModulesRequestsManagement;

const getButtonLabel = (status: string) => {
  if (
    moduleRequestsStatus.pending.toLocaleLowerCase() ==
    status.toLocaleLowerCase()
  ) {
    return common_labels.review;
  } else {
    return common_labels.view;
  }
};

const getBGcolor = (status: string) => {
  if (
    moduleRequestsStatus.approved.toLocaleLowerCase() ==
    status.toLocaleLowerCase()
  ) {
    return "bg-success-500";
  } else if (
    moduleRequestsStatus.pending.toLocaleLowerCase() ==
    status.toLocaleLowerCase()
  ) {
    return "bg-status-yellow-500 text-black";
  } else {
    return "bg-secondary-01";
  }
};
