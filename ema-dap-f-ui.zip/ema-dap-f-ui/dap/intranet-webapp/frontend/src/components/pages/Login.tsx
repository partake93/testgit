import { useState } from "react";
import { loginUser } from "../../services/authService";
import axios from "axios";
import Loading from "../Organisms/Loading/Loading";

const Login = () => {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    try {
      setIsLoading(true);
      const res = await loginUser({ email });
      if (res.status !== "success") {
        setError("Login failed");

        throw new Error(res.message);
      }
      // Optionally, redirect or show success
      window.location.href = "/";
    } catch (err: unknown) {
      if (axios.isAxiosError(err)) {
        // Handle Axios error
        setError(err.response?.data.message || "An error occurred");
      } else {
        // Handle other errors
        setError("An unexpected error occurred");
      }
      setIsLoading(false);
    }
  };

  if (import.meta.env.VITE_ENVIRONMENT !== "local") {
    return (
      <>
        {isLoading && <Loading />}
        <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
          <button
            type="submit"
            className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 transition-colors"
            onClick={() => {
              window.location.href = `${import.meta.env.VITE_BACKEND_URL}/login`;
            }}
          >
            Login
          </button>
        </div>
      </>
    );
  }
  else {
    return (
      <>
        {isLoading && <Loading />}
        <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
          <h1 className="text-4xl font-bold mb-4">Login</h1>
          <form className="bg-white p-6 rounded shadow-md w-96" onSubmit={handleSubmit}>
            <label htmlFor="email" className="block text-gray-700 mb-2">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              className="w-full px-3 py-2 mb-4 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
              value={email}
              onChange={e => setEmail(e.target.value)}
            />
            {error && <div className="text-red-500 mb-2">{error}</div>}
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition-colors"
            >
              Login
            </button>
          </form>
        </div>
      </>
    );
  }
};

export default Login;