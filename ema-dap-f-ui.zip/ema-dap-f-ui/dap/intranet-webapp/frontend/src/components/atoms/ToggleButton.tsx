import React from 'react';

interface BooleanToggleProps {
  value: boolean;
  onChange: (val: boolean) => void;
  labelTrue?: string;
  labelFalse?: string;
}

const ToggleButton: React.FC<BooleanToggleProps> = ({
  value,
  onChange,
  labelTrue = "Yes",
  labelFalse = "No",
}) => {
  return (
    <div className="flex w-full">
      <button
        type="button"
        onClick={() => onChange(true)}
        className={`w-full px-4 py-2 text-sm rounded-md transition-colors duration-200
          ${value
            ? 'bg-[#8AB6EA80] border border-white'
            : 'bg-[#8AB6EA1A]'}
        `}
      >
        {labelTrue}
      </button>
      <button
        type="button"
        onClick={() => onChange(false)}
        className={`w-full px-4 py-2 text-sm rounded-md transition-colors duration-200
          ${!value
            ? 'bg-[#8AB6EA80] border border-white'
            : 'bg-[#8AB6EA1A]'}
        `}
      >
        {labelFalse}
      </button>
    </div>
  );
};

export default ToggleButton;
