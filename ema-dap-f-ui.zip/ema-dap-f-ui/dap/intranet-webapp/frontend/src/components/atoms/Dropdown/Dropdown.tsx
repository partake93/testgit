import * as React from "react";
import Typography from "../typography/Typography";

function CustomMultiSelect<T>({
  options,
  selected,
  onChange,
  getLabel,
  getId,
  error = false,
  message = "",
  placeholder = "Select...",
  className = "",
  ...props
}: MultiSelectProps<T>) {
  const [isOpen, setIsOpen] = React.useState<boolean>(false);
  const [search, setSearch] = React.useState<string>("");

  React.useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (!(e.target as HTMLElement).closest(".custom-multiselect")) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const toggleDropdown = () => setIsOpen((prev) => !prev);

  const handleSelect = (item: T) => {
    const exists = selected.some((s) => getId(s) === getId(item));
    if (exists) {
      onChange(selected.filter((s) => getId(s) !== getId(item)));
    } else {
      onChange([...selected, item]);
    }
  };

  const filtered = options.filter((opt) =>
    getLabel(opt).toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="relative w-full">
      <div
        onClick={toggleDropdown}
        className={`flex gap-1 h-10 p-2.5 border-1 bg-[#8AB6EA1A] ${error ? "border-red-500!" : "border-gray-300"} rounded-sm cursor-pointer w-full overflow-x-auto whitespace-nowrap ${className}`}
        data-testid="dropdown-toggle"
        {...props}
      >
        {selected.map((item) => (
          <Typography
            variant="smallcaption"
            as="span"
            key={getId(item)}
            className="inline-flex items-center gap-1 rounded-sm px-1.5 py-0.5 bg-primary-500"
          >
            {getLabel(item)}
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleSelect(item);
              }}
            >
              ×
            </button>
          </Typography>
        ))}
      </div>
      {error && message !== "" && (
        <Typography variant="smallcaption" className="text-red-500">
          {message}
        </Typography>
      )}

      {isOpen && (
        <ul className="absolute top-full left-0 right-0 border-1 border-gray-300 max-h-40 overflow-y-auto z-10 m-0 p-0 list-none text-black custom-multiselect">
          <li className="p-1.5 bg-neutral-50 flex">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={placeholder}
              className="w-full p-1.5 border-1 border-gray-300 rounded-sm"
            />
            <Typography
              variant="header04"
              as="button"
              onClick={() => setIsOpen(false)}
            >
              X
            </Typography>
          </li>
          {filtered.map((item) => (
            <li
              key={getId(item)}
              onClick={() => handleSelect(item)}
              className={`p-1.5 cursor-pointer ${
                selected.some((s) => getId(s) === getId(item))
                  ? "bg-primary-500 text-white border"
                  : "bg-primary-50"
              }`}
            >
              {getLabel(item)}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default CustomMultiSelect;

type MultiSelectProps<T> = {
  options: T[];
  selected: T[];
  onChange: (selected: T[]) => void;
  getLabel: (item: T) => string;
  getId: (item: T) => string | number;
  placeholder?: string;
  [key: string]: any;
};
