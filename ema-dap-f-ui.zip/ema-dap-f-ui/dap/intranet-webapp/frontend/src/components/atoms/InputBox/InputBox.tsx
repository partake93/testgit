import React from "react";
import Typography, { typographyvar } from "../typography/Typography";

interface InputBoxProps {
  varient?: typographyvar;
  name: string;
  type?: string;
  placeholder?: string;
  error?: boolean;
  message?: string;
  required?: boolean;
  disabled?: boolean;
  className?: string;
  value?: string;
  isInput?: boolean;
  maxLength?: number;
  onChange?: (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => void;
  [key: string]: any;
}

const InputBox: React.FC<InputBoxProps> = ({
  varient = "bodyregular",
  name,
  type = "text",
  placeholder = "",
  error = false,
  required = false,
  disabled = false,
  className = "",
  value = "",
  onChange = () => {},
  isInput = true,
  message = "",
  maxLength,
  ...props
}) => {
  if (isInput) {
    return (
      <Typography variant={varient} as="span">
        <input
          id={name}
          name={name}
          type={type}
          required={required}
          placeholder={placeholder}
          disabled={disabled}
          value={value}
          onChange={onChange}
          className={`${className} h-10 px-3 py-2 rounded-md
          ${error ? "border-red-500!" : "border-gray-300"} 
          focus:outline-none border-1`}
          {...(maxLength !== undefined ? { maxLength } : {})}
          {...props}
          aria-label={name}
        />
        <Typography variant="smallcaption" as="span" className="flex py-1">
          {maxLength !== undefined && (
            <span>
              {value.length}/{maxLength} characters left
            </span>
          )}
          {error && message !== "" && (
            <span className="text-red-500 mx-1">{message}</span>
          )}
        </Typography>
      </Typography>
    );
  }
  return (
    <Typography variant={varient} as="span">
      <textarea
        id={name}
        name={name}
        required={required}
        placeholder={placeholder}
        disabled={disabled}
        value={value}
        onChange={onChange}
        className={`${className} 
          ${error ? "border-red-500!" : "border-gray-300"} 
          focus:outline-none border-1`}
        {...(maxLength !== undefined ? { maxLength } : {})}
        {...props}
      />
      <Typography variant="smallcaption" as="span" className="flex py-1">
        {maxLength !== undefined && (
          <span>
            {value.length}/{maxLength} characters left
          </span>
        )}
        {error && message !== "" && (
          <span className="text-red-500 mx-1">{message}</span>
        )}
      </Typography>
    </Typography>
  );
};

export default InputBox;
