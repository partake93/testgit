import { render, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import InputBox from "./InputBox";

describe("InputBox Component", () => {
  const defaultProps = {
    name: "testInput",
    placeholder: "Enter text",
    onChange: jest.fn(),
  };

  it("renders an input by default", () => {
    const { getByPlaceholderText } = render(<InputBox {...defaultProps} />);
    const input = getByPlaceholderText("Enter text") as HTMLInputElement;

    expect(input).toBeInTheDocument();
    expect(input.tagName).toBe("INPUT");
  });

  it("renders a textarea when isInput is false", () => {
    const { getByPlaceholderText } = render(
      <InputBox {...defaultProps} isInput={false} />
    );
    const textarea = getByPlaceholderText("Enter text") as HTMLTextAreaElement;

    expect(textarea).toBeInTheDocument();
    expect(textarea.tagName).toBe("TEXTAREA");
  });

  it("applies error class when error is true", () => {
    const { getByPlaceholderText } = render(
      <InputBox {...defaultProps} error={true} />
    );
    const input = getByPlaceholderText("Enter text");
    expect(input.className).toMatch(/border-red-500/);
  });

  it("uses provided value prop", () => {
    const { getByDisplayValue } = render(
      <InputBox {...defaultProps} value="hello" />
    );
    expect(getByDisplayValue("hello")).toBeInTheDocument();
  });

  it("handles onChange event", () => {
    const handleChange = jest.fn();
    const { getByPlaceholderText } = render(
      <InputBox {...defaultProps} onChange={handleChange} />
    );
    const input = getByPlaceholderText("Enter text");
    fireEvent.change(input, { target: { value: "new text" } });

    expect(handleChange).toHaveBeenCalledTimes(1);
  });

  it("renders disabled and required attributes", () => {
    const { getByPlaceholderText } = render(
      <InputBox {...defaultProps} required={true} disabled={true} />
    );
    const input = getByPlaceholderText("Enter text") as HTMLInputElement;

    expect(input).toBeDisabled();
    expect(input).toBeRequired();
  });
});
