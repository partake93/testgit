import { render, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import Pill from "./Pill";

describe("Pill Toggle Component", () => {
  it("renders with isOn = true", () => {
    const { container } = render(<Pill isOn={true} onToggle={() => {}} />);
    const button = container.querySelector("button");
    const knob = container.querySelector("div");

    expect(button).toHaveClass("bg-green-500");
    expect(knob).toHaveClass("translate-x-6");
  });

  it("renders with isOn = false", () => {
    const { container } = render(<Pill isOn={false} onToggle={() => {}} />);
    const button = container.querySelector("button");
    const knob = container.querySelector("div");

    expect(button).toHaveClass("bg-gray-400");
    expect(knob).toHaveClass("translate-x-0");
  });

  it("calls onToggle with correct new state when clicked", () => {
    const mockToggle = jest.fn();
    const { getByRole } = render(<Pill isOn={false} onToggle={mockToggle} />);

    const button = getByRole("button");
    fireEvent.click(button);

    expect(mockToggle).toHaveBeenCalledTimes(1);
    expect(mockToggle).toHaveBeenCalledWith(true);
  });

  it("toggles off when isOn is true and clicked", () => {
    const mockToggle = jest.fn();
    const { getByRole } = render(<Pill isOn={true} onToggle={mockToggle} />);

    const button = getByRole("button");
    fireEvent.click(button);

    expect(mockToggle).toHaveBeenCalledWith(false);
  });
});
