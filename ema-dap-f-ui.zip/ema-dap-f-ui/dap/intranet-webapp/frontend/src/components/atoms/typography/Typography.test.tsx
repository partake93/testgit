import { render, screen, fireEvent } from "@testing-library/react";
import Typography, { TypographyProps } from "./Typography";
import styles from "./Typography.module.scss";

describe("Typography component", () => {
  const defaultProps: TypographyProps = {
    variant: "header01",
    children: "Test Text",
  };

  it('renders the correct HTML element based on "as" prop', () => {
    const { container } = render(<Typography {...defaultProps} as="h1" />);
    const element = container.querySelector("h1");
    expect(element).toBeInTheDocument();
    expect(element).toHaveTextContent("Test Text");
  });

  it('defaults to a "div" if "as" prop is not provided', () => {
    const { container } = render(<Typography {...defaultProps} />);
    const element = container.querySelector("div");
    expect(element).toBeInTheDocument();
    expect(element).toHaveTextContent("Test Text");
  });

  it("applies the correct variant class from styles", () => {
    render(<Typography {...defaultProps} />);
    const element = screen.getByText("Test Text");
    expect(element).toHaveClass(styles["typography-header01"]);
  });

  it("appends additional class names", () => {
    render(<Typography {...defaultProps} className="custom-class" />);
    const element = screen.getByText("Test Text");
    expect(element).toHaveClass("custom-class");
  });

  it("applies inline styles correctly", () => {
    render(<Typography {...defaultProps} style={{ color: "red" }} />);
    const element = screen.getByText("Test Text");
    expect(element).toHaveStyle({ color: "rgb(255, 0, 0)" });
  });

  it("handles onClick event", () => {
    const onClick = jest.fn();
    render(<Typography {...defaultProps} onClick={onClick} />);
    const element = screen.getByText("Test Text");
    fireEvent.click(element);
    expect(onClick).toHaveBeenCalledTimes(1);
  });
});
