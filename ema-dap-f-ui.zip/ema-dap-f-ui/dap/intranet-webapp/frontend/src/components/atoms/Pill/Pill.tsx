import React from "react";

type ToggleProps = {
  isOn: boolean;
  onToggle: (newState: boolean) => void;
};

const Pill: React.FC<ToggleProps> = ({ isOn, onToggle }) => {
  return (
    <button
    onClick={() => onToggle(!isOn)}
    className={`w-12 h-6 flex items-center rounded-full p-1 duration-300 
      ${isOn ? 'bg-green-500' : 'bg-gray-400'}`}
  >
    <div
      className={`bg-white w-4 h-4 rounded-full shadow-md transform 
        ${isOn ? 'translate-x-6' : 'translate-x-0'}`}
    />
  </button>
  );
};

export default Pill;