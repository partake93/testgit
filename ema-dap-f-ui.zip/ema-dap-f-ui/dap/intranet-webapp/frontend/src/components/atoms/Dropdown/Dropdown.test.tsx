import * as React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import CustomMultiSelect from "./Dropdown";

type Item = {
  id: number;
  name: string;
};

const options: Item[] = [
  { id: 1, name: "Apple" },
  { id: 2, name: "Banana" },
  { id: 3, name: "Cherry" },
];

const getLabel = (item: Item) => item.name;
const getId = (item: Item) => item.id;

describe("CustomMultiSelect", () => {
  it("renders selected items", () => {
    const selected = [options[1]]; // Banana
    render(
      <CustomMultiSelect
        options={options}
        selected={selected}
        onChange={jest.fn()}
        getLabel={getLabel}
        getId={getId}
      />
    );

    expect(screen.getByText("Banana")).toBeInTheDocument();
  });

  it("opens and closes dropdown", () => {
    render(
      <CustomMultiSelect
        options={options}
        selected={[]}
        onChange={jest.fn()}
        getLabel={getLabel}
        getId={getId}
      />
    );

    // Click the main select area to open dropdown
    fireEvent.click(screen.getByTestId("dropdown-toggle"));
    expect(screen.getByPlaceholderText("Select...")).toBeInTheDocument();

    // Close using the "X" button inside dropdown
    fireEvent.click(screen.getByText("X"));
    expect(screen.queryByPlaceholderText("Select...")).not.toBeInTheDocument();
  });

  it("filters options based on search input", () => {
    render(
      <CustomMultiSelect
        options={options}
        selected={[]}
        onChange={jest.fn()}
        getLabel={getLabel}
        getId={getId}
      />
    );

    fireEvent.click(screen.getByTestId("dropdown-toggle"));
    const input = screen.getByPlaceholderText("Select...");
    fireEvent.change(input, { target: { value: "Ban" } });

    expect(screen.getByText("Banana")).toBeInTheDocument();
    expect(screen.queryByText("Apple")).not.toBeInTheDocument();
  });

  it("calls onChange when selecting and deselecting", () => {
    const handleChange = jest.fn();
    render(
      <CustomMultiSelect
        options={options}
        selected={[]}
        onChange={handleChange}
        getLabel={getLabel}
        getId={getId}
      />
    );

    fireEvent.click(screen.getByTestId("dropdown-toggle"));
    fireEvent.click(screen.getByText("Apple"));

    expect(handleChange).toHaveBeenCalledWith([options[0]]); // Apple

    // Now test deselecting
    render(
      <CustomMultiSelect
        options={options}
        selected={[options[0]]}
        onChange={handleChange}
        getLabel={getLabel}
        getId={getId}
      />
    );

    fireEvent.click(screen.getByText("×")); // The remove button
    expect(handleChange).toHaveBeenCalledWith([]);
  });
  it("allows selecting multiple options", () => {
    const Wrapper = () => {
      const [selected, setSelected] = React.useState<Item[]>([]);
      return (
        <CustomMultiSelect
          options={options}
          selected={selected}
          onChange={setSelected}
          getLabel={getLabel}
          getId={getId}
        />
      );
    };

    render(<Wrapper />);

    fireEvent.click(screen.getByTestId("dropdown-toggle"));
    fireEvent.click(screen.getByText("Apple"));

    fireEvent.click(screen.getByText("Banana"));

    expect(screen.getAllByText("Apple")[0]).toBeInTheDocument();
    expect(screen.getAllByText("Banana")[0]).toBeInTheDocument();
  });
});
