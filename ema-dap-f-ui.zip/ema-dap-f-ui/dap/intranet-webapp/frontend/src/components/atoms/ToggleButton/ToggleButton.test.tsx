import { render, fireEvent } from '@testing-library/react';
import ToggleButton from './ToggleButton';

describe('ToggleButton', () => {
  const defaultProps = {
    value: true,
    onChange: jest.fn(),
    labelTrue: 'Enabled',
    labelFalse: 'Disabled',
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders with correct labels', () => {
    const { getByText } = render(<ToggleButton {...defaultProps} />);
    expect(getByText('Enabled')).toBeInTheDocument();
    expect(getByText('Disabled')).toBeInTheDocument();
  });

  it('calls onChange(true) when clicking the "true" button', () => {
    const { getByText } = render(<ToggleButton {...defaultProps} value={false} />);
    fireEvent.click(getByText('Enabled'));
    expect(defaultProps.onChange).toHaveBeenCalledWith(true);
  });

  it('calls onChange(false) when clicking the "false" button', () => {
    const { getByText } = render(<ToggleButton {...defaultProps} value={true} />);
    fireEvent.click(getByText('Disabled'));
    expect(defaultProps.onChange).toHaveBeenCalledWith(false);
  });

  it('applies active class to the correct button based on value', () => {
    const { getByText, rerender } = render(<ToggleButton {...defaultProps} value={true} />);
    const trueBtn = getByText('Enabled');
    const falseBtn = getByText('Disabled');
    expect(trueBtn.className).toContain('bg-[#8AB6EA80]');
    expect(falseBtn.className).toContain('bg-[#8AB6EA1A]');

    rerender(<ToggleButton {...defaultProps} value={false} />);
    expect(getByText('Enabled').className).toContain('bg-[#8AB6EA1A]');
    expect(getByText('Disabled').className).toContain('bg-[#8AB6EA80]');
  });
});