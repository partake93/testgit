import { render } from "@testing-library/react";
import "@testing-library/jest-dom";
import Icons, { IconsProps } from "./Icons";
import { iconNameSet } from "./Icon";

describe("Icons Component", () => {
  const defaultProps: IconsProps = {
    size: 24,
    color: "#ffffff",
  };

  const iconNames = iconNameSet;

  iconNames.forEach((iconName) => {
    it(`renders the correct icon for name="${iconName}"`, () => {
      const { container } = render(
        <Icons {...defaultProps} name={iconName as any} />
      );
      expect(container.querySelector("svg")).toBeInTheDocument();
    });
  });

  it("renders an empty fragment when name is undefined", () => {
    const { container } = render(<Icons />);
    expect(container.firstChild).toBeNull();
  });

  it("renders an empty fragment for unknown name", () => {
    const { container } = render(<Icons name={"nonExistentIcon" as any} />);
    expect(container.firstChild).toBeNull();
  });
});
