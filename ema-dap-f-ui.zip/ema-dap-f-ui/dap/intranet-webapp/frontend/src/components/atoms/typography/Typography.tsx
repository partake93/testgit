import * as React from "react";
import styles from "./Typography.module.scss";

const Typography: React.FC<TypographyProps> = ({
  variant,
  as: Component = "div",
  children,
  className,
  style,
  onClick,
  ...props
}) => {
  return (
    <Component {...props}
      className={`${styles[`typography-${variant}`]} ${className && className}`}
      style={style} onClick={onClick}
    >
      {children}
    </Component>
  );
};

export default Typography;

export interface TypographyProps {
  variant: typographyvar;
  as?: keyof React.JSX.IntrinsicElements;
  children?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  onClick?: () => void;
  [key: string]: any;
}

export type typographyvar =
  | "header01"
  | "header02"
  | "header03"
  | "header04"
  | "header05"
  | "hyperlink"
  | "lead01"
  | "lead02"
  | "lead03"
  | "label01"
  | "bodyregular"
  | "captionregular"
  | "smallcaption"
  | "xsmallcaption"
  | "notification"
  | "mediumCaption"
  | "status";
