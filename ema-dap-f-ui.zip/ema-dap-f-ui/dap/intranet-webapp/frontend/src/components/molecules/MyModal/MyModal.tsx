import * as React from "react";
import Typography from "../../atoms/typography/Typography";
import Button from "../Button/Button";

const MyModal: React.FC<MyModalProps> = ({
  show,
  onClose,
  title,
  children,
  actionButtonLabel,
  action,
  isItFullScreen = true,
}) => {
  const modalRef = React.useRef<HTMLDivElement>(null);

  // Prevent background scrolling and focus modal when open
  React.useEffect(() => {
    if (isItFullScreen) {
      if (show) {
        document.body.style.overflow = "hidden";
        // Focus the modal for accessibility
        modalRef.current?.focus();
      } else {
        document.body.style.overflow = "";
      }
      // Cleanup on unmount
      return () => {
        document.body.style.overflow = "";
      };
    }
  }, [show]);

  // Close the modal if the backdrop is clicked
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };
  if (!show) return null;
  return (
    <>
      <div
        className={`local-modal-backdrop ${isItFullScreen ? "h-[100vh]!" : ""}`}
        onClick={handleBackdropClick}
        tabIndex={-1}
        ref={modalRef}
        aria-modal="true"
        role="dialog"
        style={{ outline: "none" }}
      >
        <div className={`local-modal shadow-2xl`}>
          <Typography variant="header04" className="py-0.5 text-white">
            {title &&
              title.replace(
                /\w\S*/g,
                (txt) =>
                  txt.charAt(0).toUpperCase() + txt.slice(1).toLowerCase()
              )}
          </Typography>
          {/* <button onClick={onClose} className="close-btn">&times;</button> */}
          <Typography variant="mediumCaption" className="py-0.5 min-h-12">
            {children}
          </Typography>
          <div
            className={`flex ${
              actionButtonLabel ? "justify-between" : "justify-end"
            } py-0.5`}
          >
            <Button
              label={actionButtonLabel ? "Cancel" : "Close"}
              variant="mediumCaption"
              hasBorder={false}
              hasIcon={false}
              isActive={true}
              onClick={onClose}
              className={`${
                actionButtonLabel ? "button-light" : "button-dark"
              } rounded-sm! px-2 py-0.5 shadow-2xl`}
            />
            {actionButtonLabel && action && (
              <Button
                label={actionButtonLabel}
                variant="mediumCaption"
                hasBorder={false}
                hasIcon={false}
                isActive={true}
                onClick={action}
                className="button-dark rounded-sm! px-2 py-0.5 shadow-2xl"
              />
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default MyModal;

interface MyModalProps {
  show: boolean;
  onClose: () => void;
  title?: string;
  children?: React.ReactNode;
  actionButtonLabel?: string;
  action?: () => void;
  isItFullScreen?: boolean;
}
