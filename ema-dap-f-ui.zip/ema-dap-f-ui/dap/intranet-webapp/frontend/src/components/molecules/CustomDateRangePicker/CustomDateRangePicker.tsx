import * as React from "react";
import { isValid, isBefore, isAfter, startOfDay, setSeconds, setMilliseconds, isEqual } from "date-fns";
import Icons from "../../atoms/Icons/Icons";
import { formatDate } from "../../../utils/date";
import { date_const } from "../../../utils/constants";
import Typography from "../../atoms/typography/Typography";
import DatePicker from "react-datepicker";
import Button from "../Button/Button";

const CustomDateRangePicker: React.FC<{
  saveDate: (start_date: string, end_date: string) => void;
  start_date?: string;
  end_date?: string;
  isPill?: boolean;
  clearDate?: () => void;
  isActive?: boolean;
  showError?: boolean;
  allowPastDates?: boolean;
  [key: string]: any;
}> = ({
  saveDate,
  start_date,
  end_date,
  isPill = false,
  clearDate,
  isActive = true,
  showError = false,
  allowPastDates = true,
  className = ""
}) => {
  const [startDate, setStartDate] = React.useState<Date | null>(
    start_date ? new Date(start_date) : null
  );
  const [endDate, setEndDate] = React.useState<Date | null>(
    end_date ? new Date(end_date) : null
  );
  const [showPicker, setShowPicker] = React.useState<boolean>(false);
  const [error, setError] = React.useState<boolean>(showError);
  const [errorMessage, setErrorMessage] = React.useState<string>("");
  const pickerRef = React.useRef<HTMLDivElement | null>(null);
  const inputRef = React.useRef<HTMLInputElement | null>(null);

  React.useEffect(() => {
    setStartDate(start_date ? new Date(start_date) : null);
    setEndDate(end_date ? new Date(end_date) : null);
  }, [start_date, end_date]);

  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (pickerRef.current && !pickerRef.current.contains(event.target as Node)) {
        setShowPicker(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  React.useEffect(() => {
    setError(showError);
  }, [showError]);

  const syncAndSaveDate = (start: Date | null, end: Date | null) => {
    if (start && end && !isBefore(end, start)) {
      saveDate(start.toISOString(), end.toISOString());
      setError(false);
      setErrorMessage("");
    }
  };

  const handleStartChange = (date: Date | null) => {
    if (!date || !isValid(date)) {
      setError(true);
      setErrorMessage(date_const.invalidDate);
      return;
    }

    if (!allowPastDates && isBefore(startOfDay(date), startOfDay(new Date()))) {
      setError(true);
      setErrorMessage(date_const.pastDateError);
      return;
    }

    if (endDate && isAfter(date, endDate)) {
      setEndDate(null);
      setError(true);
      setErrorMessage(date_const.endDateError);
      setStartDate(date);
      return;
    } else {
      setError(false);
      setErrorMessage("");
    }

    setStartDate(date);
    syncAndSaveDate(date, endDate);
  };

  const handleEndChange = (date: Date | null) => {
    if (!date || !isValid(date)) {
      setError(true);
      setErrorMessage(date_const.invalidDate);
      return;
    }

    if (!allowPastDates && isBefore(startOfDay(date), startOfDay(new Date()))) {
      setError(true);
      setErrorMessage(date_const.pastDateError);
      return;
    }

    if (startDate && isBefore(date, startDate)) {
      setError(true);
      setErrorMessage(date_const.endDateError);
      return;
    }

    // Ensure end date includes the full selected minute
    const inclusiveEndDate = setMilliseconds(setSeconds(date, 59), 999);

    setEndDate(inclusiveEndDate);
    setError(false);
    setErrorMessage("");
    syncAndSaveDate(startDate, inclusiveEndDate);
  };

  const handleSave = () => {
    if (!startDate || !endDate) {
      setError(true);
      setErrorMessage(date_const.dateRequired);
      return;
    }
    if (isBefore(endDate, startDate) || isEqual(endDate, startDate)) {
      setError(true);
      setErrorMessage(date_const.endDateError);
      return;
    }
    setError(false);
    setErrorMessage("");
    setShowPicker(false);
    saveDate(startDate.toISOString(), endDate.toISOString());
  };

  const handleShowPicker = () => {
    setShowPicker((prev) => !prev);
  };

  const formattedRange =
    startDate && endDate
      ? `${formatDate(startDate)} → ${formatDate(endDate)}`
      : "";

  return (
    <>
      <Typography
        variant="captionregular"
        className={`relative ${!isPill ? "md:w-1/2" : ""} text-black`}
      >
        <input
          ref={inputRef}
          type="text"
          readOnly
          aria-label="Date range selector"
          role="button"
          className={`${isPill ? "p-0.5 px-2 rounded-full!" : "px-1.5 p-0.5"} ${
            error ? "border-red-500!" : ""
          } w-full border rounded cursor-pointer text-white overflow-hidden overflow-ellipsis whitespace-nowrap ${className} `}
          placeholder="Start - End"
          value={formattedRange}
          onClick={handleShowPicker}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") handleShowPicker();
          }}
          tabIndex={0}
          disabled={!isActive}
        />

        <div
          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 cursor-pointer"
          onClick={() => setShowPicker(!showPicker)}
        >
          <Icons name="calendar" size={10} />
        </div>

        {showPicker && (
          <div
            ref={pickerRef}
            className="absolute z-10 mt-2 bg-white border shadow-md p-4 rounded space-y-3 min-w-[250px] max-w-[90vw]"
          >
            <div className="relative">
              <div className="block mb-1">Start Date</div>
              <DatePicker
                selected={startDate}
                onChange={handleStartChange}
                showTimeSelect
                timeIntervals={5}
                dateFormat="Pp"
                placeholderText="Select start date"
                className="border-1 rounded px-2 p-1 w-full"
                minDate={allowPastDates ? undefined : new Date()}
                shouldCloseOnSelect={true}
              />
            </div>
            <div>
              <div className="block mb-1">End Date</div>
              <DatePicker
                selected={endDate}
                onChange={handleEndChange}
                showTimeSelect
                timeIntervals={5}
                dateFormat="Pp"
                placeholderText="Select End date"
                className="border-1 rounded px-2 p-1 w-full"
                minDate={
                  allowPastDates
                    ? startDate || undefined
                    : startDate || new Date()
                }
                shouldCloseOnSelect={true}
              />
            </div>

            <div className="flex justify-between gap-2">
              {clearDate && (
                <Button
                  hasIcon={true}
                  icon={{ name: "trash", size: 16 }}
                  onClick={() => {
                    clearDate();
                    setStartDate(null);
                    setEndDate(null);
                    setShowPicker(false);
                  }}
                  className="w-fit px-2 bg-red-500 py-1 rounded"
                  title="Clear Date"
                />
              )}

              <Button
                hasIcon={false}
                label="Save"
                onClick={handleSave}
                className="w-fit px-2 bg-blue-600 text-white py-1 rounded"
              />
            </div>
          </div>
        )}
      </Typography>
      {error && errorMessage !== "" && (
        <Typography variant="smallcaption" className="text-red-500">
          {errorMessage}
        </Typography>
      )}
    </>
  );
};

export default CustomDateRangePicker;
