import { render, screen, fireEvent } from "@testing-library/react";
import { MemoryRouter, useNavigate } from "react-router-dom";
import ModuleTile, { ModuleTileProps } from "./ModuleTile";
import { routes } from "../../../utils/routes";

// Mock navigate from react-router-dom
jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useNavigate: jest.fn(),
}));

// Mock Icons to avoid SVG rendering complexity
jest.mock("../../atoms/Icons/Icons", () => (props: any) => (
  <div data-testid={`icon-${props.name}`}>{props.name}</div>
));

// Mock PopOver (simplified)
jest.mock("../../Organisms/PopOver", () => ({ children, description }: any) => (
  <div title={description}>{children}</div>
));

describe("ModuleTile", () => {
  const baseProps: ModuleTileProps = {
    IconName: "dashboard",
    title: "Module Title",
    tooltip: "This is a tooltip",
    onclick: jest.fn(),
  };

  const mockNavigate = jest.fn();

  beforeEach(() => {
    (useNavigate as jest.Mock).mockReturnValue(mockNavigate);
    jest.clearAllMocks();
  });

  const renderComponent = (props: Partial<ModuleTileProps> = {}) =>
    render(
      <MemoryRouter>
        <ModuleTile {...baseProps} {...props} />
      </MemoryRouter>
    );

  test("renders the component with title, icon, and tooltip", () => {
    renderComponent();

    expect(screen.getByText("Module Title")).toBeInTheDocument();
    expect(screen.getByTestId("icon-dashboard")).toBeInTheDocument();
    expect(screen.getByTitle("This is a tooltip")).toBeInTheDocument();
  });

  test("calls onclick when active and clicked", () => {
    renderComponent({ isActive: true });

    fireEvent.click(screen.getByRole("button"));
    expect(baseProps.onclick).toHaveBeenCalled();
  });

  test("navigates to module request URL when inactive", () => {
    renderComponent({ isActive: false, moduleId: 42 });

    fireEvent.click(screen.getByRole("button"));
    expect(mockNavigate).toHaveBeenCalledWith(`${routes.moduleRequest}?id=42`);
  });

  test("renders the eye icon when showEye is true", () => {
    renderComponent({ showEye: true });

    expect(screen.getByTestId("icon-closedEye")).toBeInTheDocument();
  });

  test("does not render eye icon when showEye is false", () => {
    renderComponent({ showEye: false });

    expect(screen.queryByTestId("icon-closedEye")).not.toBeInTheDocument();
  });

  test("handles keyboard Enter key for activation", () => {
    renderComponent({ isActive: true });

    fireEvent.keyDown(screen.getByRole("button"), { key: "Enter" });
    expect(baseProps.onclick).toHaveBeenCalled();
  });

  test("handles keyboard Space key for activation", () => {
    renderComponent({ isActive: true });

    fireEvent.keyDown(screen.getByRole("button"), { key: " " });
    expect(baseProps.onclick).toHaveBeenCalled();
  });

  test("is aria-disabled and not clickable when inactive", () => {
    renderComponent({ isActive: false });

    expect(screen.getByRole("button")).toHaveAttribute("aria-disabled", "true");
  });
});