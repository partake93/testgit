import { render, screen, fireEvent } from "@testing-library/react";
import { useEditor } from "@tiptap/react";
import { useAlert } from "../../../context/AlertContext";
import MyEditor, { EditorProps } from "./MyEditor";

// Mock tiptap editor API
jest.mock("@tiptap/react", () => {
  const actual = jest.requireActual("@tiptap/react");
  return {
    ...actual,
    useEditor: jest.fn(),
    // Pass className through so error border can be tested
    EditorContent: ({ editor, className }: any) => (
      <div data-testid="editor-content" className={className}>
        {editor?.getHTML?.()}
      </div>
    ),
  };
});

// Mock alert context
jest.mock("../../../context/AlertContext", () => ({
  useAlert: jest.fn(),
}));

// Create a mock editor with chainable methods
const mockChain: any = {
  focus: jest.fn(() => mockChain),
  toggleBold: jest.fn(() => mockChain),
  toggleItalic: jest.fn(() => mockChain),
  toggleUnderline: jest.fn(() => mockChain),
  setColor: jest.fn(() => mockChain),
  setLink: jest.fn(() => mockChain),
  unsetLink: jest.fn(() => mockChain),
  insertContent: jest.fn(() => mockChain),
  run: jest.fn(),
  extendMarkRange: jest.fn(() => mockChain),
};

const mockEditor = {
  chain: () => mockChain,
  getHTML: jest.fn(() => "<p>Initial</p>"),
  getText: jest.fn(() => "Initial"),
  commands: {
    setContent: jest.fn(),
  },
  state: {
    doc: {
      textBetween: jest.fn(() => "selected"),
    },
    selection: {
      from: 0,
      to: 0,
    },
  },
};

const mockShowAlert = jest.fn();

describe("MyEditor Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (useEditor as jest.Mock).mockReturnValue(mockEditor);
    (useAlert as jest.Mock).mockReturnValue({ showAlert: mockShowAlert });
  });

  const renderEditor = (props: Partial<EditorProps> = {}) =>
    render(<MyEditor onUpdate={jest.fn()} {...props} />);

  // ---------- RENDER BASICS ----------
  test("renders editor content successfully", () => {
    renderEditor();
    expect(screen.getByTestId("editor-content")).toBeInTheDocument();
  });

  test("initializes with passed value", () => {
    renderEditor({ value: "<p>Hello</p>" });
    expect(mockEditor.commands.setContent).toHaveBeenCalledWith("<p>Hello</p>");
  });

  // ---------- TOOLBAR BUTTONS ----------
  test("clicking Bold triggers toggleBold and run", () => {
    renderEditor();
    fireEvent.click(screen.getByTitle("Bold"));
    expect(mockChain.toggleBold).toHaveBeenCalled();
    expect(mockChain.run).toHaveBeenCalled();
  });

  test("clicking Italic triggers toggleItalic and run", () => {
    renderEditor();
    fireEvent.click(screen.getByTitle("Italic"));
    expect(mockChain.toggleItalic).toHaveBeenCalled();
    expect(mockChain.run).toHaveBeenCalled();
  });

  test("clicking Underline triggers toggleUnderline and run", () => {
    renderEditor();
    fireEvent.click(screen.getByTitle("Underline"));
    expect(mockChain.toggleUnderline).toHaveBeenCalled();
    expect(mockChain.run).toHaveBeenCalled();
  });

  // ---------- TEXT COLOR ----------
  test("clicking Text Color toggles input visibility", () => {
    renderEditor();
    const colorBtn = screen.getByTitle("Text Color");
    fireEvent.click(colorBtn);
    expect(screen.getByTitle("Pick text color")).toBeInTheDocument();
  });

  test("changing color input calls setColor", () => {
    renderEditor();
    fireEvent.click(screen.getByTitle("Text Color"));
    const colorInput = screen.getByTitle("Pick text color");
    fireEvent.change(colorInput, { target: { value: "#ff0000" } });
    expect(mockChain.setColor).toHaveBeenCalledWith("#ff0000");
    expect(mockChain.run).toHaveBeenCalled();
  });

  // ---------- LINK INSERTION ----------
  test("clicking Hyperlink opens the modal", () => {
    renderEditor();
    fireEvent.click(screen.getByTitle("Hyperlink"));

    // const modal = screen.getByRole("dialog");
    // Use a flexible matcher to avoid issues with casing and spacing
    expect(
      screen.getByText((content) =>
        content.toLowerCase().includes("insert a url")
      )
    ).toBeInTheDocument();
  });

  test("modal displays selected text", () => {
    renderEditor();
    fireEvent.click(screen.getByTitle("Hyperlink"));
    expect(screen.getByPlaceholderText("Link text")).toHaveValue("selected");
  });

  test("Add with invalid URL shows alert", () => {
    renderEditor();
    fireEvent.click(screen.getByTitle("Hyperlink"));
    fireEvent.change(screen.getByPlaceholderText("https://example.com"), {
      target: { value: "invalid" },
    });
    fireEvent.click(screen.getByText("Add"));
    expect(mockShowAlert).toHaveBeenCalledWith(
      "Please enter the valid URL",
      "danger"
    );
  });

  test("Add with valid URL calls setLink or insertContent", () => {
    mockEditor.state.selection.from = 0;
    mockEditor.state.selection.to = 5;

    renderEditor();
    fireEvent.click(screen.getByTitle("Hyperlink"));
    fireEvent.change(screen.getByPlaceholderText("https://example.com"), {
      target: { value: "https://test.com" },
    });
    fireEvent.click(screen.getByText("Add"));

    expect(mockChain.setLink).toHaveBeenCalledWith({
      href: "https://test.com",
    });
    expect(mockChain.run).toHaveBeenCalled();
  });

  // ---------- REMOVE LINK ----------
  test("clicking Remove Hyperlink triggers unsetLink and run", () => {
    renderEditor();
    fireEvent.click(screen.getByTitle("Remove Hyperlink"));
    expect(mockChain.unsetLink).toHaveBeenCalled();
    expect(mockChain.run).toHaveBeenCalled();
  });

  // ---------- CHARACTER COUNTER ----------
  test("displays current character count", () => {
    renderEditor({ CHARACTER_LIMIT: 50 });
    // The mock returns "Initial" (7 chars), so expect 7/50
    expect(screen.getByText("7/50 characters left")).toBeInTheDocument();
  });

  // ---------- ERROR STYLING ----------
  test("applies error border when showError is true and content is empty", () => {
    mockEditor.getText = jest.fn(() => "");
    mockEditor.getHTML = jest.fn(() => "<p></p>");
    renderEditor({ showError: true });
    expect(screen.getByTestId("editor-content").className).toMatch(
      /border-red-500/
    );
  });

  // ---------- DISABLED STATE ----------
  test("formatting buttons are disabled when isActive is false", () => {
    renderEditor({ isActive: false });
    const buttons = screen.getAllByRole("button");
    buttons.forEach((btn) => {
      expect(btn).toHaveAttribute("disabled");
    });
  });

  // ---------- PROP UPDATES ----------
  test("editor content updates on value prop change", () => {
    const { rerender } = renderEditor({ value: "<p>Old</p>" });
    rerender(<MyEditor onUpdate={jest.fn()} value="<p>New</p>" />);
    expect(mockEditor.commands.setContent).toHaveBeenCalledWith("<p>New</p>");
  });
});
