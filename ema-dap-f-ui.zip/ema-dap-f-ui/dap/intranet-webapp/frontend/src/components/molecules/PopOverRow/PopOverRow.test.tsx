import { render, screen, fireEvent } from "@testing-library/react";
import PopOverRow, { PopOverRowProps } from "./PopOverRow";

describe("PopOverRow", () => {
  const baseProps: PopOverRowProps = {
    content: "Test content",
    hasRightIcon: false,
    hasLeftIcon: false,
  };

  it("renders content correctly", () => {
    render(<PopOverRow {...baseProps} />);
    expect(screen.getByText("Test content")).toBeInTheDocument();
  });

  it("renders right icon when hasRightIcon is true", () => {
    const { container } = render(
      <PopOverRow {...baseProps} hasRightIcon={true} rightIcon="rightArrow" />
    );
    expect(container.querySelector("svg")).toBeInTheDocument();
  });

  it("renders left icon when hasLeftIcon is true", () => {
    const { container } = render(
      <PopOverRow {...baseProps} hasLeftIcon={true} leftIcon="leftArrow" />
    );
    expect(container.querySelector("svg")).toBeInTheDocument();
  });

  it("calls onClick when main div is clicked", () => {
    const onClick = jest.fn();
    render(<PopOverRow {...baseProps} onClick={onClick} />);
    // The clickable div wraps the whole content, so get the container div instead of just text's parent
    fireEvent.click(screen.getByText("Test content").closest("div")!);
    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it("calls rightSideClick when right icon is clicked", () => {
    const rightSideClick = jest.fn();
    const { container } = render(
      <PopOverRow
        {...baseProps}
        hasRightIcon={true}
        rightIcon="rightArrow"
        rightSideClick={rightSideClick}
      />
    );
    const rightIconSvg = container.querySelector("svg");
    if (rightIconSvg && rightIconSvg.parentElement) {
      fireEvent.click(rightIconSvg.parentElement);
    }
    expect(rightSideClick).toHaveBeenCalledTimes(1);
  });

  it("calls leftSideClick when left icon is clicked", () => {
    const leftSideClick = jest.fn();
    const { container } = render(
      <PopOverRow
        {...baseProps}
        hasLeftIcon={true}
        leftIcon="circleWithX"
        leftSideClick={leftSideClick}
      />
    );
    const leftIconSvg = container.querySelector("svg");
    if (leftIconSvg && leftIconSvg.parentElement) {
      fireEvent.click(leftIconSvg.parentElement);
    }
    expect(leftSideClick).toHaveBeenCalledTimes(1);
  });
});
