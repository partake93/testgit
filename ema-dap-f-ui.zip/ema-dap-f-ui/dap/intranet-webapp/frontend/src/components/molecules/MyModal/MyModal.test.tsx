import { render, screen, fireEvent } from "@testing-library/react";
import MyModal from "./MyModal";

describe("MyModal", () => {
  const onClose = jest.fn();
  const action = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("does not render when show is false", () => {
    const { container } = render(<MyModal show={false} onClose={onClose} />);
    expect(container.firstChild).toBeNull();
  });

  it("renders title with correct capitalization", () => {
    render(<MyModal show={true} onClose={onClose} title="hello world" />);
    expect(screen.getByText("Hello World")).toBeInTheDocument();
  });

  it("renders children content", () => {
    render(<MyModal show={true} onClose={onClose}>Modal content</MyModal>);
    expect(screen.getByText("Modal content")).toBeInTheDocument();
  });

  it("calls onClose when backdrop is clicked", () => {
    render(<MyModal show={true} onClose={onClose} />);
    fireEvent.click(screen.getByRole("dialog").parentElement!); // backdrop div is the parent of modal
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it("does NOT call onClose when modal content is clicked", () => {
    render(<MyModal show={true} onClose={onClose} />);
    fireEvent.click(screen.getByRole("dialog"));
    expect(onClose).not.toHaveBeenCalled();
  });

  it("renders Cancel button and calls onClose when clicked", () => {
    render(<MyModal show={true} onClose={onClose} actionButtonLabel="Save" />);
    const cancelButton = screen.getByText("Cancel");
    expect(cancelButton).toBeInTheDocument();
    fireEvent.click(cancelButton);
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it("renders action button and calls action when clicked", () => {
    render(<MyModal show={true} onClose={onClose} actionButtonLabel="Save" action={action} />);
    const actionButton = screen.getByText("Save");
    expect(actionButton).toBeInTheDocument();
    fireEvent.click(actionButton);
    expect(action).toHaveBeenCalledTimes(1);
  });

  it("renders Close button when no actionButtonLabel is provided", () => {
    render(<MyModal show={true} onClose={onClose} />);
    const closeButton = screen.getByText("Close");
    expect(closeButton).toBeInTheDocument();
  });

  it("applies fullscreen class when isItFullScreen is true", () => {
    const { container } = render(<MyModal show={true} onClose={onClose} isItFullScreen={true} />);
    expect(container.firstChild).toHaveClass("h-[100vh]!");
  });

  it("does not apply fullscreen class when isItFullScreen is false", () => {
    const { container } = render(<MyModal show={true} onClose={onClose} isItFullScreen={false} />);
    expect(container.firstChild).not.toHaveClass("h-[100vh]!");
  });
});