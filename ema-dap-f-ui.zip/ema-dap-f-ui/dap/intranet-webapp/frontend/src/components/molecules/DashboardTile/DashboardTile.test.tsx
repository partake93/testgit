import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import DashboardTile from "./DashboardTile";
import * as service from "../../../services/dashboardService";
import { useErrorManager } from "../../../utils/manageApiError";
import { Dashboard } from "../../../types/Dashboards";
import { useModalPopup } from "../../../context/ModalPopupContext";
import { dashboard_const } from "../../../utils/constants";

jest.mock("../../../utils/getEnv", () => ({
  getEnv: (key: string) => {
    if (key === "VITE_BACKEND_URL") return "https://mock-api.com";
    return "";
  },
}));

jest.mock("../../../services/dashboardService");
jest.mock("../../../context/ModalPopupContext");
jest.mock("../../../utils/manageApiError");

const mockShowModal = jest.fn();
const mockErrorManager = jest.fn();

const mockDashboard: Dashboard = {
    id: 1,
    title: "Sample Dashboard",
    version: "1.0",
    description: "Dashboard description",
    is_starred: false,
    url: "https://example.com/dashboard",
    order_index: 0,
    created_at: new Date(),
    created_by: 0,
    notes: "",
    status: "",
    updated_at: new Date(),
    updated_by: 0,
    updated_by_first_name: "",
    updated_by_last_name: "",
    categories: []
};

describe("DashboardTile", () => {
  beforeEach(() => {
    (useModalPopup as jest.Mock).mockReturnValue({ showModal: mockShowModal });
    (useErrorManager as jest.Mock).mockReturnValue(mockErrorManager);
    jest.clearAllMocks();
  });

  test("renders dashboard title, version, and description", () => {
    render(<DashboardTile dashboard={mockDashboard} />);
    expect(screen.getByText("Sample Dashboard")).toBeInTheDocument();
    expect(screen.getByText("v1.0")).toBeInTheDocument();
    expect(screen.getByText("Dashboard description")).toBeInTheDocument();
  });

  test("toggles star and shows success modal", async () => {
    (service.starDashboard as jest.Mock).mockResolvedValue({ status: "success" });

    render(<DashboardTile dashboard={mockDashboard} />);
    const starButton = screen.getByTestId("star-button");

    fireEvent.click(starButton);

    await waitFor(() => {
      expect(service.starDashboard).toHaveBeenCalledWith(1);
      expect(mockShowModal).toHaveBeenCalledWith(
        expect.objectContaining({ title: "success" })
      );
    });
  });

  test("shows error modal if API returns error", async () => {
    (service.starDashboard as jest.Mock).mockResolvedValue({
      status: "error",
      message: "Failed to star",
    });

    render(<DashboardTile dashboard={mockDashboard} />);
        const starButton = screen.getByTestId("star-button");


    fireEvent.click(starButton);

    await waitFor(() => {
      expect(mockShowModal).toHaveBeenCalledWith(
        expect.objectContaining({
          message: expect.stringContaining("Failed to star"),
          title: "error",
        })
      );
    });
  });

  test("calls errorManager on thrown exception", async () => {
    const error = new Error("Network Error");
    (service.starDashboard as jest.Mock).mockRejectedValue(error);

    render(<DashboardTile dashboard={mockDashboard} />);
        const starButton = screen.getByTestId("star-button");


    fireEvent.click(starButton);

    await waitFor(() => {
      expect(mockErrorManager).toHaveBeenCalledWith(error);
    });
  });

  test("opens dashboard URL in new tab on button click", () => {
    window.open = jest.fn();

    render(<DashboardTile dashboard={mockDashboard} />);
    const button = screen.getByRole("button", { name: dashboard_const.goToDashboard });
    fireEvent.click(button);

    expect(window.open).toHaveBeenCalledWith("https://example.com/dashboard", "_blank");
  });
});