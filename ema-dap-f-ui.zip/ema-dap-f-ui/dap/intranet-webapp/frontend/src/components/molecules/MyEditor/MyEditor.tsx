import * as React from "react";
import { useEditor, EditorContent } from "@tiptap/react";
import { EditorView } from "prosemirror-view";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import TextStyle from "@tiptap/extension-text-style";
import Color from "@tiptap/extension-color";
import Link from "@tiptap/extension-link";
import styles from "../../../styles/editor.module.scss";
import Typography from "../../atoms/typography/Typography";
import MyModal from "../MyModal/MyModal";
import { useAlert } from "../../../context/AlertContext";
import { isValidUrl } from "../../../utils/functions";
import Button from "../Button/Button";
import { modalString } from "../../../utils/modal";

const MyEditor: React.FC<EditorProps> = ({
  CHARACTER_LIMIT = 34,
  onUpdate,
  value = "",
  showError = false,
  isActive = true,
}) => {
  const [toggleColorView, switchColorView] = React.useState(false);
  const [modalShow, setModalShow] = React.useState(false);
  const [linkText, setLinkText] = React.useState("");
  const [linkUrl, setLinkUrl] = React.useState("https://");

  const { showAlert } = useAlert();

  React.useEffect(() => {
    if (editor && value !== editor.getHTML()) {
      editor.commands.setContent(value);
    }
  }, [value]);

  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: false, // disables heading
      }),
      Underline,
      TextStyle,
      Color,
      Link.configure({
        openOnClick: false,
      }),
    ],
    content: "",
    editable: isActive,
    onUpdate: () => {
      if (editor) {
        const html = editor.getHTML();
        onUpdate(html);
      }
    },
    editorProps: {
      handleDOMEvents: {
        beforeinput: (view: EditorView, event: InputEvent) => {
          const currentLength = view.state.doc.textContent.length;
          const incomingText = (event as InputEvent).data || "";
          const incomingLength = incomingText.length;

          if (currentLength + incomingLength > CHARACTER_LIMIT) {
            event.preventDefault(); // block typing
            return true;
          }

          return false;
        },
        paste: (view: EditorView, event: ClipboardEvent) => {
          const pasteText = event.clipboardData?.getData("text") || "";
          const currentLength = view.state.doc.textContent.length;

          if (currentLength + pasteText.length > CHARACTER_LIMIT) {
            event.preventDefault(); // block paste
            return true;
          }

          return false;
        },
      },
    },
  });

  const html = editor?.getHTML();
  const text = editor?.getText().trim();
  const isEmpty = text === "" || html === "<p></p>";

  if (!editor) return null;

  const setColor = (color: string) =>
    editor.chain().focus().setColor(color).run();

  // const setLink = () => {
  // const url = prompt("Enter URL");
  // if (url) {
  //   editor
  //     .chain()
  //     .focus()
  //     .extendMarkRange("link")
  //     .setLink({ href: url })
  //     .run();
  // }
  // };

  const setLink = () => {
    const selectedText =
      editor?.state?.doc.textBetween(
        editor.state.selection.from,
        editor.state.selection.to,
        " "
      ) || "";
    setLinkText(selectedText || "");
    setLinkUrl("https://"); // clear previous URL
    setModalShow(true);
  };

  const handleInsertLink = () => {
    if (!linkUrl.trim() || !isValidUrl(linkUrl)) {
      showAlert("Please enter the valid URL", "danger");
      return;
    }
    editor.chain().focus();

    const selection = editor.state.selection;
    const hasSelection = selection.from !== selection.to;

    if (hasSelection) {
      editor
        .chain()
        .extendMarkRange("link")
        .setLink({ href: linkUrl.trim() })
        .run();
    } else {
      editor
        .chain()
        .insertContent([
          {
            type: "text",
            text: linkText || linkUrl,
            marks: [{ type: "link", attrs: { href: linkUrl.trim() } }],
          },
        ])
        .run();
    }

    setModalShow(false);
    setLinkText("");
    setLinkUrl("https://");
  };

  const unsetLink = () => editor.chain().focus().unsetLink().run();

  return (
    <>
      <div className="flex px-3.5 py-0.5 my-1 rounded-full bg-[#8AB6EA80] w-fit">
        <Button
          className="p-1"
          onClick={() => editor.chain().focus().toggleBold().run()}
          hasBorder={false} hasIcon={true} icon={{name: "bold", size: 10}}
          tooltip="Bold"
          title="Bold"
          isActive={isActive}
        />
        <Button
          className="p-1"
          onClick={() => editor.chain().focus().toggleItalic().run()}
          hasBorder={false} hasIcon={true} icon={{name: "italic", size: 10}}
          tooltip="Italic"
          title="Italic"
          isActive={isActive}
        />
        <Button
          className="p-1"
          onClick={() => editor.chain().focus().toggleUnderline().run()}
          hasBorder={false} hasIcon={true} icon={{name: "underline", size: 10}}
          tooltip="Underline"
          title="Underline"
          isActive={isActive}
        />
        <Button
          className="p-1"
          onClick={() => switchColorView(!toggleColorView)}
          hasBorder={false} hasIcon={true} icon={{name: "textColorEdit", size: 10}}
          tooltip="Text Color"
          title="Text Color"
          isActive={isActive}
        />
        <Button
          className="p-1"
          onClick={setLink}
          hasBorder={false} hasIcon={true} icon={{name: "hyperlink", size: 10}}
          tooltip="Hyperlink"
          title="Hyperlink"
          isActive={isActive}
        />
        <Button
          className="p-1"
          onClick={unsetLink}
          hasBorder={false} hasIcon={true} icon={{name: "removeHyperlink", size: 10}}
          tooltip="Remove Hyperlink"
          title="Remove Hyperlink"
          isActive={isActive}
        />
        <input
          className={`p-1 ${!toggleColorView && "hidden"}`}
          type="color"
          onChange={(e) => setColor(e.target.value)}
          title="Pick text color"
        />
      </div>
      <Typography variant="bodyregular">
        <EditorContent
          className={`${styles["editor-content"]} ${
            showError && isEmpty ? "border-red-500" : "border-gray-300"
          } bg-[#8AB6EA1A] border-1 rounded-md h-fit px-2.5`}
          editor={editor}
        />
      </Typography>
      <Typography variant="smallcaption" as="span">
        {`${editor.getText().length}/${CHARACTER_LIMIT} characters left`}
      </Typography>
      <MyModal
        title={modalString.textEditorTitle || "Add Hyperlink"}
        actionButtonLabel="Add"
        action={handleInsertLink}
        show={modalShow}
        onClose={() => setModalShow(false)}
      >
        <div className="flex flex-col gap-2 pt-2">
          <input
            type="text"
            className="border p-1 rounded text-sm"
            placeholder="Link text"
            value={linkText}
            onChange={(e) => setLinkText(e.target.value)}
          />
          <input
            type="url"
            className="border p-1 rounded text-sm"
            placeholder="https://example.com"
            value={linkUrl}
            onChange={(e) => setLinkUrl(e.target.value)}
          />
        </div>
      </MyModal>
    </>
  );
};

export default MyEditor;

export interface EditorProps {
  CHARACTER_LIMIT?: number;
  onUpdate: (content: string) => void;
  value?: string;
  showError?: boolean;
  isActive?: boolean;
}
