import { render, screen, fireEvent } from "@testing-library/react";
import QuickActionItem from "./QuickActionItem";

describe("QuickActionItem Component", () => {
  it("renders content correctly", () => {
    render(<QuickActionItem content="Open Link" />);
    expect(screen.getByText("Open Link")).toBeInTheDocument();
  });

  it("renders default icon when none is provided", () => {
    render(<QuickActionItem content="Open Link" />);
    expect(screen.getByRole("img", { name: /hyperlink/i })).toBeInTheDocument();
  });

  it("renders the passed icon if provided", () => {
    render(<QuickActionItem content="Go to Docs" icon="leftArrow" />);
    expect(screen.getByRole("img", { name: /leftArrow/i })).toBeInTheDocument();
  });

  it("calls onClick when right arrow icon is clicked", () => {
    const handleClick = jest.fn();
    render(<QuickActionItem content="Go" onClick={handleClick} />);
    const clickableIcon = screen.getByRole("img", { name: /rightArrow/i });
    fireEvent.click(clickableIcon);
    expect(handleClick).toHaveBeenCalledTimes(1);
  });
});