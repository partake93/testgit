import React from "react";
import Typography, { typographyvar } from "../../atoms/typography/Typography";
import Icons, { IconsProps } from "../../atoms/Icons/Icons";
import PopOver from "../../Organisms/PopOver";
import { classNames } from "../../../utils/classNames";

const Button: React.FC<ButtonProps> = ({
  label,
  variant = "captionregular",
  onClick,
  isActive = true,
  isDark = true,
  className = "",
  hasBorder = true,
  hasIcon = false,
  icon,
  iconOnLeft = true,
  style,
  tooltip = "",
  ...props
}) => {
  const Icon = hasIcon && (
    <span className="px-1">
      <Icons name={icon?.name} size={icon?.size} color={icon?.color} />
    </span>
  );

  const getButton = () => {
    return (
      <button
        onClick={onClick}
        disabled={!isActive}
        className={`flex items-center hoverObj ${className} ${
          isDark
            ? classNames.light + (hasBorder && classNames.border_light)
            : classNames.dark + (hasBorder && classNames.border_dark)
        } ${!isActive && "opacity-50"} `}
        style={style}
        {...props}
      >
        {hasIcon && iconOnLeft && Icon}
        <Typography variant={variant} as="span">
          {label}
        </Typography>
        {hasIcon && !iconOnLeft && Icon}
      </button>
    );
  };

  return (
    <>
      {tooltip !== "" ? (
        <PopOver trigger="hover" description={tooltip}>
          {getButton()}
        </PopOver>
      ) : (
        getButton()
      )}
    </>
  );
};

export default Button;

export interface ButtonProps {
  label?: string;
  variant?: typographyvar;
  onClick?: () => void;
  isActive?: boolean;
  isDark?: boolean;
  hasBorder?: boolean;
  hasIcon?: boolean;
  icon?: IconsProps;
  iconOnLeft?: boolean;
  className?: string;
  style?: React.CSSProperties;
  tooltip?: string;
  [key: string]: any;
}
