import * as React from "react";
import { IconName } from "../../atoms/Icons/Icon.type";
import Typography from "../../atoms/typography/Typography";
import Icons from "../../atoms/Icons/Icons";

const QuickActionItem: React.FC<{
  icon?: IconName;
  content: string;
  onClick?: () => void;
}> = ({ icon ="hyperlink", content, onClick }) => {

  return (
    <>
      <Typography
        variant="bodyregular"
        as="span"
        className="p-[0.25rem] w-full col-span-7 border-2 border-[#5C94D6] bg-[#5C94D680] rounded-xl grid grid-cols-8 items-center hoverObj"
      >
        <span className="col-span-1 flex justify-center">
          <Icons name={icon} size={15} />
        </span>
        <span className="col-span-6">{content}</span>
        <span
          className="col-span-1 flex justify-end cursor-pointer"
          onClick={onClick}
        >
          <Icons name="rightArrow" size={15} />
        </span>
      </Typography>
    </>
  );
};

export default QuickActionItem;
