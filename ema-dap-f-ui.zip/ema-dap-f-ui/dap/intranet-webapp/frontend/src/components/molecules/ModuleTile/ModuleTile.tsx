import * as React from "react";
import styles from "./ModuleTile.module.scss";
import { IconName } from "../../atoms/Icons/Icon.type";
import Typography from "../../atoms/typography/Typography";
import Icons from "../../atoms/Icons/Icons";
import PopOver from "../../Organisms/PopOver";
import { useNavigate } from "react-router-dom";
import { routes } from "../../../utils/routes";

const ModuleTile: React.FC<ModuleTileProps> = ({
  IconName,
  title,
  tooltip,
  isActive = true,
  showEye = false,
  moduleId = 0,
  pending = false,
  onclick = () => {},
}) => {
  const navigate = useNavigate();

  const handleTileClick = () => {
    if (isActive) {
      onclick?.();
    } else {
      navigate(`${routes.moduleRequest}?id=${moduleId}`);
    }
  };

  return (
    <>
      <div
        className={`${styles["modulesTile"]} shadow-md hoverObj ${
          !isActive ? "opacity-50 cursor-not-allowed" : ""
        }`}
        aria-disabled={!isActive}
        role="button"
        tabIndex={0}
        onClick={handleTileClick}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") handleTileClick();
        }}
      >
        <div className="flex justify-between">
          <span>
            <Icons name={IconName} size={30} />
          </span>
          <span>
            {pending && (
                <Typography
                  variant="status"
                  className="bg-status-yellow-500 text-black rounded-full text-center px-2 py-0.5 w-min"
                  title="REVIEWING REQUEST"
                >REVIEWING REQUEST
                </Typography>
            )}
            {showEye && <Icons name="closedEye" size={15} color="#FFB74E" />}
          </span>
        </div>
        <div className="flex justify-between">
          <Typography
            variant="lead01"
            as="span"
            className="text-left flex-wrap"
          >
            {title}
          </Typography>
          <span className="content-end">
            <PopOver trigger="hover" isTooltip={true} description={tooltip}>
              <Icons name="support" size={16} />
            </PopOver>
          </span>
        </div>
      </div>
    </>
  );
};

export default ModuleTile;

export interface ModuleTileProps {
  IconName: IconName;
  title: string;
  tooltip: string;
  isActive?: boolean;
  url?: string;
  showEye?: boolean;
  moduleId?: number;
  pending?: boolean;
  onclick?: () => void;
}
