import * as React from "react";
import Typography, { typographyvar } from "../../atoms/typography/Typography";

const StatusTag: React.FC<StatusTagProps> = ({
    label, variant = "smallcaption", className
}) =>{
    return(<>
        <Typography variant={variant} className={"flex justify-center rounded-xl items-center px-2 py-1 "+className} >{label}</Typography>
    </>);
}

export default StatusTag;

export interface StatusTagProps {
    label: string;
    variant?: typographyvar;
    className?: string;
}