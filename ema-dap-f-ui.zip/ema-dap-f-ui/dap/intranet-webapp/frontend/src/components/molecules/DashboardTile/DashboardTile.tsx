import * as React from "react";
import styles from "./DashboardTile.module.scss";
import { Dashboard } from "../../../types/Dashboards";
import Icons from "../../atoms/Icons/Icons";
import Typography from "../../atoms/typography/Typography";
import {
  dashboard_const,
} from "../../../utils/constants";
import Button from "../Button/Button";

const DashboardTile: React.FC<{ dashboard: Dashboard, starFunc:(id: number) => void}> = ({ dashboard, starFunc }) => {

  // const toggleStar = async (id: number) => {
  //   try {
  //     if (isLoading) return; // Prevent multiple clicks
  //     setIsLoading(true);
  //     const res = await service.starDashboard(id);
  //     if (res.status === api_status.error) {
  //       showModal({
  //         message: `${error_const.failed}: ${
  //           res.message || error_const.apiError
  //         }`,
  //         title: api_status.error,
  //       });
  //       return;
  //     }
  //     setIsStarred((prev) => !prev);
  //     showModal({
  //       message: is_starred
  //         ? dashboard_const.removeQuickActions
  //         : dashboard_const.addQuickActions,
  //       title: api_status.success,
  //     });
  //   } catch (error) {
  //     errorManager(error as Error | APIerror);
  //   } finally {
  //     setIsLoading(false);
  //   }
  // };

  return (
    <div className={`${styles["dashboardTile"]} shadow-md hoverObj`}>
      <span className="flex flex-col gap-2">
        <Typography variant="lead03" className="flex justify-between">
          <span className="flex items-end gap-1">
            <span className="line-clamp-1">
              {dashboard.title}
            </span>
            <Typography variant="smallcaption" as="span" className="p-0.5">
              v{dashboard.version}
            </Typography>
          </span>
          <span
            className="cursor-pointer"
            onClick={() => starFunc(dashboard.id)}
            role="button"
            data-testid="star-button"
          >
            <Icons name={dashboard.is_starred ? "starFilled" : "star"} size={12} />
          </span>
        </Typography>
        <Typography
          variant="label01"
          className="line-clamp-7"
          title={dashboard.description}
        >
          {dashboard.description}
        </Typography>
      </span>
      <span className="flex justify-end">
        <Button
          onClick={() =>
            window.open(dashboard.url, "_blank", "noopener,noreferrer")
          }
          label={dashboard_const.goToDashboard}
          variant="label01"
          hasBorder={false}
          hasIcon={true}
          iconOnLeft={false}
          isActive={true}
          icon={{ name: "rightArrow", size: 10 }}
          className="ps-3 pe-2 py-2 rounded-full! bg-secondary-03"
          aria-label={dashboard_const.goToDashboard}
        />
      </span>
    </div>
  );
};

export default DashboardTile;
