import { render, screen } from "@testing-library/react";
import StatusTag, { StatusTagProps } from "./StatusTag";

describe("StatusTag", () => {
  const baseProps: StatusTagProps = {
    label: "Active",
  };

  it("renders the label correctly", () => {
    render(<StatusTag {...baseProps} />);
    expect(screen.getByText("Active")).toBeInTheDocument();
  });

  it("applies default typography variant when none is provided", () => {
    render(<StatusTag {...baseProps} />);
    const element = screen.getByText("Active");
    // Check for default class, assuming variant "smallcaption" adds something specific
    expect(element.className).toContain("typography-smallcaption"); // Adjust if variant affects className
  });

  it("applies custom typography variant when provided", () => {
    render(<StatusTag {...baseProps} variant="captionregular" />);
    const element = screen.getByText("Active");
    expect(element.className).toContain("typography-caption"); // Adjust based on Typography implementation
  });

  it("applies custom className when provided", () => {
    render(<StatusTag {...baseProps} className="bg-green-500" />);
    const element = screen.getByText("Active");
    expect(element.className).toContain("bg-green-500");
  });

  it("combines default and custom classes correctly", () => {
    render(<StatusTag {...baseProps} className="custom-class" />);
    const element = screen.getByText("Active");
    expect(element.className).toContain("flex");
    expect(element.className).toContain("custom-class");
  });
});