import { useState } from "react";
import DatePicker from "react-datepicker";
import {
  isAfter,
  isBefore,
  parseISO,
} from "date-fns";
import "react-datepicker/dist/react-datepicker.css";

const DateTimeRangePicker = ({
  initialStart,
  initialEnd,
  onChange,
}: {
  initialStart?: Date | string;
  initialEnd?: Date | string;
  onChange: (start: Date, end: Date) => void;
}) => {
  const [startDate, setStartDate] = useState<Date | null>(
    initialStart ? (typeof initialStart === "string" ? parseISO(initialStart) : initialStart) : null
  );
  const [endDate, setEndDate] = useState<Date | null>(
    initialEnd ? (typeof initialEnd === "string" ? parseISO(initialEnd) : initialEnd) : null
  );
  const [error, setError] = useState("");

  const handleStartChange = (date: Date | null) => {
    setStartDate(date);
    if (date && endDate && isAfter(date, endDate)) {
      setEndDate(null); // reset if invalid
    }
    setError("");
  };

  const handleEndChange = (date: Date | null) => {
    if (startDate && date && isBefore(date, startDate)) {
      setError("End date must be after start date");
      return;
    }
    setEndDate(date);
    setError("");

    if (startDate && date) {
      onChange(startDate, date);
    }
  };

  return (
    <div className="datetime-range-container">
      <div className="picker-wrapper">
        <label className="picker-label">Start Date & Time</label>
        <DatePicker
          selected={startDate}
          onChange={handleStartChange}
          showTimeSelect
          timeIntervals={15}
          dateFormat="Pp"
          placeholderText="Select start date"
          className="picker-input"
        />
      </div>

      <div className="picker-wrapper">
        <label className="picker-label">End Date & Time</label>
        <DatePicker
          selected={endDate}
          onChange={handleEndChange}
          showTimeSelect
          timeIntervals={15}
          dateFormat="Pp"
          placeholderText="Select end date"
          minDate={startDate ?? undefined}
          className="picker-input"
        />
      </div>

      {error && <div className="error-text">{error}</div>}
    </div>
  );
};

export default DateTimeRangePicker;