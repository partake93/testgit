import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import CustomDateRangePicker from "./CustomDateRangePicker";
import moment from "moment";
import { date_const } from "../../../utils/constants";

jest.mock("react-datetime", () => (props: any) => {
  return (
    <input
      data-testid={`datetime-${props.inputProps.placeholder}`}
      value={props.value ? props.value.format("YYYY-MM-DD HH:mm") : ""}
      onChange={(e) =>
        props.onChange(moment(e.target.value, "YYYY-MM-DD HH:mm"))
      }
      placeholder={props.inputProps.placeholder}
    />
  );
});

describe("CustomDateRangePicker", () => {
  const saveDateMock = jest.fn();
  const clearDateMock = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("renders without crashing", () => {
    render(<CustomDateRangePicker saveDate={saveDateMock} />);
    expect(screen.getByLabelText("Date range selector")).toBeInTheDocument();
  });

  test("opens date picker on click", () => {
    render(<CustomDateRangePicker saveDate={saveDateMock} />);
    fireEvent.click(screen.getByLabelText("Date range selector"));
    expect(screen.getByText("Start Date")).toBeInTheDocument();
    expect(screen.getByText("End Date")).toBeInTheDocument();
  });

  test("displays error if start date is in the past", async () => {
    render(<CustomDateRangePicker saveDate={saveDateMock} />);
    fireEvent.click(screen.getByLabelText("Date range selector"));

    const pastDate = moment().subtract(1, "day").format("YYYY-MM-DD HH:mm");
    fireEvent.change(screen.getByTestId("datetime-Select start date"), {
      target: { value: pastDate },
    });

    await waitFor(() => {
      expect(screen.getByText(date_const.pastDateError)).toBeInTheDocument();
    });
  });

  test("displays error if end date is before start date", async () => {
    render(<CustomDateRangePicker saveDate={saveDateMock} />);
    fireEvent.click(screen.getByLabelText("Date range selector"));

    const start = moment().add(2, "days").format("YYYY-MM-DD HH:mm");
    const end = moment().add(1, "day").format("YYYY-MM-DD HH:mm");

    fireEvent.change(screen.getByTestId("datetime-Select start date"), {
      target: { value: start },
    });
    fireEvent.change(screen.getByTestId("datetime-Select end date"), {
      target: { value: end },
    });

    await waitFor(() => {
      expect(screen.getByText(date_const.endDateError)).toBeInTheDocument();
    });
  });

  test("calls saveDate on valid date range and save button click", async () => {
    render(<CustomDateRangePicker saveDate={saveDateMock} />);
    fireEvent.click(screen.getByLabelText("Date range selector"));

    const start = moment().add(1, "day").format("YYYY-MM-DD HH:mm");
    const end = moment().add(2, "days").format("YYYY-MM-DD HH:mm");

    fireEvent.change(screen.getByTestId("datetime-Select start date"), {
      target: { value: start },
    });
    fireEvent.change(screen.getByTestId("datetime-Select end date"), {
      target: { value: end },
    });

    fireEvent.click(screen.getByText("Done"));

    await waitFor(() => {
      expect(saveDateMock).toHaveBeenCalledWith(
        expect.any(String),
        expect.any(String)
      );
    });
  });

  test("clears dates on clear button click", async () => {
    render(
      <CustomDateRangePicker
        saveDate={saveDateMock}
        clearDate={clearDateMock}
        start_date={moment().add(1, "day").toISOString()}
        end_date={moment().add(2, "days").toISOString()}
      />
    );

    fireEvent.click(screen.getByLabelText("Date range selector"));
    fireEvent.click(screen.getByText("Clear Dates"));

    expect(clearDateMock).toHaveBeenCalled();
  });

  test("disables input when isActive is false", () => {
    render(<CustomDateRangePicker saveDate={saveDateMock} isActive={false} />);

    expect(screen.getByLabelText("Date range selector")).toBeDisabled();
  });

  test("shows error message when start date is in the past", async () => {
    render(<CustomDateRangePicker saveDate={saveDateMock} />);
    fireEvent.click(screen.getByLabelText("Date range selector"));

    const pastDate = moment().subtract(1, "day").format("YYYY-MM-DD HH:mm");

    fireEvent.change(screen.getByTestId("datetime-Select start date"), {
      target: { value: pastDate },
    });

    await waitFor(() => {
      expect(screen.getByText(date_const.pastDateError)).toBeInTheDocument();
    });
  });
});