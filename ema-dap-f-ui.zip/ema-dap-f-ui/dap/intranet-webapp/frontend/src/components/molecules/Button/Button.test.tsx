import { render, screen, fireEvent } from '@testing-library/react';
import Button from './Button';
import { ButtonProps } from './Button';

const defaultProps: ButtonProps = {
  label: 'Click Me',
  onClick: jest.fn(),
};

describe('Button component', () => {
  it('renders with label', () => {
    render(<Button {...defaultProps} />);
    expect(screen.getByText('Click Me')).toBeInTheDocument();
  });

  it('calls onClick when clicked and active', () => {
    render(<Button {...defaultProps} />);
    fireEvent.click(screen.getByRole('button'));
    expect(defaultProps.onClick).toHaveBeenCalled();
  });

  it('does not call onClick when inactive', () => {
    const onClick = jest.fn();
    render(<Button {...defaultProps} isActive={false} onClick={onClick} />);
    fireEvent.click(screen.getByRole('button'));
    expect(onClick).not.toHaveBeenCalled();
  });

  it('applies dark mode classes when isDark is true', () => {
    const { container } = render(<Button {...defaultProps} isDark />);
    const classList = container.querySelector('button')?.className || '';
    expect(classList).toMatch(/text-white|bg-dark/); // adjust based on actual classNames
  });

  it('applies light mode classes when isDark is false', () => {
    const { container } = render(<Button {...defaultProps} isDark={false} />);
    const classList = container.querySelector('button')?.className || '';
    expect(classList).toMatch(/text-black|bg-light/); // adjust based on actual classNames
  });

  it('renders icon when hasIcon is true', () => {
    render(
      <Button
        {...defaultProps}
        hasIcon
        icon={{ name: 'plusWithCircle', size: 16, color: 'black' }}
      />
    );
    expect(document.querySelector('svg')).toBeInTheDocument();
  });

  it('renders icon on the left when iconOnLeft is true', () => {
    const { container } = render(
      <Button
        {...defaultProps}
        hasIcon
        icon={{ name: 'plusWithCircle', size: 16, color: 'black' }}
        iconOnLeft
      />
    );
    const icon = container.querySelector('svg');
    expect(icon?.previousSibling).toBe(null); // Icon appears first
  });

  it('renders icon on the right when iconOnLeft is false', () => {
    const { container } = render(
      <Button
        {...defaultProps}
        hasIcon
        icon={{ name: 'plusWithCircle', size: 16, color: 'black' }}
        iconOnLeft={false}
      />
    );
    const icon = container.querySelector('svg');
    expect(icon?.nextSibling).toBe(null); // Icon appears last
  });

  it('applies custom className and style', () => {
    const style = { backgroundColor: 'red' };
    render(<Button {...defaultProps} className="test-class" style={style} />);
    const button = screen.getByRole('button');
    expect(button).toHaveClass('test-class');
    expect(button).toHaveStyle({ backgroundColor: 'rgb(255, 0, 0)' });
  });

  it('does not render PopOver when tooltip is empty', () => {
    render(<Button {...defaultProps} tooltip="" />);
    const span = screen.getByText('Click Me').closest('span');
    expect(span?.className).not.toContain('popover'); // heuristic check
  });

  it('renders tooltip wrapper when tooltip is present', () => {
    render(<Button {...defaultProps} tooltip="This is a tooltip" />);
    expect(screen.getByText('Click Me')).toBeInTheDocument();
  });
});