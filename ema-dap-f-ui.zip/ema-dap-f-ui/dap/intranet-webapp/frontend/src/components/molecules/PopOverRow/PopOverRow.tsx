import * as React from "react";
import Icons from "../../atoms/Icons/Icons";
import Typography from "../../atoms/typography/Typography";
import { IconName } from "../../atoms/Icons/Icon.type";

const PopOverRow: React.FC<PopOverRowProps> = ({
  content,
  hasRightIcon = false,
  rightIcon,
  rightIconSize = 10,
  hasLeftIcon = false,
  leftIcon,
  leftIconSize = 10,
  rightSideClick,
  leftSideClick,
  onClick,
}) => {
  return (
    <>
      <div
        className="flex justify-between items-center w-full px-3.5 py-2.5 my-1.5 bg-primary-400 rounded-md"
        onClick={onClick}
      >
        <span className="grid gap2 cursor-pointer" onClick={() => rightSideClick && rightSideClick()}>
          {hasRightIcon && (
            <span className="flex items-center">
              <Icons name={rightIcon} size={rightIconSize} />
            </span>
          )}
          <Typography
            variant="notification"
            as="span"
            className="col-span-8 text-white break-all w-full px-1.5"
            title={content}
          >
            {content}
          </Typography>
        </span>
        {hasLeftIcon && (
          <span className="cursor-pointer" onClick={() => leftSideClick && leftSideClick()}>
            <Icons name={leftIcon} size={leftIconSize} />
          </span>
        )}
      </div>
    </>
  );
};

export default PopOverRow;

export interface PopOverRowProps {
  content: string;
  hasRightIcon: boolean;
  rightIcon?: IconName;
  rightIconSize?: number;
  hasLeftIcon: boolean;
  leftIcon?: IconName;
  leftIconSize?: number;
  rightSideClick?: () => void;
  leftSideClick?: () => void;
  onClick?: () => void;
}
