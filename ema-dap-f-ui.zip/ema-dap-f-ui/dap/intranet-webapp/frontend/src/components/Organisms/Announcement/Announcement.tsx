import * as React from "react";
import * as service from "../../../services/announcementsService";
import { announcements } from "../../../types/Announcement";
import { useUserContext } from "../../../context/UserContext";
import { useModalPopup } from "../../../context/ModalPopupContext";
import { useErrorManager } from "../../../utils/manageApiError";
import { api_status, error_const } from "../../../utils/constants";
import { APIerror } from "../../../types/Error";
import Typography from "../../atoms/typography/Typography";
import { Link } from "react-router-dom";
import Icons from "../../atoms/Icons/Icons";
import { routes } from "../../../utils/routes";
import Button from "../../molecules/Button/Button";

const Announcement: React.FC<{}> = () => {
  const [announcements, setAnnouncements] = React.useState<announcements[]>([]);
  const [currentIndex, setCurrentIndex] = React.useState(1);
  const [isHovered, setIsHovered] = React.useState(false);
  const [isTransitioning, setIsTransitioning] = React.useState(true);
  const [transitionEnabled, setTransitionEnabled] = React.useState(true); // NEW

  const intervalRef = React.useRef<NodeJS.Timeout | null>(null);
  const sliderRef = React.useRef<HTMLDivElement | null>(null);

  const { isAdmin } = useUserContext();
  const { showModal } = useModalPopup();
  const errorManager = useErrorManager();

  React.useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  React.useEffect(() => {
    getAnnouncements();
  }, []);

  const getAnnouncements = async () => {
    try {
      const res = await service.getPublishedAnnouncementsList();
      if (res.status === api_status.error) {
        showModal({message:`${error_const.failed}: ${res.message || error_const.apiError}`, title: api_status.error});
        return;
      }
      if (!res.data || res.data.length === 0) {
        setAnnouncements([]);
        return;
      }
      const sort: announcements[] = [...res.data].sort(
        (a, b) => a.order_index - b.order_index
      );
      setAnnouncements(sort);
    } catch (error) {
      errorManager(error as Error | APIerror);
    }
  };

  const startAutoMove = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (announcements.length > 1) {
      intervalRef.current = setInterval(() => {
        setCurrentIndex((prev) =>
          prev >= announcements.length ? 1 : prev + 1
        );
        setIsTransitioning(true);
        setTransitionEnabled(announcements.length!==currentIndex);
      }, 3000);
    }
  };

  const goToSlideByClick = (index: number) => {
    if (index === currentIndex) return;
    const diff = Math.abs(index - currentIndex);
    if (diff > 1) {
      setTransitionEnabled(false);
      setCurrentIndex(index);
      setTimeout(() => {
        setTransitionEnabled(true);
      }, 20); // 20ms is enough for DOM update
    } else {
      setTransitionEnabled(true);
      setCurrentIndex(index);
      setIsTransitioning(true);
    }
  };

  React.useEffect(() => {
    if (announcements.length <= 1 || isHovered) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      return;
    }
    startAutoMove();

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [announcements, isHovered, currentIndex]);

  const handleTransitionEnd = () => {
    setIsTransitioning(false);
  };

  const normalizedIndex = currentIndex;

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (announcements.length <= 1) return;
    if (e.key === "ArrowLeft") {
      goToSlideByClick(normalizedIndex === 1 ? announcements.length : normalizedIndex - 1);
    } else if (e.key === "ArrowRight") {
      goToSlideByClick(normalizedIndex === announcements.length ? 1 : normalizedIndex + 1);
    }
  };

  return (
    <>
      <div className="relative w-full min-h-[128px] shadow-md bg-white text-black rounded-md px-[1rem] py-[0.75rem]">
        {announcements.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <Typography variant="bodyregular" as="span">
              No announcements available
            </Typography>
          </div>
        ) : (
          <div className="flex flex-col gap-3 justify-between h-full">
            <div className="carousel-container w-full overflow-hidden relative">
              <div
                ref={sliderRef}
                className="carousel-slider flex"
                style={{
                  width: `${announcements.length * 100}%`,
                  transform: `translateX(-${(currentIndex - 1) * (100 / announcements.length)}%)`,
                  transition: transitionEnabled && isTransitioning
                    ? "transform 0.4s ease-in-out"
                    : "none",
                }}
                onTransitionEnd={handleTransitionEnd}
                aria-live="polite"
              >
                {announcements.map((item, i) => (
                  <div
                    key={i}
                    className="w-full flex-shrink-0 flex flex-col gap-0.5"
                    style={{ width: `${100 / announcements.length}%` }}
                    onMouseEnter={() => setIsHovered(true)}
                    onMouseLeave={() => setIsHovered(false)}
                    onFocus={() => setIsHovered(true)}
                    onBlur={() => setIsHovered(false)}
                    tabIndex={0}
                    aria-label={`Announcement ${i + 1}`}
                  >
                    <Typography variant="header02" as="span">
                      <span
                        dangerouslySetInnerHTML={{ __html: item.title }}
                      ></span>
                    </Typography>
                    <Typography variant="bodyregular" as="span">
                      <span
                        dangerouslySetInnerHTML={{ __html: item.text }}
                      ></span>
                    </Typography>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex justify-center">
              <div
                className="flex gap-1.5 flex-wrap"
                tabIndex={0}
                onKeyDown={handleKeyDown}
                aria-label="Announcement navigation"
              >
                {announcements.map((x, i) => (
                  <Button
                    key={x.title + i}
                    variant="xsmallcaption"
                    label={(i + 1).toString()}
                    onClick={() => goToSlideByClick(i + 1)}
                    hasBorder={true}
                    hasIcon={false}
                    isDark={false}
                    className={`button px-1.5 ${i + 1 === normalizedIndex ? "selected" : ""}`}
                    aria-label={`Go to announcement ${i + 1}`}
                    tabIndex={-1}
                  />
                ))}
              </div>
            </div>
          </div>
        )}
        {isAdmin && (
          <div className="absolute top-0 right-0 rounded-bl-sm bg-primary-900 p-[0.25rem]">
            <Link to={routes.announcementsManagement} aria-label="Manage announcements">
              <Icons name="pencil" size={16} />
            </Link>
          </div>
        )}
      </div>
    </>
  );
};

export default Announcement;
