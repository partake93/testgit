import "./QuickActions.scss";
import * as React from "react";
import * as service from "../../../services/quickActionsService";
import SectionHeader from "../SectionHeader";
import Typography from "../../atoms/typography/Typography";
import Icons from "../../atoms/Icons/Icons";
import QuickActionItem from "../../molecules/QuickActionItem/QuickActionItem";
import { QuickActionsList } from "../../../types/QuickActions";
import { APIerror } from "../../../types/Error";
import Loading from "../Loading/Loading";
import MyModal from "../../molecules/MyModal/MyModal";
import { modalString } from "../../../utils/modal";
import { isValidUrl } from "../../../utils/functions";
import { useUserContext } from "../../../context/UserContext";
import InputBox from "../../atoms/InputBox/InputBox";
import { useModalPopup } from "../../../context/ModalPopupContext";
import { useErrorManager } from "../../../utils/manageApiError";
import { api_status, error_const } from "../../../utils/constants";

const QuickActions = () => {
  const [quickActionsList, setQuickActionsList] = React.useState<
    QuickActionsList[]
  >([]);
  const [addQAName, setAddQAName] = React.useState("");
  const [addQAurl, setAddQAurl] = React.useState("https://");
  const [isLoading, setLoading] = React.useState(false);
  const [modalShow, setModalShow] = React.useState(false);
  const [deleteModalShow, setDeleteModalShow] = React.useState(false);
  const [showError, setShowError] = React.useState<boolean>(false);
  const [showError1, setShowError1] = React.useState<boolean>(false);
  const [errormodal, setErrorModal] = React.useState<string[]>([]);
  const { user } = useUserContext();

  const deleteId = React.useRef(0);
  const { showModal } = useModalPopup();
  const errorManager = useErrorManager();

  const getQuickActionsList = async () => {
    try {
      setLoading(true);
      const res = await service.getQuickActionsList();
      if (res.status === "success" && res.data) {
        setQuickActionsList(res.data);
      } else {
        errorManager(
          new Error(
            `Failed to fetch quick actions: ${res.message || error_const.apiError}`
          )
        );
      }
    } catch (error) {
      errorManager(error as Error | APIerror);
    }
    setLoading(false);
  };

  React.useEffect(() => {
    getQuickActionsList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const deleteQuickAction = async () => {
    setDeleteModalShow(false);
    try {
      const res = await service.deleteQuickAction(deleteId.current);
      if (res.status !== "success") {
        errorManager(
          new Error(
            `Failed to delete quick action: ${res.message || error_const.apiError}`
          )
        );
        return;
      }
      getQuickActionsList();
      if (res.status === "success") {
        showModal({ message: res.message, title: api_status.success });
      }
      deleteId.current = 0;
    } catch (error) {
      errorManager(error as Error | APIerror);
    }
  };

  const deleteFunction = (id?: number) => {
    if (id) {
      deleteId.current = id;
      setDeleteModalShow(true);
    }
  };

  const addQuickAction = async () => {
    let errorName = false;
    let errorUrl = false;
    if (addQAName.trim() === "") {
      setErrorModal((prev) => [
        ...prev,
        "Please fill the name."
      ]);
      errorName = true;
    } else if (addQAName.trim().length < 3) {
      setErrorModal((prev) => [
        ...prev,
        "Name must be at least 3 characters long.",
      ]);
      errorName = true;
    }
    if (!addQAurl.trim() || !isValidUrl(addQAurl)) {
      setErrorModal((prev) => [
        ...prev,
        "Please enter a valid link."
      ]);
      errorUrl = true;
    }
    setShowError(errorName);
    setShowError1(errorUrl);

    if (errorName || errorUrl) {
      return;
    }
    try {
      setModalShow(false);
      const res = await service.addQuickAction({
        label: addQAName,
        url: addQAurl,
      });
      if (res.status !== "success") {
        errorManager(
          new Error(
            `Failed to add quick action: ${res.message || error_const.apiError}`
          )
        );
        return;
      }
      if (res.status === "success") {
        showModal({ message: res.message, title: api_status.success });
      }
      getQuickActionsList();
      setAddQAName("");
      setAddQAurl("https://");
    } catch (error) {
      errorManager(error as Error | APIerror);
    }
  };

  return (
    <>
      <div className="quickActionsBox shadow-md modal-wrapper w-full rounded-md max-w-full">
        <SectionHeader
          title="Quick Actions"
          hasButton={true}
          hasNavigation={false}
          button={
            user.is_dap_user
              ? {
                  label: "+",
                  variant: "header04",
                  onClick: () => setModalShow(true),
                  isActive: true,
                  isDark: true,
                  hasBorder: true,
                  hasIcon: false,
                  iconOnLeft: true,
                  className: "button px-[0.75rem] py-0.5",
                }
              : undefined
          }
        />
        {isLoading ? (
          <Loading isFullPage={false} className="h-90!" />
        ) : (
          <>
            <div className="max-h-[60vh] overflow-y-auto sm:max-h-[24rem]">
              {quickActionsList.length > 0 ? (
                <div className="py-[1.25rem] w-full">
                  {quickActionsList.map((x) => {
                    return (
                      <div
                        key={x.id}
                        className="flex items-center justify-between gap-2 py-1"
                      >
                        <QuickActionItem
                          icon={x.icon_name || "hyperlink"}
                          content={x.label}
                          onClick={() => window.open(x.url, "_blank")}
                        />
                        <span
                          data-testid="quick-action-delete"
                          className="p-[0.5rem] flex justify-center items-center cursor-pointer"
                          onClick={() => deleteFunction(x.id)}
                        >
                          <Icons name="trash" size={15} />
                        </span>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="h-full flex flex-wrap content-center justify-center">
                  <Typography variant="captionregular" className="opacity-50">
                    There are no quick actions available
                  </Typography>
                </div>
              )}
            </div>
          </>
        )}
        <MyModal
          title={modalString.quickActionAdd}
          actionButtonLabel="Add"
          action={addQuickAction}
          show={modalShow}
          onClose={() => setModalShow(false)}
          isItFullScreen={false}
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 py-2">
            <Typography
              variant="smallcaption"
              as="span"
              className="sm:w-1/5 text-center sm:text-left"
            >
              Name:
            </Typography>
            <span className="w-full sm:w-4/5">
              <InputBox
                varient="smallcaption"
                name="AddNameInputBox"
                value={addQAName}
                error={showError}
                onChange={(e) => setAddQAName(e.target.value)}
                className="bg-white text-black rounded-lg w-full px-2 py-1"
              />
            </span>
          </div>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 py-2">
            <Typography
              variant="smallcaption"
              as="span"
              className="sm:w-1/5 text-center sm:text-left"
            >
              Link:
            </Typography>
            <span className="w-full sm:w-4/5">
              <InputBox
                varient="smallcaption"
                name="AddUrlInputBox"
                value={addQAurl}
                error={showError1}
                onChange={(e) => setAddQAurl(e.target.value)}
                className="bg-white text-black rounded-lg w-full px-2 py-1"
              />
            </span>
          </div>
        </MyModal>
        <MyModal
          show={deleteModalShow}
          onClose={() => setDeleteModalShow(false)}
          title={modalString.quickActionDeleteTitle}
          actionButtonLabel="Delete"
          action={deleteQuickAction}
          isItFullScreen={false}
        >
          <span>{modalString.actionBody}</span>
        </MyModal>
        <MyModal
          show={errormodal.length > 0}
          onClose={() => setErrorModal([])}
          title="Please fix the Issues"
          isItFullScreen={false}
        >
          <ul>
            {errormodal.map((error, index) => (
              <Typography
                key={index}
                variant="bodyregular"
                as="li"
                className="list-disc"
              >
                {error}
              </Typography>
            ))}
          </ul>
        </MyModal>
      </div>
    </>
  );
};

export default QuickActions;
