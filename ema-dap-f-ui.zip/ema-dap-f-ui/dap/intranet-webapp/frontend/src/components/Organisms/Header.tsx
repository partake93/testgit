import * as React from "react";
import * as notificationService from "../../services/notificationsService";
import ema from "../../assets/svg/EMA.svg";
import { Link, useNavigate } from "react-router-dom";
import Icons from "../atoms/Icons/Icons";
import PopOver from "./PopOver";
import { PopOverRowProps } from "../molecules/PopOverRow/PopOverRow";
import { IconName } from "../atoms/Icons/Icon.type";
import { logoutUser } from "../../services/authService";
import { NotificationHeader } from "../../types/Notification";
import { useErrorManager } from "../../utils/manageApiError";
import { APIerror } from "../../types/Error";
import Typography from "../atoms/typography/Typography";
import { routes } from "../../utils/routes";
import { api_status, error_const, notification_const } from "../../utils/constants";

const Header = () => {
  const [notifications, setNotifications] = React.useState<NotificationHeader[]>([]);
  const timerRef = React.useRef<NodeJS.Timeout | null>(null);
  const errorManager = useErrorManager();
  const navigate = useNavigate();

  const supportData: popOverStr[] = [
    { icon: "folderBox", content: "Guides" },
    { icon: "faq", content: "FAQ" },
  ];

  const profileData: popOverStr[] = [
    {
      icon: "powerBtn",
      content: "Log Out",
      onClick: () => {
        logoutUser();
        window.location.href = routes.login;
      },
    },
  ];

  const fetchNotifications = React.useCallback(async () => {
    try {
      const res = await notificationService.getNotificationsHeader();
      if (res.status === api_status.error) {
        errorManager(
          new Error(
            `${notification_const.failed}: ${res.message || error_const.apiError}`
          )
        );
        return;
      }
      if (!res.data || res.data.notifications.length === 0) {
        setNotifications([]);
        return;
      }
      setNotifications(res.data.notifications);
    } catch (error) {
      errorManager(error as Error | APIerror);
      window.location.href = routes.login;
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  React.useEffect(() => {
    fetchNotifications(); // Initial fetch
    // Set up polling to fetch notifications every 5 minutes
    timerRef.current = setInterval(fetchNotifications, 5 * 60 * 1000); // Fetch every 5 minutes
    return () => {
      
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [fetchNotifications]);

  const removeNotificationByIndex = (index: number) => {
    setNotifications((prev) =>
      prev.splice(index, 1) && [...prev]
    );
  };

  return (
    <>
      <div className="flex justify-between py-[0.5rem] top-0 z-50 w-full">
        <div className="start-element">
          <Link to={"/"}>
            <img src={ema} alt="EMA" />
          </Link>
        </div>
        <div className="end-element grid grid-cols-3 items-center">
          <div className="px-[0.25rem]">
            <PopOver
              trigger="click"
              isTooltip={false}
              popOverContent={{
                header: {
                  title: "NOTIFICATIONS",
                  variant: "header03",
                  hasButton: true,
                  button: {
                    label: "View all",
                    variant: "hyperlink",
                    hasBorder: false,
                    hasIcon: true,
                    iconOnLeft: false,
                    icon: {
                      name: "arrowRight",
                      size: 10,
                      color: "#2567B6",
                    },
                    isActive: true,
                    className: "flex text-primary-400 items-center",
                    onClick: () => {
                      navigate(routes.notifications);
                    },
                  },
                },
                rowList: notifications.map((x, i) => {
                  const row: PopOverRowProps = {
                    content: x.details==null ? x.error_code+"-"+x.source_file_name : x.details,
                    hasRightIcon: true,
                    // hasLeftIcon: true,
                    hasLeftIcon: false,
                    leftIcon: "xmark",
                    // rightIcon: "redDangerAlert",
                    rightIconSize: 20,
                    leftSideClick: () => removeNotificationByIndex(i),
                    // rightSideClick: () => window.open(x.url, "_blank"),
                  };
                  return row;
                }),
              }}
            >
              <span className="relative cursor-pointer">
                <Icons name="bell" size={16} />
                {notifications.length > 0 && (
                  <Typography variant="xsmallcaption" as="span" className="absolute -top-1 -right-[0.2rem] px-1 bg-secondary-01 text-white flex items-center justify-center rounded-xs" >{notifications.length}</Typography>
                )}
              </span>
            </PopOver>
          </div>

          <div className="px-[0.25rem]">
            <PopOver
              trigger="click"
              isTooltip={false}
              popOverContent={{
                header: {
                  title: "SUPPORT",
                  variant: "header03",
                  hasButton: false,
                },
                rowList: supportData.map((x) => {
                  const row: PopOverRowProps = {
                    content: x.content,
                    hasRightIcon: true,
                    hasLeftIcon: true,
                    rightIcon: x.icon,
                    leftIcon: "arrowRight",
                    rightIconSize: 20,
                    leftIconSize: 15,
                  };
                  return row;
                }),
              }}
            >
              <span className="cursor-pointer">
                <Icons name="support" size={16} />
              </span>
            </PopOver>
          </div>

          <div className="px-[0.25rem]">
            <PopOver
              trigger="click"
              isTooltip={false}
              popOverContent={{
                header: {
                  title: "PROFILE",
                  variant: "header03",
                  hasButton: false,
                },
                rowList: profileData.map((x) => {
                  const row: PopOverRowProps = {
                    content: x.content,
                    hasRightIcon: true,
                    hasLeftIcon: false,
                    rightIcon: x.icon,
                    rightIconSize: 20,
                    onClick: x.onClick,
                  };
                  return row;
                }),
              }}
            >
              <span className="cursor-pointer">
                <Icons name="user" size={16} />
              </span>
            </PopOver>
          </div>
        </div>
      </div>
    </>
  );
};

export default Header;

interface popOverStr {
  icon: IconName;
  content: string;
  onClick?: () => void;
}
