import * as React from "react";
import Typography, { typographyvar } from "../atoms/typography/Typography";
import { useNavigate } from "react-router-dom";
import Icons from "../atoms/Icons/Icons";
import Button, { ButtonProps } from "../molecules/Button/Button";

const SectionHeader: React.FC<SectionHeaderProps> = ({
  title,
  variant = "header05",
  hasNavigation = false,
  navigateTo = "",
  hasButton = false,
  button = undefined,
  className
}) => {
  const navigate = useNavigate();

  const handleClick = () => {
    if (navigateTo == "") {
    navigate(-1); // Go back to the previous page
    } else {
      navigate(navigateTo);
    }
  };

  return (
    <div className={`flex flex-wrap justify-between items-center ${className}`}>
      <div className="start-element flex items-center">
        {hasNavigation && (
          <span onClick={handleClick} className="cursor-pointer">
            <Icons name="leftArrow" size={16} />
          </span>
        )}
        <Typography variant={variant} as="span">
          {title}
        </Typography>
      </div>
      <div className="end-element">
        {hasButton && button && (
          <Button
            variant={button.variant}
            label={button.label}
            isActive={button.isActive}
            isDark={button.isDark}
            className={button.className}
            hasBorder={button.hasBorder}
            hasIcon={button.hasIcon}
            icon={button.icon}
            iconOnLeft={button.iconOnLeft}
            onClick={button.onClick}
          />
        )}
      </div>
    </div>
  );
};

export default SectionHeader;

export interface SectionHeaderProps {
  title: string;
  variant?: typographyvar
  hasNavigation?: boolean;
  navigateTo?: string;
  hasButton?: boolean;
  className?: string;
  button?: ButtonProps;
}