import * as React from "react";
import { OverlayTrigger, Popover } from "react-bootstrap";
import SectionHeader, { SectionHeaderProps } from "./SectionHeader";
import PopOverRow, { PopOverRowProps } from "../molecules/PopOverRow/PopOverRow";

const PopOver: React.FC<PopoverProps> = ({
  trigger,
  isTooltip = true,
  children,
  description = "",
  popOverContent,
  ...props
}) => {
  let overlay = Tooltip(description);

  if (!isTooltip) {
    if (popOverContent) {
      const content = PopOverGrid({ ...popOverContent });
      if (React.isValidElement(content)) {
        overlay = content;
      }
    }
  }

  return (
    <OverlayTrigger
      trigger={[trigger, "focus"]}
      placement="auto"
      overlay={overlay}
      flip={true}
      rootClose={true}
      {...props}
    >
      <span>{children}</span>
    </OverlayTrigger>
  );
};

export default PopOver;

const Tooltip = (description: string) => {
  return (
    <Popover>
      <Popover.Body className="p-2.5!">
        <span dangerouslySetInnerHTML={{ __html: description }}></span>
      </Popover.Body>
    </Popover>
  );
};

const PopOverGrid: React.FC<PopOverGridProps> = ({ header, rowList }) => {
  return (
    <Popover className="bg-primary-100 min-w-[20rem]!">
      <Popover.Body className="p-2.5!">
        <SectionHeader {...header} />
        <div className="my-2.5">
          {rowList.map((x, i) => (
            <PopOverRow key={i} onClick={x.onClick} {...x} />
          ))}
        </div>
      </Popover.Body>
    </Popover>
  );
};

export interface PopOverGridProps {
  header: SectionHeaderProps;
  rowList: PopOverRowProps[];
};

export interface PopoverProps  {
  trigger: "click" | "hover";
  isTooltip?: boolean;
  children?: React.ReactNode;
  description?: string;
  popOverContent?: PopOverGridProps;
  [key: string]: any;
};