import { render, screen, fireEvent, waitFor, act } from "@testing-library/react";
import QuickActions from "./QuickActions";
import { BrowserRouter } from "react-router-dom";
import * as service from "../../../services/quickActionsService";

// Mock dependencies
jest.mock("../../../utils/getEnv", () => ({
  getEnv: (key: string) => (key === "VITE_BACKEND_URL" ? "https://mock-api.com" : ""),
}));
jest.mock("../../../context/UserContext", () => ({
  useUserContext: () => ({
    user: { is_dap_user: true },
  }),
}));
jest.mock("../../../context/ModalPopupContext", () => ({
  useModalPopup: () => ({
    showModal: jest.fn(),
  }),
}));
jest.mock("../../../utils/manageApiError", () => ({
  useErrorManager: () => jest.fn(),
}));
jest.mock("../../../services/quickActionsService");

const renderWithRouter = (ui: React.ReactElement) => {
  return render(<BrowserRouter>{ui}</BrowserRouter>);
};

describe("QuickActions Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("renders loading initially", async () => {
    (service.getQuickActionsList as jest.Mock).mockReturnValue(new Promise(() => {}));
    const { container } = renderWithRouter(<QuickActions />);
    // Look for the spinner by class
    expect(container.querySelector('.spinner')).toBeInTheDocument();
  });

  it("renders quick actions list", async () => {
    const mockList = [
      { id: 1, label: "Google", url: "https://google.com", icon_name: "hyperlink" },
      { id: 2, label: "Facebook", url: "https://facebook.com", icon_name: "hyperlink" },
    ];
    (service.getQuickActionsList as jest.Mock).mockResolvedValue({ status: "success", data: mockList });

    await act(async () => {
      renderWithRouter(<QuickActions />);
    });
    await waitFor(() => expect(screen.getByText("Google")).toBeInTheDocument());
    expect(screen.getByText("Facebook")).toBeInTheDocument();
  });

  it("shows empty state when no quick actions", async () => {
    (service.getQuickActionsList as jest.Mock).mockResolvedValue({ status: "success", data: [] });
    await act(async () => {
      renderWithRouter(<QuickActions />);
    });
    await waitFor(() => expect(screen.getByText(/there are no quick actions/i)).toBeInTheDocument());
  });

  it("opens and closes add quick action modal", async () => {
    (service.getQuickActionsList as jest.Mock).mockResolvedValue({ status: "success", data: [] });

    await act(async () => {
      renderWithRouter(<QuickActions />);
    });
    const addButton = screen.getByText("+");
    await act(async () => {
      fireEvent.click(addButton);
    });

    expect(screen.getByText(/name:/i)).toBeInTheDocument();

    const closeButton = screen.getByRole("button", { name: /cancel/i });
    await act(async () => {
      fireEvent.click(closeButton);
    });

    await waitFor(() => expect(screen.queryByText(/name:/i)).not.toBeInTheDocument());
  });

  it("shows validation errors when adding a quick action with invalid inputs", async () => {
    (service.getQuickActionsList as jest.Mock).mockResolvedValue({ status: "success", data: [] });
    await act(async () => {
      renderWithRouter(<QuickActions />);
    });
    await act(async () => {
      fireEvent.click(screen.getByText("+"));
    });

    const addActionButton = screen.getByRole("button", { name: /^Add$/i });
    await act(async () => {
      fireEvent.click(addActionButton);
    });

    await waitFor(() => {
      expect(screen.getByText("Please fill the name.")).toBeInTheDocument();
      expect(screen.getByText("Please enter a valid link.")).toBeInTheDocument();
    });
  });

  it("calls addQuickAction service on valid input", async () => {
    (service.getQuickActionsList as jest.Mock).mockResolvedValue({ status: "success", data: [] });
    (service.addQuickAction as jest.Mock).mockResolvedValue({ status: "success", message: "Added successfully" });

    await act(async () => {
      renderWithRouter(<QuickActions />);
    });
    await act(async () => {
      fireEvent.click(screen.getByText("+"));
    });

    await act(async () => {
      fireEvent.change(screen.getByRole("textbox", { name: /AddNameInputBox/i }), {
        target: { value: "New Action" },
      });
      fireEvent.change(screen.getByRole("textbox", { name: /AddUrlInputBox/i }), {
        target: { value: "https://example.com" },
      });
    });

    await act(async () => {
      fireEvent.click(screen.getByRole("button", { name: /^Add$/i }));
    });

    await waitFor(() => {
      expect(service.addQuickAction).toHaveBeenCalledWith({
        label: "New Action",
        url: "https://example.com",
      });
    });
  });

  it("deletes a quick action", async () => {
    const mockList = [
      { id: 1, label: "Google", url: "https://google.com", icon_name: "hyperlink" },
    ];
    (service.getQuickActionsList as jest.Mock).mockResolvedValueOnce({ status: "success", data: mockList });
    (service.deleteQuickAction as jest.Mock).mockResolvedValue({ status: "success", message: "Deleted successfully" });

    await act(async () => {
      renderWithRouter(<QuickActions />);
    });
    await waitFor(() => expect(screen.getByText("Google")).toBeInTheDocument());

    // Find the trash icon button by test id
    const trashButton = screen.getAllByTestId("quick-action-delete")[0];
    await act(async () => {
      fireEvent.click(trashButton);
    });

    // Confirm modal should appear (simulate clicking delete)
    const deleteButton = screen.getByRole("button", { name: /^Delete$/i });
    await act(async () => {
      fireEvent.click(deleteButton);
    });

    await waitFor(() => {
      expect(service.deleteQuickAction).toHaveBeenCalledWith(1);
    });
  });
});