import * as React from "react";
import { pagination } from "../../types/Pagination";
import Button from "../molecules/Button/Button";

const Pagination: React.FC<paginationProps> = ({
  page = { current_page: 1, total_pages: 1 },
  handlePageChange,
  isDark = true,
}) => {
  const buttons: any = [];
  const leftArrow =()=>{
    if(page.current_page!=1){
        handlePageChange?.(page.current_page - 1);
    }
  };
const rightArrow =()=>{
    if(page.current_page!=page.total_pages){
        handlePageChange?.(page.current_page + 1);
    }
  };
  const getPageNumbers = () => {
    buttons.push(
      <Button
        key={"left"}
        variant="xsmallcaption"
        hasBorder={false}
        hasIcon={true}
        onClick={() => leftArrow()}
        icon={{
          name: "leftArrow",
          color: page.current_page != 1 ? "#fff" : "#ffffff50",
          size: 10,
        }}
      />
    );

    const delta = 1;

    const left = Math.max(2, page.current_page - delta);
    const right = Math.min(page.total_pages - 1, page.current_page + delta);

    buttons.push(
      <Button
        key={"page1"}
        variant="xsmallcaption"
        label="1"
        onClick={() => handlePageChange?.(1)}
        hasBorder={true}
        hasIcon={false}
        isActive={true}
        isDark={isDark}
        className={`button px-1.5 ${1 == page.current_page && "selected"}`}
      />
    );

    if (left > 2) {
      buttons.push(
        <Button
          key={"elipse1"}
          variant="xsmallcaption"
          label="..."
          hasBorder={true}
          hasIcon={false}
          isActive={true}
          isDark={isDark}
          className={`button px-1.5`}
        />
      );
    }

    for (let index = left; index <= right; index++) {
      buttons.push(
        <Button
          key={index}
          variant="xsmallcaption"
          label={index + ""}
          onClick={() => handlePageChange?.(index)}
          hasBorder={true}
          hasIcon={false}
          isActive={true}
          isDark={isDark}
          className={`button px-1.5 ${
            index == page.current_page && "selected"
          }`}
        />
      );
    }

    if (right < page.total_pages - 1) {
      buttons.push(
        <Button
          key={"elipse2"}
          variant="xsmallcaption"
          label="..."
          hasBorder={true}
          hasIcon={false}
          isActive={true}
          isDark={isDark}
          className={`button px-1.5`}
        />
      );
    }

    if (page.total_pages > 1) {
      buttons.push(
        <Button
          key={"lastPagw"}
          variant="xsmallcaption"
          label={page.total_pages + ""}
          onClick={() => handlePageChange?.(page.total_pages)}
          hasBorder={true}
          hasIcon={false}
          isActive={true}
          isDark={isDark}
          className={`button px-1.5 ${
            page.total_pages == page.current_page && "selected"
          }`}
        />
      );
    }
    buttons.push(
      <Button
        key={"right"}
        variant="xsmallcaption"
        hasBorder={false}
        hasIcon={true}
        onClick={() => rightArrow()}
        icon={{
          name: "arrowRight",
          color: page.current_page != page.total_pages ? "#fff" : "#ffffff50",
          size: 10,
        }}
      />
    );
  };
  getPageNumbers();
  if (page.total_pages <= 1) {
    return null;
  }
  return (
    <div className="flex justify-center p-2.5">
      <span className="flex items-center gap-1">{buttons}</span>
    </div>
  );
};

export default Pagination;

export interface paginationProps {
  page: pagination;
  isDark?: boolean;
  handlePageChange?: (pageNumber: number) => void;
}
