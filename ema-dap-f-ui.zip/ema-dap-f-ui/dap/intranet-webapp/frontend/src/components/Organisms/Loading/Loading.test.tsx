import { render } from "@testing-library/react";
import Loading from "./Loading";

// Mock the styles if using CSS Modules
jest.mock("./Loading.module.scss", () => ({
  container: "container",
  container_content: "container_content",
  spinner: "spinner",
}));

describe("Loading component", () => {
  test("renders full-page loading by default", () => {
    const { container } = render(<Loading />);
    expect(container.firstChild).toHaveClass("container");
    expect(container.querySelector(".spinner")).toBeInTheDocument();
  });

  test("renders content-only loading when isFullPage is false", () => {
    const { container } = render(<Loading isFullPage={false} />);
    expect(container.firstChild).toHaveClass("container_content");
  });

  test("applies custom className when provided", () => {
    const { container } = render(<Loading className="custom-class" />);
    expect(container.firstChild).toHaveClass("container");
    expect(container.firstChild).toHaveClass("custom-class");
  });

  test("renders overlay variant when varient is true", () => {
    const { container } = render(<Loading varient />);
    const overlay = container.firstChild as HTMLElement;
    expect(overlay).toHaveClass("fixed");
    expect(overlay).toHaveClass("inset-0");
    expect(overlay.querySelector(".spinner")).toBeInTheDocument();
  });
});