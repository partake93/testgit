import * as React from "react";
import styles from "./Loading.module.scss";

const Loading: React.FC<{
  isFullPage?: boolean;
  className?: string;
  varient?: boolean;
}> = ({ isFullPage = true, className, varient = false }) => {
  return (
    <>
    {varient ? (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
        <div className={styles.spinner} />
      </div>
    ): (
    <div className={
          (isFullPage ? styles.container : styles.container_content) +
          ` ${className}`
        }
      >
        <div className={styles.spinner} />
      </div>)}
    </>
  );
};

export default Loading;
