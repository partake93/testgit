import * as React from "react";
import { FaFacebook, FaLinkedinIn, FaInstagram, FaYoutube, FaXTwitter, FaUpRightFromSquare } from "react-icons/fa6";

const Footer: React.FC<{}> = () => {
    return (
      <>
        <div id="footer" className="px-20 py-10">
          <div className="text-[1.5rem] font-bold text-white mb-5">
            Energy Market Authority of Singapore
          </div>
          <div className="flex justify-between pb-4 border-b-1 border-b-white border-dashed" >
            <div className="start-element inline-flex whitespace-nowrap gap-5">
              <span className="text-[#BAC8E1]">About EMA</span>
              <span className="text-[#BAC8E1]">Contact Us</span>
              <span className="text-[#BAC8E1]">FAQs</span>
              <span className="text-[#BAC8E1]">Site Map</span>
            </div>
            <div className="end-element inline-flex whitespace-nowrap gap-2">
              <FaFacebook className="text-white text-[1.5rem] cursor-pointer" />
              <span className="size-[1.5rem] bg-white text-[#042546] place-items-center content-center rounded-full cursor-pointer"><FaLinkedinIn className="text-[0.9rem]" /></span>
              <span className="size-[1.5rem] bg-white text-[#042546] place-items-center content-center rounded-full cursor-pointer"><FaInstagram className="text-[0.9rem]" /></span>
              <span className="size-[1.5rem] bg-white text-[#042546] place-items-center content-center rounded-full cursor-pointer"><FaYoutube className="text-[0.9rem]" /></span>
              <span className="size-[1.5rem] bg-white text-[#042546] place-items-center content-center rounded-full cursor-pointer"><FaXTwitter className="text-[0.9rem]" /></span>
              {/* <FaLinkedinIn className="bg-white size-[1.5rem] p-1 rounded-full cursor-pointer" /> */}
            </div>
          </div>
          <div className="flex justify-between mt-4" >
            <div className="start-element inline-flex whitespace-nowrap gap-5">
              <span className="text-[#BAC8E1] cursor-pointer flex">Report Vulnerability <FaUpRightFromSquare className="font-bold ms-0.5" /></span>
              <span className="text-[#BAC8E1] cursor-pointer">Whistleblowing</span>
              <span className="text-[#BAC8E1] cursor-pointer">Privacy Statement</span>
              <span className="text-[#BAC8E1] cursor-pointer">Terms of use</span>
              <span className="text-[#BAC8E1] cursor-pointer flex">REACH <FaUpRightFromSquare className="font-bold ms-0.5" /></span>
            </div>
            <div className="end-element grid grid-rows-2">
              <span className="text-white text-xs">© 2025 Gov...... of Singapore</span>
              <span className="text-white text-xs text-end">Last Updated 11 Mar 2025</span>
            </div>
          </div>
        </div>
      </>
    );
  };

  export default Footer;