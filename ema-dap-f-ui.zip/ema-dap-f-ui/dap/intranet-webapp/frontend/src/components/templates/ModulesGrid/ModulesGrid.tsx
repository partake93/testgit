import * as React from "react";
import * as service from "../../../services/modulesService";
import { useNavigate } from "react-router-dom";
import { routes } from "../../../utils/routes";
import SectionHeader from "../../Organisms/SectionHeader";
import ModuleTile from "../../molecules/ModuleTile/ModuleTile";
import { modules, Tag } from "../../../types/Modules";
import { APIerror } from "../../../types/Error";
import { isIconName } from "../../atoms/Icons/Icon";
import Loading from "../../Organisms/Loading/Loading";
import { useErrorManager } from "../../../utils/manageApiError";
import { useUserContext } from "../../../context/UserContext";
import { defaultModules, defaultModulesNames } from "../../../utils/modules";
import MyModal from "../../molecules/MyModal/MyModal";
import Typography from "../../atoms/typography/Typography";
import { useModalPopup } from "../../../context/ModalPopupContext";
import { api_status, common_labels, error_const, modules_const } from "../../../utils/constants";
import Button from "../../molecules/Button/Button";

const ModulesGrid = () => {
  const [selectedFilter, setSelectedFilter] = React.useState("");
  const [moduleList, setModuleList] = React.useState<modules[]>([]);
  const [allModuleList, setAllModuleList] = React.useState<modules[]>([]);
  const [tagList, setTagList] = React.useState<Tag[]>([
    { id: 0, label: common_labels.all },
  ]);
  const [isLoading, setLoading] = React.useState(false);
  const [modalModule, setModalModule] = React.useState<modules | null>(null);
  const [modalShow, setModalShow] = React.useState(false);

  const { user, isAdmin } = useUserContext();

  const errorManager = useErrorManager();
  const navigate = useNavigate();
  const { showModal } = useModalPopup();

  React.useEffect(() => {
    getTags();
    getModules();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getTags = async () => {
    try {
      const res = await service.getTagList();
      if (res.status === api_status.error) {
        showModal({message: `${error_const.failed}: ${res.message || error_const.apiError}`, title: api_status.error});
        return;
      }
      if (!res.data || res.data.length === 0) {
        // showModal({message: modules_const.tagsNotFound,title: "info"});
        return;
      }
      const allTags = [{ id: 0, label: common_labels.all}, ...res.data];
      setTagList(allTags);
      setSelectedFilter(common_labels.all);
    } catch (error) {
      errorManager(error as Error | APIerror);
    }
  };

  const getModules = async () => {
    try {
      setLoading(true);
      const res = await service.getModulesList();
      if (res.status === api_status.error) {
        showModal({message: `${error_const.failed}: ${res.message || error_const.apiError}`, title: api_status.error});
        return;
      }
      if (!res.data || res.data.length === 0) {
        // showModal({message: modules_const.moduleNotFound,title: status_const.info});
        setModuleList([]);
        setAllModuleList([]);
        return;
      }
      const modules = res.data.sort((a, b) => a.order_index - b.order_index);
      setModuleList(modules);
      setAllModuleList(modules);
    } catch (error) {
      errorManager(error as Error | APIerror);
    } finally {
      setLoading(false);
    }
  };

  const filterSelect = React.useCallback(
    (value: string) => {
      setSelectedFilter(value);
      if (value === common_labels.all) {
        setModuleList([...allModuleList]);
        return;
      }
      const filtered = allModuleList.filter((x) =>
        x.tags.some((tag) => tag.label.toLowerCase() === value.toLowerCase())
      );
      setModuleList(filtered);
    },
    [allModuleList]
  );

  return (
    <div>
      <SectionHeader
        title={modules_const.modules}
        hasButton={true}
        hasNavigation={false}
        className="text-white"
        button={
          user.is_dap_user
            ? {
                label: isAdmin ? modules_const.manageModules : modules_const.accessRequest,
                onClick: () =>
                  navigate(
                    isAdmin ? routes.modulesManagement : routes.moduleRequest
                  ),
                variant: "header04",
                isActive: true,
                isDark: true,
                hasBorder: true,
                hasIcon: true,
                icon: { name: "gear", size: 10 },
                iconOnLeft: true,
                className: "button px-[1rem] py-0.5",
              }
            : undefined
        }
      />
      {isLoading ? (
        <Loading isFullPage={false} className="h-90!" />
      ) : (
        <div className="flex flex-col gap-2 mb-4">
          <div className="pb-2 flex gap-2 flex-wrap sm:flex-nowrap overflow-x-auto text-white">
            {tagList.map((x: Tag) => (
              <Button
                key={x.id}
                variant="captionregular"
                onClick={() => filterSelect(x.label)}
                label={x.label}
                hasBorder={true}
                hasIcon={false}
                isActive={true}
                isDark={true}
                className={`button px-1.5 py-0.5 ${
                  selectedFilter === x.label && "selected"
                }`}
              />
            ))}
          </div>

          <div className="overflow-y-auto max-h-[50vh] sm:max-h-[60vh] md:max-h-[70vh]">
            {moduleList.length === 0 && (
              <div className="text-white p-4">
                {modules_const.moduleNotFound} for selected category.
              </div>
            )}
            {moduleList && (
              <div className="grid grid-cols-[repeat(auto-fit,_minmax(167px,_1fr))] gap-3">
                {moduleList.map((x: modules) => {
                  const isActive: boolean = x.has_access;
                  let url = x.url;
                  let target = "_blank";
                  if (defaultModulesNames.includes(x.label.toLowerCase())) {
                    const foundUrl = defaultModules.find(
                      (module) =>
                        module.label.toLowerCase() === x.label.toLowerCase()
                    )?.url;
                    if (foundUrl) {
                      url = foundUrl;
                      target = foundUrl.startsWith("http") ? "_blank" : "_self";
                    }
                  }
                  let func = () => {
                    if (isActive) {
                      window.open(url, target);
                    }
                  };
                  if (x.confirmation_step) {
                    func = () => {
                      setModalModule(x);
                      setModalShow(true);
                    };
                  }
                  return (
                    <ModuleTile
                      key={x.id}
                      IconName={
                        isIconName(x.icon_name) ? x.icon_name : "package"
                      }
                      title={x.label}
                      tooltip={x.tooltip_text}
                      url={x.url}
                      pending={x.pending}
                      isActive={isActive}
                      {...(isAdmin && { showEye: !x.default_visible })}
                      moduleId={x.id}
                      onclick={func}
                    />
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
      {modalModule && (
        <MyModal
          title={modalModule.label}
          actionButtonLabel={common_labels.view}
          action={() => {
            setModalShow(false);
            window.open(modalModule.url, "_blank");
          }}
          show={modalShow}
          onClose={() => setModalShow(false)}
          isItFullScreen={true}
        >
          <Typography variant="bodyregular" className="text-white">
            <p>{modalModule.confirmation_text}</p>
            <Typography variant="smallcaption" className="text-white">
              <p className="mt-2">
                This module requires confirmation before proceeding. Click
                "View" to continue.
              </p>
            </Typography>
          </Typography>
        </MyModal>
      )}
    </div>
  );
};

export default ModulesGrid;
