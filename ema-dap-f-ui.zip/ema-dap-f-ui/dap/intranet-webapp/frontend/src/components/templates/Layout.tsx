import { Outlet, useNavigate } from "react-router-dom";
import Header from "../Organisms/Header";
import { useEffect, useState } from "react";
import { checkValidUser } from "../../services/authService";
import Loading from "../Organisms/Loading/Loading";
import { useUserContext } from "../../context/UserContext";
import { routes } from "../../utils/routes";

const Layout = () => {
  const navigate = useNavigate();
  const [isValidUser, setIsValidUser] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const { setUser, setIsAdmin } = useUserContext();

  useEffect(() => {
    const checkUser = async () => {
      try {
        setIsLoading(true);
        const res = await checkValidUser();
        if (res.status === "success") {
          setIsValidUser(true);
          if (res.data) {
            setUser(res.data);
            setIsAdmin(res.data.is_admin);
          }
        } else {
          navigate(routes.login, { replace: true });
        }
      } catch {
        navigate(routes.login, { replace: true });
      } 
      setIsLoading(false);
    };
    checkUser();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [navigate]);

  if (isLoading) return <Loading />;
  if (!isValidUser) return null;
  return (
    <div className="md:px-10 lg:px-20 px-5.5" style={{ maxWidth: 1397, margin: "0 auto" }}>
      <Header />
      <main>
        <Outlet />
      </main>
      {/* <Footer /> */}
    </div>
  );
};

export default Layout;
