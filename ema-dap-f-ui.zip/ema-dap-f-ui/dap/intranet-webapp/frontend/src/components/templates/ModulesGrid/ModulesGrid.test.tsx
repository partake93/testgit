import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import ModulesGrid from "./ModulesGrid";
import * as service from "../../../services/modulesService";
import { useModalPopup } from "../../../context/ModalPopupContext";
import { useUserContext } from "../../../context/UserContext";
import { useErrorManager } from "../../../utils/manageApiError";
import { BrowserRouter } from "react-router-dom";
import { modules_const, common_labels } from "../../../utils/constants";

jest.mock("../../../utils/getEnv", () => ({
  getEnv: (key: string) => {
    if (key === "VITE_BACKEND_URL") return "https://mock-api.com";
    return "";
  },
}));

// ✅ Mock external services and dependencies
jest.mock("../../../services/modulesService");
jest.mock("../../../context/ModalPopupContext");
jest.mock("../../../context/UserContext");
jest.mock("../../../utils/manageApiError");

const mockShowModal = jest.fn();
const mockErrorManager = jest.fn();
const mockNavigate = jest.fn();

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useNavigate: () => mockNavigate,
}));

const renderWithRouter = (ui: React.ReactElement) => {
  return render(<BrowserRouter>{ui}</BrowserRouter>);
};

describe("ModulesGrid", () => {
  beforeEach(() => {
    (useModalPopup as jest.Mock).mockReturnValue({ showModal: mockShowModal });
    (useUserContext as jest.Mock).mockReturnValue({
      user: { is_dap_user: true },
      isAdmin: true,
    });
    (useErrorManager as jest.Mock).mockReturnValue(mockErrorManager);
    jest.clearAllMocks();
  });

  test("renders module section and calls APIs", async () => {
    (service.getTagList as jest.Mock).mockResolvedValue({
      status: "success",
      data: [{ id: 1, label: "Analytics" }],
    });

    (service.getModulesList as jest.Mock).mockResolvedValue({
      status: "success",
      data: [],
    });

    renderWithRouter(<ModulesGrid />);
    expect(screen.getByText(modules_const.modules)).toBeInTheDocument();

    await waitFor(() => {
      expect(service.getTagList).toHaveBeenCalled();
      expect(service.getModulesList).toHaveBeenCalled();
    });
  });

  test("displays error modal when getModulesList returns error", async () => {
    (service.getTagList as jest.Mock).mockResolvedValue({
      status: "success",
      data: [],
    });
    (service.getModulesList as jest.Mock).mockResolvedValue({
      status: "error",
      message: "Module fetch failed",
    });

    renderWithRouter(<ModulesGrid />);

    await waitFor(() => {
      expect(mockShowModal).toHaveBeenCalledWith(
        expect.objectContaining({
          title: "error",
          message: expect.stringContaining("Module fetch failed"),
        })
      );
    });
  });

  test("displays error modal when getTagList throws error", async () => {
    (service.getTagList as jest.Mock).mockRejectedValue(new Error("Network error"));
    (service.getModulesList as jest.Mock).mockResolvedValue({
      status: "success",
      data: [],
    });

    renderWithRouter(<ModulesGrid />);

    await waitFor(() => {
      expect(mockErrorManager).toHaveBeenCalledWith(expect.any(Error));
    });
  });

  test("filters modules based on tag selection", async () => {
    const mockModules = [
      {
        id: 1,
        label: "HR",
        icon_name: "package",
        url: "https://example.com/hr",
        has_access: true,
        order_index: 0,
        tags: [{ id: 2, label: "People" }],
      },
    ];

    (service.getTagList as jest.Mock).mockResolvedValue({
      status: "success",
      data: [{ id: 2, label: "People" }],
    });

    (service.getModulesList as jest.Mock).mockResolvedValue({
      status: "success",
      data: mockModules,
    });

    renderWithRouter(<ModulesGrid />);

    await waitFor(() => {
      expect(screen.getByText("HR")).toBeInTheDocument();
      const peopleTag = screen.getByRole("button", { name: "People" });
      fireEvent.click(peopleTag);
    });

    expect(screen.getByText("HR")).toBeInTheDocument();
  });

  test("shows confirmation modal for module with confirmation_step", async () => {
    const moduleWithConfirmation = {
      id: 2,
      label: "Secure Module",
      icon_name: "package",
      url: "https://example.com/secure",
      has_access: true,
      confirmation_step: true,
      confirmation_text: "Are you sure?",
      order_index: 1,
      tags: [],
    };

    (service.getTagList as jest.Mock).mockResolvedValue({
      status: "success",
      data: [],
    });

    (service.getModulesList as jest.Mock).mockResolvedValue({
      status: "success",
      data: [moduleWithConfirmation],
    });

    renderWithRouter(<ModulesGrid />);

    await waitFor(() => {
      const secureModule = screen.getByText("Secure Module");
      fireEvent.click(secureModule);
    });

    expect(await screen.findByText("Are you sure?")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: common_labels.view })).toBeInTheDocument();
  });
});