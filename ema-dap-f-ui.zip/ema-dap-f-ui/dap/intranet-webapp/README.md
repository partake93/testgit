# EMA DAP Intranet Webapp (AKA Landing Page)

This project provides a basic webapp with login functionality and a landing page.

## Getting Started

To get started with the EMA DAP web application on local environment, follow these steps:
- First, install the required backend dependencies
- Setup the Python virtual environment
- [Start the backend](#start-the-backend-server)

### Install the required backend dependencies:
- Python `3.11.9` (do not use `3.12` at this stage)
- Follow the instructions for setting up of the virtual environment

### Install the required frontend dependencies:
- Node.js (version `14.15.0` or higher - prefer version `22.13.1`)
- npm (gets installed when you install Node.js, version I have is `10.9.2`)
- Run the following commands in the terminal.
> Please ensure that you are inside the `intranet-webapp` directory (directly under the `code` directory) under the project directory.

```
C:\path-to-project-directory-on-laptop>cd code\intranet-webapp\frontend
C:\path-to-project-directory-on-laptop\code\intranet-webapp\frontend>npm install
```
> Note: You may encounter some issues when running this on the Terminal within VSCode. If you do, use CMD instead.

If you encounter issues, try the following
```
C:\path-to-project-directory-on-laptop\code\intranet-webapp\frontend>(if exist node_modules rmdir /s /q node_modules) && (if exist package-lock.json del package-lock.json)

### Setup the Python virtual environment
This is required for the backend.
Run the following commands in the terminal:
```
cd backend

```bash
C:\path-to-project-directory-on-laptop>mkdir venvs
C:\path-to-project-directory-on-laptop>cd venvs
C:\path-to-project-directory-on-laptop\venvs>python -m venv venv-1
C:\path-to-project-directory-on-laptop\venvs>cd ..
C:\path-to-project-directory-on-laptop>venvs\venv-1\Scripts\activate.bat
(venv-1) C:\path-to-project-directory-on-laptop>cd code\intranet-webapp\backend
(venv-1) C:\path-to-project-directory-on-laptop\code\intranet-webapp\backend>pip install -r requirements.txt
(venv-1) C:\path-to-project-directory-on-laptop\code\intranet-webapp\backend>cd app
(venv-1) C:\path-to-project-directory-on-laptop\code\intranet-webapp\backend\app>uvicorn main:app --host 0.0.0.0 --port 8000
```