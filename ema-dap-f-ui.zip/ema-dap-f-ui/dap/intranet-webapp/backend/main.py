import os

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
# from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

import models
from database import engine
from routers import (
    announcements,
    auth,
    auth_oidc,
    dashboards,
    modules,
    notifications,
    notifications_queue,
    quickactions,
    requests,
    uploads,
)

app = FastAPI()
app.add_middleware(
    SessionMiddleware, secret_key="123", https_only=True
)

load_dotenv()
FE_URL = os.getenv("FE_URL", "")
origins = [FE_URL]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

models.Base.metadata.create_all(bind=engine)

app.include_router(auth.router)
app.include_router(auth_oidc.router)
app.include_router(quickactions.router)
app.include_router(announcements.router)
app.include_router(modules.router)
app.include_router(dashboards.router)
app.include_router(notifications.router)
app.include_router(uploads.router)
app.include_router(requests.router)
app.include_router(notifications_queue.router)

# app.mount("/temp_uploads", StaticFiles(directory="temp_uploads"), name="temp_uploads")
# @app.on_event("startup")
# @repeat_at(cron="0 0 * * *")  # every 24 hours at midnight
# async def hey():
#     print("hey")

