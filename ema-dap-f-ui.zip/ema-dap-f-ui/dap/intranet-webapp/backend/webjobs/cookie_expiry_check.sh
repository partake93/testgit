#!/bin/bash

# Access environment variables
API_KEY="$SCHEDULER_API_KEY"
BE_URL="$BE_URL"

# Use the secret value (e.g., trigger an API)
API_URL="$BE_URL/api/auth/cookie_expiry_check"
RESPONSE=$(curl -s "$API_URL" -H "Authorization: Bearer $API_KEY")

# Get current Singapore time
SG_TIME=$(TZ="Asia/Singapore" date "+%Y-%m-%d %H:%M:%S")
echo "Current SG Time: $SG_TIME"

# Check if the request was successful
if [ $? -eq 0 ]; then
    echo "RESPONSE: $RESPONSE"
else
    echo "Failed to trigger API."
    exit 1
fi

