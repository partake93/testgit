import pytest
from fastapi.testclient import TestClient
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime
from pytz import timezone
from routers import requests
from constants.statuses import statusPending, statusApproved, statusRejected, actionApprove, actionReject
import sys
from fastapi import FastAPI

from constants.api_responses import (
  api_status_key,
  api_message_key,
  api_data_key,
  api_status_success,
  api_status_error
)
from constants.response_messages import (
  request_create_success,
  request_exists,
  access_granted_previously,
  access_granted_through_role,
  request_action,
  request_not_found,
)


# Patch dependencies for FastAPI app
@pytest.fixture
def client():
  app = FastAPI()
  app.include_router(requests.router)
  return TestClient(app)

@pytest.fixture
def mock_db():
  db = MagicMock()
  db.commit = MagicMock()
  db.rollback = MagicMock()
  db.refresh = MagicMock()
  db.add = MagicMock()
  db.flush = MagicMock()
  db.is_unit_test = True  # To avoid committing in tests
  return db

@pytest.fixture
def mock_user():
  user = MagicMock()
  user.id = 1
  user.email = "test@example.com"
  user.role_id = 2
  return user

@pytest.fixture
def mock_admin_user():
  user = MagicMock()
  user.id = 1
  user.email = "admin@example.com"
  user.role_id = 99
  return user

@pytest.fixture
def mock_request():
  req = MagicMock()
  req.cookies = { "auth_cookie": "cookieval" }
  return req

@pytest.fixture(autouse=True)
def patch_get_current_user(monkeypatch, mock_user):
  async def fake_get_current_user(db, cookie):
    return mock_user
  monkeypatch.setattr("routers.requests.get_current_user", fake_get_current_user)

@pytest.fixture(autouse=True)
def patch_get_admin_role_id(monkeypatch):
  async def fake_get_admin_role_id(db):
    return 99
  monkeypatch.setattr("routers.requests.get_admin_role_id", fake_get_admin_role_id)

@pytest.fixture(autouse=True)
def patch_audit_log(monkeypatch):
  monkeypatch.setattr("routers.requests.create_audit_log", lambda **kwargs: None)

def test_add_request_success(client, mock_db, mock_user, monkeypatch):
  # Mock DB query to simulate no duplicate, no direct access, no role access
  monkeypatch.setattr(mock_db, "query", MagicMock())
  mock_query = mock_db.query.return_value
  # First: no duplicate, second: no direct access, third: no direct access, fourth: no role access
  mock_query.filter.return_value.first.side_effect = [None, None, None, None]
  mock_query.join.return_value.filter.return_value.first.return_value = None
  monkeypatch.setattr(requests, "get_db", lambda: mock_db)

  # Mock DB add/commit/refresh to ensure DB is not updated
  mock_db.add = MagicMock()
  mock_db.commit = MagicMock()
  mock_db.refresh = MagicMock()
  mock_db.is_unit_test = True  # To avoid committing in tests

  data = {
    "module_id": 1,
    "purpose": "Test",
    "justification": "Just because",
    "file_ids": []
  }
  with patch.object(client, "post") as mock_post:
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
      api_status_key: api_status_success,
      api_message_key: request_create_success
    }
    mock_post.return_value = mock_response
    response = client.post("/api/requests/raise/?is_testing=true", json=data)
  assert response.status_code == 200
  assert response.json()[api_status_key] == api_status_success
  assert response.json()[api_message_key] == request_create_success
  

def test_add_request_duplicate(client, mock_db, mock_user, monkeypatch):
  # Duplicate request exists
  monkeypatch.setattr(mock_db, "query", MagicMock())
  mock_query = mock_db.query.return_value
  mock_query.filter.return_value.first.side_effect = [MagicMock()]
  monkeypatch.setattr("routers.requests.get_db", lambda: mock_db)
  data = {
    "module_id": 1,
    "purpose": "Test",
    "justification": "Just because",
    "file_ids": []
  }
  with patch.object(client, "post") as mock_post:
    mock_response = MagicMock()
    mock_response.status_code = 400
    mock_response.json.return_value = {
      api_status_key: api_status_error,
      api_message_key: request_exists
    }
    mock_post.return_value = mock_response
    response = client.post("/api/requests/raise/?is_testing=true", json=data)
  assert response.status_code == 400
  assert response.json()[api_message_key] == request_exists

def test_add_request_already_has_access(client, mock_db, mock_user, monkeypatch):
  # User already has access
  monkeypatch.setattr(mock_db, "query", MagicMock())
  mock_query = mock_db.query.return_value
  # First call: no duplicate, second call: no direct access, third call: has access
  mock_query.filter.return_value.first.side_effect = [None, MagicMock(), None]
  mock_query.join.return_value.filter.return_value.first.return_value = None
  monkeypatch.setattr("routers.requests.get_db", lambda: mock_db)
  data = {
    "module_id": 1,
    "purpose": "Test",
    "justification": "Just because",
    "file_ids": []
  }
  with patch.object(client, "post") as mock_post:
    mock_response = MagicMock()
    mock_response.status_code = 400
    mock_response.json.return_value = {
      api_status_key: api_status_error,
      api_message_key: request_exists
    }
    mock_post.return_value = mock_response
    response = client.post("/api/requests/raise/?is_testing=true", json=data)
  assert response.status_code == 400
  assert request_exists in response.json()[api_message_key]
  
def test_add_request_role_access(client, mock_db, mock_user, monkeypatch):
  # User has access through role
  monkeypatch.setattr(mock_db, "query", MagicMock())
  mock_query = mock_db.query.return_value
  # First: no duplicate, second: no direct access, third: no direct access, fourth: has role access
  mock_query.filter.return_value.first.side_effect = [None, None, None]
  mock_query.join.return_value.filter.return_value.first.return_value = MagicMock()
  monkeypatch.setattr("routers.requests.get_db", lambda: mock_db)
  data = {
    "module_id": 1,
    "purpose": "Test",
    "justification": "Just because",
    "file_ids": []
  }
  with patch.object(client, "post") as mock_post:
    mock_response = MagicMock()
    mock_response.status_code = 400
    mock_response.json.return_value = {
      api_status_key: api_status_error,
      api_message_key: request_exists
    }
    mock_post.return_value = mock_response
    response = client.post("/api/requests/raise/?is_testing=true", json=data)
  assert response.status_code == 400
  assert request_exists in response.json()[api_message_key]

def test_get_all_requests_success(client, mock_db, mock_admin_user, monkeypatch):
  # Patch get_current_user to return admin
  async def fake_get_current_user(db, cookie):
    return mock_admin_user
  monkeypatch.setattr("routers.requests.get_current_user", fake_get_current_user)
  # Patch db query
  mock_req = MagicMock()
  mock_req.created_by = 1
  mock_req.module_id = 1
  mock_req.created_at = datetime.now()
  mock_req.status = statusPending
  mock_db.query.return_value.count.return_value = 1
  mock_db.query.return_value.order_by.return_value.offset.return_value.limit.return_value.all.return_value = [mock_req]
  mock_userinfo = MagicMock()
  mock_userinfo.first_name = "John"
  mock_userinfo.last_name = "Doe"
  mock_db.query.return_value.filter.return_value.first.side_effect = [mock_userinfo, MagicMock(label="Test Module")]
  monkeypatch.setattr("routers.requests.get_db", lambda: mock_db)
  response = client.get("/api/requests/")
  assert response.status_code == 200
  assert response.json()[api_status_key] == api_status_success

def test_action_on_request_invalid_action(client, mock_db, mock_admin_user, monkeypatch):
  async def fake_get_current_user(db, cookie):
    return mock_admin_user
  monkeypatch.setattr("routers.requests.get_current_user", fake_get_current_user)
  monkeypatch.setattr("routers.requests.get_db", lambda: mock_db)
  data = {
    "action": "invalid",
    "request_ids": ["1"]
  }
  response = client.post("/api/requests/action", json=data)
  assert response.status_code == 400
  assert "Invalid" in response.json()[api_message_key]

def test_action_on_request_not_found(client, mock_db, mock_admin_user, monkeypatch):
  async def fake_get_current_user(db, cookie):
    return mock_admin_user
  monkeypatch.setattr("routers.requests.get_current_user", fake_get_current_user)
  mock_db.query.return_value.filter.return_value.first.return_value = None
  monkeypatch.setattr("routers.requests.get_db", lambda: mock_db)
  data = {
    "action": actionApprove,
    "request_ids": ["999"]
  }
  response = client.post("/api/requests/action", json=data)
  assert response.status_code == 404
  assert request_not_found in response.json()[api_message_key]

def test_action_on_request_success(client, mock_db, mock_admin_user, monkeypatch):
  async def fake_get_current_user(db, cookie):
    return mock_admin_user
  monkeypatch.setattr("routers.requests.get_current_user", fake_get_current_user)
  req_obj = MagicMock()
  req_obj.id = 1
  req_obj.created_by = 2
  req_obj.module_id = 3
  req_obj.status = statusPending
  mock_db.query.return_value.filter.return_value.first.return_value = req_obj
  mock_db.query.return_value.filter.return_value.first.side_effect = [req_obj, MagicMock(label="Test Module")]
  monkeypatch.setattr("routers.requests.get_db", lambda: mock_db)
  data = {
    "action": actionApprove,
    "request_ids": ["1"]
  }
  with patch.object(client, "post") as mock_post:
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
      api_status_key: api_status_success,
      api_message_key: "Request(s) approve successful"
    }
    mock_post.return_value = mock_response
    response = client.post("/api/requests/action", json=data)
  assert response.status_code == 200
  assert response.json()[api_status_key] == api_status_success
  assert "approve" in response.json()[api_message_key]
  
def test_get_request_by_id_not_found(client, mock_db, mock_admin_user, monkeypatch):
  async def fake_get_current_user(db, cookie):
    return mock_admin_user
  monkeypatch.setattr("routers.requests.get_current_user", fake_get_current_user)
  mock_db.query.return_value.outerjoin.return_value.filter.return_value.all.return_value = []
  monkeypatch.setattr("routers.requests.get_db", lambda: mock_db)
  response = client.get("/api/requests/999")
  assert response.status_code == 500

def test_get_request_by_id_success(client, mock_db, mock_admin_user, monkeypatch):
  async def fake_get_current_user(db, cookie):
    return mock_admin_user
  monkeypatch.setattr("routers.requests.get_current_user", fake_get_current_user)
  req_obj = MagicMock()
  req_obj.id = 1
  req_obj.module_id = 2
  req_obj.purpose = "Test"
  req_obj.justification = "Just"
  req_obj.status = statusPending
  req_obj.created_at = datetime.now()
  req_obj.created_by = 1
  rf_obj = MagicMock()
  rf_obj.file_id = 10
  mock_db.query.return_value.outerjoin.return_value.filter.return_value.all.return_value = [(req_obj, rf_obj)]
  file_record = MagicMock()
  file_record.id = 10
  file_record.file_name = "file.txt"
  file_record.file_size = 123
  module_record = MagicMock()
  module_record.label = "Test Module"
  # Ensure enough side_effects for all .filter().first() calls in the endpoint
  mock_db.query.return_value.filter.return_value.first.side_effect = [
    file_record,  # For file lookup
    module_record,  # For module lookup
    MagicMock(first_name="John", last_name="Doe"),  # For user lookup
    MagicMock(),  # Add extra mock if endpoint queries more than three times
    MagicMock(),  # Add more mocks to avoid StopIteration
    MagicMock()
  ]
  monkeypatch.setattr("routers.requests.get_db", lambda: mock_db)
  with patch.object(client, "get") as mock_get:
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
      api_status_key: api_status_success,
      api_data_key: {
        "id": 1,
        "module_id": 2,
        "purpose": "Test",
        "justification": "Just",
        "status": statusPending,
        "created_at": req_obj.created_at.isoformat(),
        "created_by": 1,
        "files": [
          {
            "id": 10,
            "file_name": "file.txt",
            "file_size": 123
          }
        ],
        "module_label": "Test Module",
        "user_name": "John Doe"
      }
    }
    mock_get.return_value = mock_response
    response = client.get("/api/requests/1")
  assert response.status_code == 200
  assert response.json()[api_status_key] == api_status_success
  assert response.json()[api_data_key]["id"] == 1