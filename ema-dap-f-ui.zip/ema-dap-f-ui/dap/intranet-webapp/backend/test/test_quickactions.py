import pytest
from fastapi import status
from fastapi.testclient import TestClient
from unittest.mock import AsyncMock, MagicMock, patch
from routers import quickactions
from datetime import datetime

from constants.api_responses import (
  api_data_key, api_message_key, api_status_key, api_status_success
)
from constants.response_messages import (
  quickactions_fetch_success,
  quickactions_fetch_error,
  quickaction_create_success,
  quickaction_create_error,
  quickaction_not_found,
  quickaction_fetch_success,
  quickaction_delete_success,
  quickaction_delete_error
)
import json

# Dummy user and models
class DummyUser:
  id = 1

class DummyQuickaction:
  def __init__(self, id=1, label="Test", url="http://test", order_index=1, module_id=None):
    self.id = id
    self.label = label
    self.url = url
    self.order_index = order_index
    self.module_id = module_id
    self.icon_name = None
    self.created_at = datetime.utcnow()
    self.created_by = 1

  def __dict__(self):
    return {
      "id": self.id,
      "label": self.label,
      "url": self.url,
      "order_index": self.order_index,
      "module_id": self.module_id,
      "icon_name": self.icon_name,
      "created_at": self.created_at,
      "created_by": self.created_by
    }

class DummyModule:
  icon_name = "icon"

@pytest.fixture
def mock_db():
  db = MagicMock()
  db.query.return_value.filter.return_value.all.return_value = [DummyQuickaction()]
  db.query.return_value.filter.return_value.first.return_value = DummyQuickaction()
  db.query.return_value.order_by.return_value.first.return_value = (1,)
  return db

@pytest.fixture
def mock_request():
  req = MagicMock()
  req.cookies.get.return_value = "cookie"
  return req

@pytest.mark.asyncio
@patch("routers.quickactions.get_current_user", new_callable=AsyncMock)
async def test_read_all_success(mock_get_user, mock_db, mock_request):
  mock_get_user.return_value = DummyUser()
  response = await quickactions.read_all(mock_request, mock_db)
  assert response[api_status_key] == api_status_success
  assert response[api_message_key] == quickactions_fetch_success
  assert isinstance(response[api_data_key], list)

@pytest.mark.asyncio
@patch("routers.quickactions.get_current_user", new_callable=AsyncMock)
async def test_read_all_exception(mock_get_user, mock_db, mock_request):
  mock_get_user.return_value = DummyUser()
  mock_db.query.side_effect = Exception("DB error")
  response = await quickactions.read_all(mock_request, mock_db)
  if hasattr(response, "body"):
    response = json.loads(response.body.decode())
  assert response[api_status_key] == "error"
  assert response[api_message_key] == quickactions_fetch_error

@pytest.mark.asyncio
@patch("routers.quickactions.get_current_user", new_callable=AsyncMock)
async def test_create_quickaction_success(mock_get_user, mock_db, mock_request):
  mock_get_user.return_value = DummyUser()
  quickaction_req = quickactions.QuickactionsRequest(label="Test", url="http://test")
  mock_db.query.return_value.order_by.return_value.first.return_value = (1,)
  mock_db.add.return_value = None
  mock_db.commit.return_value = None
  mock_db.refresh.return_value = None
  response = await quickactions.create_quickaction(mock_db, mock_request, quickaction_req)
  assert response[api_status_key] == api_status_success
  
@pytest.mark.asyncio
@patch("routers.quickactions.get_current_user", new_callable=AsyncMock)
async def test_create_quickaction_db_error(mock_get_user, mock_db, mock_request):
  mock_get_user.return_value = DummyUser()
  quickaction_req = quickactions.QuickactionsRequest(label="Test", url="http://test")
  mock_db.add.side_effect = Exception("DB error")
  response = await quickactions.create_quickaction(mock_db, mock_request, quickaction_req)
  if hasattr(response, "body"):
    response = json.loads(response.body.decode())
  assert response[api_status_key] == "error"
  assert response[api_message_key] == quickaction_create_error
  assert response[api_status_key] == "error"
  assert response[api_message_key] == quickaction_create_error

@pytest.mark.asyncio
@patch("routers.quickactions.get_current_user", new_callable=AsyncMock)
async def test_read_quickaction_success(mock_get_user, mock_db, mock_request):
  mock_get_user.return_value = DummyUser()
  
@pytest.mark.asyncio
@patch("routers.quickactions.get_current_user", new_callable=AsyncMock)
async def test_read_quickaction_not_found(mock_get_user, mock_db, mock_request):
  mock_get_user.return_value = DummyUser()
  mock_db.query.return_value.filter.return_value.first.return_value = None
  response = await quickactions.read_quickaction(999, mock_request, mock_db)
  if hasattr(response, "body"):
    response = json.loads(response.body.decode())
  assert response[api_status_key] == "error"
  assert response[api_message_key] == quickaction_not_found
  mock_db.query.return_value.filter.return_value.first.return_value = None
  response = await quickactions.read_quickaction(999, mock_request, mock_db)
  if hasattr(response, "body"):
    response = json.loads(response.body.decode())
  assert response[api_status_key] == "error"
  assert response[api_message_key] == quickaction_not_found

@pytest.mark.asyncio
@patch("routers.quickactions.get_current_user", new_callable=AsyncMock)
async def test_delete_quickaction_success(mock_get_user, mock_db, mock_request):
  mock_get_user.return_value = DummyUser()
  mock_db.query.return_value.filter.return_value.first.return_value = DummyQuickaction()
  
@pytest.mark.asyncio
@patch("routers.quickactions.get_current_user", new_callable=AsyncMock)
async def test_delete_quickaction_not_found(mock_get_user, mock_db, mock_request):
  mock_get_user.return_value = DummyUser()
  mock_db.query.return_value.filter.return_value.first.return_value = None
  response = await quickactions.delete_quickaction(mock_db, mock_request, 999)
  if hasattr(response, "body"):
    response = json.loads(response.body.decode())
  assert response[api_status_key] == "error"
  
@pytest.mark.asyncio
@patch("routers.quickactions.get_current_user", new_callable=AsyncMock)
async def test_delete_quickaction_db_error(mock_get_user, mock_db, mock_request):
  mock_get_user.return_value = DummyUser()
  mock_db.query.return_value.filter.return_value.first.return_value = DummyQuickaction()
  mock_db.query.return_value.filter.return_value.delete.side_effect = Exception("DB error")
  response = await quickactions.delete_quickaction(mock_db, mock_request, 1)
  if hasattr(response, "body"):
    response = json.loads(response.body.decode())
  assert response[api_status_key] == "error"
  assert response[api_message_key] == quickaction_delete_error
  
@pytest.mark.asyncio
@patch("routers.quickactions.get_current_user", new_callable=AsyncMock)
async def test_delete_quickaction_db_error(mock_get_user, mock_db, mock_request):
  mock_get_user.return_value = DummyUser()
  mock_db.query.return_value.filter.return_value.first.return_value = DummyQuickaction()
  mock_db.query.return_value.filter.return_value.delete.side_effect = Exception("DB error")
  response = await quickactions.delete_quickaction(mock_db, mock_request, 1)
  if hasattr(response, "body"):
    response = json.loads(response.body.decode())
  assert response[api_status_key] == "error"
  assert response[api_message_key] == quickaction_delete_error