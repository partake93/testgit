import pytest
from unittest.mock import patch, MagicMock, AsyncMock
from fastapi import status
from starlette.requests import Request
from routers import notifications_queue

@pytest.fixture
def mock_db():
  db = MagicMock()
  db.add = MagicMock()
  db.commit = MagicMock()
  db.refresh = MagicMock()
  db.rollback = MagicMock()
  db.delete = MagicMock()
  db.execute = MagicMock()
  return db

@pytest.fixture
def mock_request():
  req = MagicMock(spec=Request)
  req.headers = {}
  return req

def test_get_alert_log_found(mock_db):
  mock_result = MagicMock()
  mock_row = MagicMock()
  mock_result.fetchone.return_value = mock_row
  mock_db.execute.return_value = mock_result
  result = notifications_queue.get_alert_log(mock_db, "123")
  assert result == mock_row
  mock_db.execute.assert_called_once()

def test_get_alert_log_not_found(mock_db):
  mock_result = MagicMock()
  mock_result.fetchone.return_value = None
  mock_db.execute.return_value = mock_result
  result = notifications_queue.get_alert_log(mock_db, "notfound")
  assert result is None

def test_get_create_datetime_valid():
  alert_log = MagicMock()
  alert_log.CREATE_DATETIME = "2024-06-01T12:00:00"
  dt = notifications_queue.get_create_datetime(alert_log)
  assert dt is not None

def test_get_create_datetime_none():
  alert_log = MagicMock()
  alert_log.CREATE_DATETIME = None
  dt = notifications_queue.get_create_datetime(alert_log)
  assert dt is None

def test_get_error_datetime_valid():
  alert_log = MagicMock()
  alert_log.ERROR_DATETIME = "2024-06-01T12:00:00"
  dt = notifications_queue.get_error_datetime(alert_log)
  assert dt is not None

def test_get_error_datetime_none():
  alert_log = MagicMock()
  alert_log.ERROR_DATETIME = None
  dt = notifications_queue.get_error_datetime(alert_log)
  assert dt is None

# @pytest.mark.asyncio
# async def test_get_notification_from_queue_invalid_auth(monkeypatch, mock_request, mock_db):
#   mock_request.headers = {}
#   monkeypatch.delenv("SCHEDULER_API_KEY", raising=False)
#   with patch("routers.notifications_queue.error_response") as error_response:
#     error_response.return_value = {"error": "invalid_user"}
#     resp = await notifications_queue.get_notification_from_queue(
#       mock_request, mock_db, "hard"
#     )
#     assert resp == {"error": "invalid_user"}

@pytest.mark.asyncio
async def test_get_notification_from_queue_valid_auth(monkeypatch, mock_request, mock_db):
  mock_request.headers = {"Authorization": "Bearer testkey"}
  monkeypatch.setenv("SCHEDULER_API_KEY", "testkey")
  with patch("routers.notifications_queue.get_messages") as get_messages:
    get_messages.return_value = [{"message_id": "abc"}]
    resp = await notifications_queue.get_notification_from_queue(
      mock_request, mock_db, "hard"
    )
    assert resp == [{"message_id": "abc"}]

def test_get_messages_hard(monkeypatch, mock_db):
  # Patch QueueClient and dependencies
  mock_queue_client = MagicMock()
  mock_msg = MagicMock()
  mock_msg.id = "msgid"
  mock_msg.content.decode.return_value = "errorlogid"
  mock_msg.inserted_on = None
  mock_queue_client.receive_messages.return_value.by_page.return_value = [[mock_msg]]
  monkeypatch.setattr(notifications_queue, "QueueClient", MagicMock())
  notifications_queue.QueueClient.from_connection_string.return_value = mock_queue_client
  with patch("routers.notifications_queue.get_alert_log") as get_alert_log, \
     patch("routers.notifications_queue.get_create_datetime") as get_create_datetime, \
     patch("routers.notifications_queue.get_error_datetime") as get_error_datetime, \
     patch.object(mock_db, "add"), patch.object(mock_db, "commit"), patch.object(mock_db, "refresh"):
    get_alert_log.return_value = MagicMock(
      ERROR_LOG_ID="errid", MODULE="mod", ZIP_FILE_NAME="zip", SOURCE_FILE_NAME="src",
      JOB_NAME="job", ERROR_CODE="ecode"
    )
    get_create_datetime.return_value = None
    get_error_datetime.return_value = None
    result = notifications_queue.get_messages(mock_db, "hard")
    assert isinstance(result, list)

def test_get_messages_soft(monkeypatch, mock_db):
  mock_queue_client = MagicMock()
  mock_msg = MagicMock()
  mock_msg.id = "msgid"
  mock_msg.content = b"[errorlogid1,errorlogid2]"
  mock_msg.inserted_on = None
  mock_queue_client.receive_messages.return_value.by_page.return_value = [[mock_msg]]
  monkeypatch.setattr(notifications_queue, "QueueClient", MagicMock())
  notifications_queue.QueueClient.from_connection_string.return_value = mock_queue_client
  with patch("routers.notifications_queue.get_alert_log") as get_alert_log, \
     patch("routers.notifications_queue.get_create_datetime") as get_create_datetime, \
     patch("routers.notifications_queue.get_error_datetime") as get_error_datetime, \
     patch.object(mock_db, "add"), patch.object(mock_db, "commit"), patch.object(mock_db, "refresh"):
    get_alert_log.return_value = MagicMock(
      ERROR_LOG_ID="errid", MODULE="mod", ZIP_FILE_NAME="zip", SOURCE_FILE_NAME="src",
      JOB_NAME="job", ERROR_CODE="ecode"
    )
    get_create_datetime.return_value = None
    get_error_datetime.return_value = None
    result = notifications_queue.get_messages(mock_db, "soft")
    assert isinstance(result, list)