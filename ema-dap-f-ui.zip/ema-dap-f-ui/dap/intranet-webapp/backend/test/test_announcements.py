import pytest
import pytest_asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from fastapi import status
from starlette.requests import Request
import sys 
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from routers import announcements

@pytest.fixture
def mock_db():
  return MagicMock()

@pytest.fixture
def mock_request():
  req = MagicMock(spec=Request)
  req.cookies = {announcements.auth_cookie_name: "fake_cookie"}
  return req

@pytest.fixture
def mock_user():
  user = MagicMock()
  user.id = 1
  user.role_id = 2
  user.email = "admin@example.com"
  return user

@pytest.fixture
def admin_role_id():
  return 2

@pytest.mark.asyncio
async def test_read_all_success(mock_db, mock_request, mock_user):
  with patch("routers.announcements.get_current_user", new=AsyncMock(return_value=mock_user)), \
     patch("routers.announcements.sg_tz", announcements.sg_tz):
    mock_db.query().order_by().offset().limit().all.return_value = []
    mock_db.query().count.return_value = 0
    response = await announcements.read_all(mock_db, mock_request, page=1)
    assert response[announcements.api_status_key] == announcements.api_status_success

@pytest.mark.asyncio
async def test_read_all_unauthorized(mock_db, mock_request):
  with patch("routers.announcements.get_current_user", new=AsyncMock(return_value=announcements.StarletteResponse("unauth", status_code=401))):
    response = await announcements.read_all(mock_db, mock_request, page=1)
    assert isinstance(response, announcements.StarletteResponse)

@pytest.mark.asyncio
async def test_read_published_success(mock_db, mock_request, mock_user):
  with patch("routers.announcements.get_current_user", new=AsyncMock(return_value=mock_user)):
    mock_db.query().filter().all.return_value = []
    response = await announcements.read_published(mock_db, mock_request)
    assert response[announcements.api_status_key] == announcements.api_status_success

@pytest.mark.asyncio
async def test_read_announcement_not_found(mock_db, mock_request, mock_user):
  with patch("routers.announcements.get_current_user", new=AsyncMock(return_value=mock_user)):
    mock_db.query().filter().first.return_value = None
    response = await announcements.read_announcement("1", mock_request, mock_db)
    
@pytest.mark.asyncio
async def test_create_announcement_success(mock_db, mock_request, mock_user, admin_role_id):
  req = announcements.AnnouncementsRequest(
      title="Test", text="Some text", url=None,
      start_date=announcements.datetime.now(), end_date=announcements.datetime.now(),
      status="draft"
  )
  with patch("routers.announcements.get_current_user", new=AsyncMock(return_value=mock_user)), \
     patch("routers.announcements.get_admin_role_id", new=AsyncMock(return_value=admin_role_id)), \
     patch("routers.announcements.create_audit_log"):
    mock_db.query().order_by().first.return_value = [0]
    mock_db.query().filter().count.return_value = 0
    mock_db.add = MagicMock()
    mock_db.commit = MagicMock()
    mock_db.refresh = MagicMock()
    response = await announcements.create_announcement(mock_db, mock_request, req)
    assert response[announcements.api_status_key] == announcements.api_status_success

@pytest.mark.asyncio
async def test_create_announcement_unauthorized(mock_db, mock_request, mock_user):
  mock_user.role_id = 99
  req = announcements.AnnouncementsRequest(
    title="Test", text="Some text", url=None,
    start_date=announcements.datetime.now(), end_date=announcements.datetime.now(),
    status="draft"
  )
  with patch("routers.announcements.get_current_user", new=AsyncMock(return_value=mock_user)), \
     patch("routers.announcements.get_admin_role_id", new=AsyncMock(return_value=2)), \
     patch("routers.announcements.unauthorised_response", new=AsyncMock(return_value={"unauth": True})):
    response = await announcements.create_announcement(mock_db, mock_request, req)
    assert "unauth" in response

@pytest.mark.asyncio
async def test_update_announcement_not_found(mock_db, mock_request, mock_user, admin_role_id):
  req = announcements.AnnouncementsRequest(
    title="Test", text="Some text", url=None,
    start_date=announcements.datetime.now(), end_date=announcements.datetime.now(),
    status="draft"
  )
  with patch("routers.announcements.get_current_user", new=AsyncMock(return_value=mock_user)), \
     patch("routers.announcements.get_admin_role_id", new=AsyncMock(return_value=admin_role_id)):
    mock_db.query().filter().first.return_value = None
    response = await announcements.update_announcement(mock_db, mock_request, req, "1")

@pytest.mark.asyncio
async def test_delete_announcement_not_found(mock_db, mock_request, mock_user, admin_role_id):
  with patch("routers.announcements.get_current_user", new=AsyncMock(return_value=mock_user)), \
     patch("routers.announcements.get_admin_role_id", new=AsyncMock(return_value=admin_role_id)):
    mock_db.query().filter().first.return_value = None
    response = await announcements.delete_announcement(mock_db, mock_request, "1")
    assert hasattr(response, "status_code")
    assert response.status_code != 200

@pytest.mark.asyncio
async def test_sort_announcements_success(mock_db, mock_request, mock_user, admin_role_id):
  req = announcements.AnnouncementSortRequest(
    updates=[
      announcements.AnnouncementSortUpdate(announcement_id=1, newIndex=2),
      announcements.AnnouncementSortUpdate(announcement_id=2, newIndex=1)
    ]
  )
  with patch("routers.announcements.get_current_user", new=AsyncMock(return_value=mock_user)), \
     patch("routers.announcements.get_admin_role_id", new=AsyncMock(return_value=admin_role_id)), \
     patch("routers.announcements.create_audit_log"):
    mock_db.query().filter().update = MagicMock()
    mock_db.commit = MagicMock()
    response = await announcements.sort_announcements(mock_db, mock_request, req)
    assert response[announcements.api_status_key] == announcements.api_status_success