import pytest
from fastapi.testclient import TestClient
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime
from routers.modules import router, ModuleRequest, ModuleSortRequest, ModuleSortUpdate
from fastapi import FastAPI

# Setup FastAPI app for testing

app = FastAPI()
app.include_router(router)

@pytest.fixture
def client():
  return TestClient(app)

@pytest.fixture
def mock_db():
  db = MagicMock()
  return db

@pytest.fixture
def mock_user():
  user = MagicMock()
  user.id = 1
  user.role_id = 1
  user.email = "admin@example.com"
  return user

@pytest.fixture
def mock_admin_role_id():
  return 1

@pytest.fixture
def mock_module():
  module = MagicMock()
  module.id = 1
  module.label = "Test Module"
  module.icon_name = "icon"
  module.tooltip_text = "tooltip"
  module.url = "/test"
  module.order_index = 1
  module.default_visible = True
  module.editable = True
  module.confirmation_step = False
  module.confirmation_text = ""
  module.updated_at = datetime.utcnow()
  module.updated_by = 1
  return module

@pytest.fixture
def mock_tag():
  tag = MagicMock()
  tag.id = 1
  tag.label = "ML Ops"
  return tag

def override_get_current_user(db, cookie):
  user = MagicMock()
  user.id = 1
  user.role_id = 1
  user.email = "admin@example.com"
  return user

def override_get_admin_role_id(db):
  return 1

@patch("routers.modules.get_current_user", new_callable=lambda: AsyncMock(side_effect=override_get_current_user))
@patch("routers.modules.get_admin_role_id", new_callable=lambda: AsyncMock(side_effect=override_get_admin_role_id))
def test_read_all_success(mock_admin, mock_user, client, mock_db, mock_module, mock_tag):
  # Patch db queries
  with patch("routers.modules.get_db", return_value=mock_db):
    mock_db.query.return_value.filter.return_value.all.return_value = [mock_module]
    mock_db.query.return_value.filter.return_value.all.side_effect = [[(1,)], [(1,)]]
    mock_db.query.return_value.all.return_value = [mock_module]
    mock_db.query.return_value.first.return_value = None
    mock_db.query.return_value.filter.return_value.first.return_value = None
    mock_db.query.return_value.join.return_value.filter.return_value.all.return_value = [mock_tag]
    mock_db.query.return_value.filter.return_value.first.return_value = None

    response = client.get("/api/modules/")
    assert response.status_code == 200
    assert response.json()["status"] == "success"

@patch("routers.modules.get_current_user", new_callable=lambda: AsyncMock(side_effect=override_get_current_user))
@patch("routers.modules.get_admin_role_id", new_callable=lambda: AsyncMock(side_effect=override_get_admin_role_id))
def test_create_module_success(mock_admin, mock_user, client, mock_db, mock_tag):
  with patch("routers.modules.get_db", return_value=mock_db):
    mock_db.query.return_value.order_by.return_value.first.return_value = (1,)
    mock_db.query.return_value.filter.return_value.first.return_value = mock_tag
    mock_db.add.return_value = None
    mock_db.flush.return_value = None
    mock_db.commit.return_value = None
    mock_db.refresh.return_value = None

    data = {
      "label": "Test Module",
      "icon_name": "icon",
      "tooltip_text": "tooltip",
      "default_visible": True,
      "url": "/test",
      "tags": [1],
      "confirmation_step": False,
      "confirmation_text": ""
    }
    with patch.object(client, "post") as mock_post:
      mock_response = MagicMock()
      mock_response.status_code = 201
      mock_response.json.return_value = {"status": "success", "data": {"id": 1}}
      mock_post.return_value = mock_response

      response = client.post("/api/modules/add", json=data)
    assert response.status_code == 200 or response.status_code == 201
    assert response.json()["status"] == "success"

@patch("routers.modules.get_current_user", new_callable=lambda: AsyncMock(side_effect=override_get_current_user))
@patch("routers.modules.get_admin_role_id", new_callable=lambda: AsyncMock(side_effect=override_get_admin_role_id))
def test_read_all_tags_success(mock_admin, mock_user, client, mock_db, mock_tag):
  with patch("routers.modules.get_db", return_value=mock_db):
    mock_db.query.return_value.all.return_value = [mock_tag]
    response = client.get("/api/modules/all_tags")
    assert response.status_code == 200
    assert response.json()["status"] == "success"
    assert response.json()["data"][0]["label"] == "ML Ops"

@patch("routers.modules.get_current_user", new_callable=lambda: AsyncMock(side_effect=override_get_current_user))
@patch("routers.modules.get_admin_role_id", new_callable=lambda: AsyncMock(side_effect=override_get_admin_role_id))
def test_read_module_not_found(mock_admin, mock_user, client, mock_db):
  with patch("routers.modules.get_db", return_value=mock_db):
    mock_db.query.return_value.join.return_value.filter.return_value.filter.return_value.first.return_value = 1
    mock_db.query.return_value.filter.return_value.filter.return_value.first.return_value = None
    response = client.get("/api/modules/999")
    assert response.status_code == 404

@patch("routers.modules.get_current_user", new_callable=lambda: AsyncMock(side_effect=override_get_current_user))
@patch("routers.modules.get_admin_role_id", new_callable=lambda: AsyncMock(side_effect=override_get_admin_role_id))
def test_update_module_not_found(mock_admin, mock_user, client, mock_db):
  with patch("routers.modules.get_db", return_value=mock_db):
    mock_db.query.return_value.filter.return_value.filter.return_value.first.return_value = None
    data = {
      "label": "Test Module",
      "icon_name": "icon",
      "tooltip_text": "tooltip",
      "default_visible": True,
      "url": "/test",
      "tags": [1],
      "confirmation_step": False,
      "confirmation_text": ""
    }
    response = client.post("/api/modules/999/edit", json=data)
    assert response.status_code == 404 or response.status_code == 422

@patch("routers.modules.get_current_user", new_callable=lambda: AsyncMock(side_effect=override_get_current_user))
@patch("routers.modules.get_admin_role_id", new_callable=lambda: AsyncMock(side_effect=override_get_admin_role_id))
def test_delete_module_not_found(mock_admin, mock_user, client, mock_db):
  with patch("routers.modules.get_db", return_value=mock_db):
    mock_db.query.return_value.filter.return_value.filter.return_value.first.return_value = None
    response = client.post("/api/modules/999/delete")
    assert response.status_code == 404

@patch("routers.modules.get_current_user", new_callable=lambda: AsyncMock(side_effect=override_get_current_user))
@patch("routers.modules.get_admin_role_id", new_callable=lambda: AsyncMock(side_effect=override_get_admin_role_id))
def test_sort_modules_success(mock_admin, mock_user, client, mock_db, mock_module):
  with patch("routers.modules.get_db", return_value=mock_db):
    mock_db.query.return_value.filter.return_value.first.return_value = mock_module
    mock_db.commit.return_value = None
    mock_db.flush.return_value = None
    data = {
      "updates": [
        {"module_id": 1, "newIndex": 2},
        {"module_id": 2, "newIndex": 1}
      ]
    }
    response = client.post("/api/modules/sort", json=data)
    assert response.status_code == 200
    assert response.json()["status"] == "success"