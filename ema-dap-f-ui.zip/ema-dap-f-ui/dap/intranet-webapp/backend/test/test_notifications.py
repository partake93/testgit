import pytest
from fastapi import status
from fastapi.testclient import TestClient
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime
from constants.statuses import statusNeedAttention

from routers.notifications import (
  router,
  MarkAsViewedRequest,
  read_all,
  read_for_header,
  mark_as_viewed,
  read_notification,
)
from constants.api_responses import (
  api_status_key,
  api_message_key,
  api_data_key,
  api_status_success,
  api_total_count_key,
  api_total_pages_key,
)
from constants.response_messages import (
  notifications_fetch_success,
  notifications_hard_top_5_fetch_success,
  notification_already_viewed,
  notification_mark_viewed_success,
  notification_content_fetch_success,
  notification_not_found,
  notifications_mark_viewed_error
)

client = TestClient(router)

@pytest.fixture
def mock_db():
  return MagicMock()

@pytest.fixture
def mock_request():
  req = MagicMock()
  req.cookies = { "auth_cookie": "token" }
  return req

@pytest.fixture
def mock_user():
  user = MagicMock()
  user.id = 1
  user.role_id = 2
  return user

@pytest.mark.asyncio
@patch("routers.notifications.get_current_user", new_callable=AsyncMock)
@patch("routers.notifications.get_admin_role_id", new_callable=AsyncMock)
async def test_read_all_success(mock_admin_role, mock_current_user, mock_db, mock_request, mock_user):
  mock_current_user.return_value = mock_user
  mock_admin_role.return_value = 2

  notification = MagicMock()
  notification.id = 1
  notification.inserted_at = datetime(2024, 1, 1)
  notification.classification = statusNeedAttention
  notification.targeted_user_id = None
  notification.admin_only = False

  info = MagicMock()
  info.error_log_id = 123
  info.zip_file_name = "file.zip"
  info.source_file_name = "src.csv"
  info.data_module = "mod"
  info.error_code = "ERR"
  info.details = "details"

  mock_db.query().order_by().filter().filter().filter().offset().limit().all.return_value = [notification]
  mock_db.query().filter().first.return_value = info
  mock_db.query().filter().all.return_value = []
  mock_db.execute().fetchone.return_value = ("desc",)
  # Mock count() on all possible order_by/filter chains used in the code under test
  mock_db.query().order_by().filter().filter().filter().count.return_value = 1
  mock_db.query().order_by().filter().order_by().count.return_value = 1
  mock_db.query().order_by().filter().count.return_value = 1

  response = await read_all(mock_db, mock_request, page=1)
  assert response[api_status_key] == api_status_success
  assert response[api_message_key] == notifications_fetch_success
  assert response[api_total_count_key] == 1
  assert response[api_total_pages_key] == 1
  assert isinstance(response[api_data_key], list)

@pytest.mark.asyncio
@patch("routers.notifications.get_current_user", new_callable=AsyncMock)
@patch("routers.notifications.get_admin_role_id", new_callable=AsyncMock)
async def test_read_for_header_success(mock_admin_role, mock_current_user, mock_db, mock_request, mock_user):
  mock_current_user.return_value = mock_user
  mock_admin_role.return_value = 2

  notification = MagicMock()
  notification.id = 1
  notification.classification = statusNeedAttention
  info = MagicMock()
  info.error_code = "ERR"
  info.source_file_name = "src.csv"
  info.details = "details"

  mock_db.query().filter().order_by().limit().all.return_value = [notification]
  mock_db.query().filter().all.return_value = []
  mock_db.query().filter().first.return_value = info

  response = await read_for_header(mock_db, mock_request)
  assert response[api_status_key] == api_status_success
  assert response[api_message_key] == notifications_hard_top_5_fetch_success
  assert "notifications" in response[api_data_key]

@pytest.mark.asyncio
@patch("routers.notifications.get_current_user", new_callable=AsyncMock)
async def test_mark_as_viewed_already_viewed(mock_current_user, mock_db, mock_request, mock_user):
  mock_current_user.return_value = mock_user
  notification = MagicMock()
  notification.id = 1
  mock_db.query().filter().first.side_effect = [notification, MagicMock()]

  body = MarkAsViewedRequest(notification_id=1)
  response = await mark_as_viewed(mock_db, mock_request, body)
  assert response[api_status_key] == api_status_success
  assert response[api_message_key] == notification_already_viewed

@pytest.mark.asyncio
@patch("routers.notifications.get_current_user", new_callable=AsyncMock)
async def test_mark_as_viewed_success(mock_current_user, mock_db, mock_request, mock_user):
  mock_current_user.return_value = mock_user
  notification = MagicMock()
  notification.id = 1
  # First call: notification exists, Second call: not already viewed
  mock_db.query().filter().first.side_effect = [notification, None]

  body = MarkAsViewedRequest(notification_id=1)
  response = await mark_as_viewed(mock_db, mock_request, body)
  assert response[api_status_key] == api_status_success
  assert response[api_message_key] == notification_mark_viewed_success

@pytest.mark.asyncio
@patch("routers.notifications.get_current_user", new_callable=AsyncMock)
async def test_mark_as_viewed_not_found(mock_current_user, mock_db, mock_request, mock_user):
  mock_current_user.return_value = mock_user
  mock_db.query().filter().first.return_value = None

  body = MarkAsViewedRequest(notification_id=999)
  response = await mark_as_viewed(mock_db, mock_request, body)
  # If response is a FastAPI Response, extract status_code and body
  if hasattr(response, "status_code") and hasattr(response, "body"):
    import json
    response_json = json.loads(response.body)
    assert response.status_code == 500
    assert response_json["message"] == notifications_mark_viewed_error
  else:
    assert response["status_code"] == 404
    assert response["message"] == notification_not_found

@pytest.mark.asyncio
@patch("routers.notifications.get_current_user", new_callable=AsyncMock)
async def test_read_notification_success(mock_current_user, mock_db, mock_request, mock_user):
  mock_current_user.return_value = mock_user
  mock_db.execute().fetchone.return_value = ("",)
  error_log_id = "123"
  response = await read_notification(mock_db, mock_request, error_log_id)
  # If response is a FastAPI Response, get the JSON body
  if hasattr(response, "body"):
    import json
    response_json = json.loads(response.body)
  else:
    response_json = response
  assert response_json[api_status_key] == api_status_success
  assert response_json[api_message_key] == notification_content_fetch_success
  assert response_json[api_data_key]["notification"]["error_log_id"] == error_log_id
  assert "" in response_json[api_data_key]["notification"]["content"]

  response = await read_notification(mock_db, mock_request, error_log_id)
  # If response is a FastAPI Response, get the JSON body
  if hasattr(response, "body"):
    import json
    response_json = json.loads(response.body)
  else:
    response_json = response
  assert response_json[api_status_key] == api_status_success
  assert response_json[api_message_key] == notification_content_fetch_success
  assert response_json[api_data_key]["notification"]["content"] == ""
  mock_db.execute().fetchone.return_value = None
  error_log_id = "999"
  response = await read_notification(mock_db, mock_request, error_log_id)
  assert response[api_status_key] == api_status_success
  assert response[api_message_key] == notification_content_fetch_success
  assert response[api_data_key]["notification"]["content"] == ""