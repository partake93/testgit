import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock, AsyncMock
from starlette import status
from routers.uploads import router
from fastapi import FastAPI

app = FastAPI()
app.include_router(router)

@pytest.fixture
def client():
  return TestClient(app)

@pytest.fixture
def mock_db():
  db = MagicMock()
  db.query.return_value.filter.return_value.first.return_value = None
  return db

@pytest.fixture
def mock_user():
  user = MagicMock()
  user.id = 1
  user.role_id = 2
  return user

@pytest.fixture
def mock_file_record(mock_user):
  file_record = MagicMock()
  file_record.file_name = "testfile_1.txt"
  file_record.created_by = mock_user.id
  return file_record

@pytest.fixture
def mock_blob_service_client(monkeypatch):
  blob_client = MagicMock()
  blob_client.download_blob.return_value.readall.return_value = b"filedata"
  blob_client.upload_blob.return_value = None
  blob_client.url = "https://fakeurl/testfile_1.txt"
  container_client = MagicMock()
  container_client.get_blob_client.return_value = blob_client
  blob_service_client = MagicMock()
  blob_service_client.get_container_client.return_value = container_client
  monkeypatch.setattr("routers.uploads.BlobServiceClient.from_connection_string", lambda x: blob_service_client)
  return blob_service_client

@pytest.mark.asyncio
async def test_download_file_not_found(client, mock_db, monkeypatch):
  async def fake_get_current_user(db, cookie):
    return MagicMock(id=1, role_id=2)
  monkeypatch.setattr("routers.uploads.get_current_user", fake_get_current_user)
  monkeypatch.setattr("routers.uploads.get_admin_role_id", AsyncMock(return_value=99))
  response = client.get("/api/uploads/file/nonexistent.txt")
  assert response.status_code == 404
  assert "not found" in response.json()["message"].lower()

@pytest.mark.asyncio
async def test_download_file_success(client, mock_db, mock_user, mock_file_record, monkeypatch, mock_blob_service_client):
  async def fake_get_current_user(db, cookie):
    return mock_user
  monkeypatch.setattr("routers.uploads.get_current_user", fake_get_current_user)
  monkeypatch.setattr("routers.uploads.get_admin_role_id", AsyncMock(return_value=mock_user.role_id))
  mock_db.query.return_value.filter.return_value.first.return_value = mock_file_record

  # Override FastAPI dependency for get_db to use mock_db
  app.dependency_overrides = {}
  app.dependency_overrides[getattr(__import__("routers.uploads", fromlist=["get_db"]), "get_db")] = lambda: mock_db

  # Mock the API call and response, do not send any data to the database
  with patch("routers.uploads.BlobServiceClient.from_connection_string", return_value=mock_blob_service_client):
    response = client.get(f"/api/uploads/file/{mock_file_record.file_name}")
  assert response.status_code == 200
  assert response.content == b"filedata"
  assert response.headers["content-disposition"].startswith("attachment; filename=")

@pytest.mark.asyncio
async def test_download_file_not_owner_not_admin(client, mock_db, mock_user, mock_file_record, monkeypatch):
  async def fake_get_current_user(db, cookie):
    return mock_user
  monkeypatch.setattr("routers.uploads.get_current_user", fake_get_current_user)
  monkeypatch.setattr("routers.uploads.get_admin_role_id", AsyncMock(return_value=999))
  mock_file_record.created_by = 9999  # Not the same as user.id
  mock_db.query.return_value.filter.return_value.first.return_value = mock_file_record
  monkeypatch.setattr("routers.uploads.get_db", lambda: mock_db)
  response = client.get(f"/api/uploads/file/{mock_file_record.file_name}")
  assert response.status_code == 404

@pytest.mark.asyncio
async def test_upload_success(client, mock_db, mock_user, monkeypatch, mock_blob_service_client):
  async def fake_get_current_user(db, cookie):
    return mock_user
  monkeypatch.setattr("routers.uploads.get_current_user", fake_get_current_user)
  monkeypatch.setattr("routers.uploads.get_db", lambda: mock_db)
  mock_db.add = MagicMock()
  mock_db.flush = MagicMock()
  mock_db.commit = MagicMock()
  mock_db.refresh = MagicMock()
  # Simulate model with id
  class FakeUploadModel:
    id = 123
    file_name = "test.txt"
    domain_name = "domain"
    table_name = "table"
    action_name = "action"
    justification = "justification"
    file_size = 4
    file_url = ""
  fake_model = FakeUploadModel()
  mock_db.add.side_effect = lambda x: setattr(x, "id", 123)
  mock_db.flush.side_effect = lambda: None
  mock_db.refresh.side_effect = lambda x: None
  monkeypatch.setattr("routers.uploads.Files_uploaded", lambda **kwargs: fake_model)
  data = {
    "domain_name": "domain",
    "table_name": "table",
    "action_name": "action",
    "justification": "justification"
  }
  files = {"file": ("test.txt", b"data")}
  response = client.post("/api/uploads/", data=data, files=files)
  assert response.status_code == 200
  assert response.json()["status"] == "success"
  assert response.json()["data"]["file_name"].startswith("test")

@pytest.mark.asyncio
async def test_upload_exception(client, mock_db, mock_user, monkeypatch):
  async def fake_get_current_user(db, cookie):
    return mock_user
  monkeypatch.setattr("routers.uploads.get_current_user", fake_get_current_user)
  monkeypatch.setattr("routers.uploads.get_db", lambda: mock_db)
  monkeypatch.setattr("routers.uploads.Files_uploaded", lambda **kwargs: (_ for _ in ()).throw(Exception("fail")))
  data = {
    "domain_name": "domain",
    "table_name": "table",
    "action_name": "action",
    "justification": "justification"
  }
  files = {"file": ("test.txt", b"data")}
  response = client.post("/api/uploads/", data=data, files=files)
  assert response.status_code == 500
  assert "fail" in response.json()["detail"]