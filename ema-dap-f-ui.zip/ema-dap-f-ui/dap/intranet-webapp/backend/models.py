from database import Base
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime, Text

class Roles(Base):
    __tablename__ = 'roles'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255))
    description = Column(String(255))
    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    # created_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    # updated_by = Column(Integer, ForeignKey('landing.userinfo.id'))

class UserInfo(Base):
    __tablename__ = 'userinfo'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    first_name = Column(String(255))
    last_name = Column(String(255))
    email = Column(String(255))
    status = Column(Boolean)
    role_id = Column(Integer, ForeignKey('landing.roles.id'))
    status = Column(String(255), default='active')
    logged_in = Column(Boolean, default=False)  # Added logged_in column
    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    last_login = Column(DateTime, nullable=True)
    last_active = Column(DateTime, nullable=True)
    # created_by = Column(Integer, ForeignKey('landing.userinfo.id'), nullable=True)
    # updated_by = Column(Integer, ForeignKey('landing.userinfo.id'), nullable=True)
    
class Announcements(Base):
    __tablename__ = 'announcements'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    title = Column(Text)
    text = Column(Text)
    url = Column(String(255), nullable=True)
    order_index = Column(Integer)
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    status = Column(String(255))
    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    updated_by = Column(Integer, ForeignKey('landing.userinfo.id'))

class Modules(Base):
    __tablename__ = 'modules'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    label = Column(String(255))
    icon_name = Column(String(255))
    tooltip_text = Column(String(255))
    default_visible = Column(Boolean)
    url = Column(String(255))
    order_index = Column(Integer)
    editable = Column(Boolean, default=True)
    confirmation_step = Column(Boolean)
    confirmation_text = Column(Text)
    status = Column(String(255), default='active')
    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    updated_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    
class Modules_tags(Base):
    __tablename__ = 'modules_tags'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    label = Column(String(255))
    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    updated_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    
class Modules_modules_tags(Base):
    __tablename__ = 'modules_modules_tags'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    module_id = Column(Integer, ForeignKey('landing.modules.id'))
    tag_id = Column(Integer, ForeignKey('landing.modules_tags.id'))
    created_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    
class Roles_access(Base):
    __tablename__ = 'roles_access'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    role_id = Column(Integer, ForeignKey('landing.roles.id'))
    module_id = Column(Integer, ForeignKey('landing.modules.id'))
    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    updated_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    
class Files_uploaded(Base):
    __tablename__ = 'files_uploaded'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    file_name = Column(String(255))
    file_size = Column(String(255))
    domain_name = Column(String(255))
    table_name = Column(String(255))
    action_name = Column(String(255))
    justification = Column(Text)
    created_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    
class Requests(Base):
    __tablename__ = 'requests'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    module_id = Column(Integer, ForeignKey('landing.modules.id'))
    purpose = Column(String(255))
    justification = Column(Text)
    status = Column(String(255))
    created_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    action_at = Column(DateTime, nullable=True)
    action_by = Column(Integer, ForeignKey('landing.userinfo.id'), nullable=True)
    
class Request_files(Base):
    __tablename__ = 'request_files'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    request_id = Column(Integer, ForeignKey('landing.requests.id'))
    file_id = Column(Integer, ForeignKey('landing.files_uploaded.id'))
    created_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))

class Module_access(Base):
    __tablename__ = 'module_access'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    module_id = Column(Integer, ForeignKey('landing.modules.id'))
    request_id = Column(Integer, ForeignKey('landing.requests.id'))
    user_id = Column(Integer, ForeignKey('landing.userinfo.id'))
    granted_at = Column(DateTime)
    granted_by = Column(Integer, ForeignKey('landing.userinfo.id'))

class Dashboards_categories(Base):
    __tablename__ = 'dashboards_categories'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255))
    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    updated_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    
class Dashboards(Base):
    __tablename__ = 'dashboards'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255))
    description = Column(Text)
    notes = Column(Text)
    version = Column(String(10))
    url = Column(String(255))
    order_index = Column(Integer)
    status = Column(String(255), default='active')
    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    updated_by = Column(Integer, ForeignKey('landing.userinfo.id'))

class Dashboards_dashboards_categories(Base):
    __tablename__ = 'dashboards_dashboards_categories'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    dashboard_id = Column(Integer, ForeignKey('landing.dashboards.id'))
    category_id = Column(Integer, ForeignKey('landing.dashboards_categories.id'))
    created_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))

class Dashboards_starred(Base):
    __tablename__ = 'dashboards_starred'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('landing.userinfo.id'))
    dashboard_id = Column(Integer, ForeignKey('landing.dashboards.id'))
    created_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    
class Quickactions(Base):
    __tablename__ = 'quickactions'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    label = Column(String(255))
    url = Column(String(255))
    module_id = Column(Integer, ForeignKey('landing.modules.id'), nullable=True)
    item_id = Column(Integer, nullable=True)
    user_id = Column(Integer, ForeignKey('landing.userinfo.id'))
    order_index = Column(Integer)
    created_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    
class Notifications(Base):
    __tablename__ = 'notifications'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    message_queue_id = Column(String(255), nullable=True)
    classification = Column(Text)
    inserted_at = Column(DateTime)
    admin_only = Column(Boolean, default=False)
    targeted_user_id = Column(Integer, ForeignKey('landing.userinfo.id'), nullable=True)
    targeted_role_id = Column(Integer, ForeignKey('landing.roles.id'), nullable=True)

class Notifications_info(Base):
    __tablename__ = 'notifications_info'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    notification_id = Column(Integer, ForeignKey('landing.notifications.id'))
    error_log_id = Column(String(255), nullable=True)
    error_code = Column(String(255), nullable=True)
    zip_file_name = Column(String(255), nullable=True)
    source_file_name = Column(String(255), nullable=True)
    data_module = Column(String(255), nullable=True)
    job_name = Column(String(255), nullable=True)
    error_datetime = Column(DateTime, nullable=True)
    classification = Column(Text)
    create_datetime = Column(DateTime)
    details = Column(Text, nullable=True)
    request_id = Column(Integer, ForeignKey('landing.requests.id'), nullable=True)
    
class Notifications_viewed(Base):
    __tablename__ = 'notifications_viewed'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('landing.userinfo.id'))
    notification_id = Column(Integer, ForeignKey('landing.notifications.id'))
    created_at = Column(DateTime)
    
class Tables(Base):
    __tablename__ = 'tables'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    label = Column(String(255))
    icon_name = Column(String(255))
    tooltip_text = Column(String(255))
    default_visible = Column(Boolean)
    order_index = Column(Integer)
    status = Column(String(255), default='active')
    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    updated_by = Column(Integer, ForeignKey('landing.userinfo.id'))  
    
class Tables_access(Base):
    __tablename__ = 'tables_access'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    role_id = Column(Integer, ForeignKey('landing.roles.id'))
    table_id = Column(Integer, ForeignKey('landing.tables.id'))
    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey('landing.userinfo.id'))
    updated_by = Column(Integer, ForeignKey('landing.userinfo.id'))

class Audit_logs(Base):
    __tablename__ = 'audit_logs'
    __table_args__ = {'schema': 'landing'}

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String(255), nullable=True)
    action = Column(String(255), nullable=True)
    table_name = Column(String(255), nullable=True)
    record_id = Column(Integer, nullable=True)
    created_at = Column(DateTime)
