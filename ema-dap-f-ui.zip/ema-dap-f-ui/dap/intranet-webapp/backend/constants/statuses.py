statusPublished = "published"
statusDraft = "draft"
statusExpired = "expired"

statusInactive = "inactive"
statusActive = "active"

statusNeedAttention = 'Need Attention'
statusWarning = 'Warning'
statusInfo = 'Information'

statusPending = "Pending"
statusApproved = "Approved"
statusRejected = "Rejected"

actionApprove = "approve"
actionReject = "reject"

