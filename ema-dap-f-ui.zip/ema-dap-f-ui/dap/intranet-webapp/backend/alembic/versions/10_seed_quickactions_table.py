"""
Revision ID: 10_seed_quickactions_table
Revises: 09_seed_dashboards_starred_table
Create Date: 2024-06-10 13:00:00.000000
"""
revision = '10_seed_quickactions_table'
down_revision = '09_seed_dashboards_starred_table'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa

def upgrade():
    # Insert sample data into dashboards_starred table
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    
    conn.execute(sa.text("""
        INSERT INTO landing.quickactions (label, url, module_id, item_id, user_id, order_index, created_at, created_by)
        VALUES
            ('Quickaction 1', 'http://example.com/1', NULL, NULL, (SELECT id FROM landing.userinfo WHERE email='a@daplanding.com'), 1, GETDATE(), :user_id),
            ('Solar Energy Performance', 'http://example.com/1', (SELECT id FROM landing.modules WHERE label='Dashboards'), (SELECT id FROM landing.dashboards WHERE title='Solar Energy Performance'), (SELECT id FROM landing.userinfo WHERE email='a@daplanding.com'), 2, GETDATE(), :user_id),
            ('Analytical Insights', 'http://example.com/3', (SELECT id FROM landing.modules WHERE label='Dashboards'), (SELECT id FROM landing.dashboards WHERE title='Analytical Insights'), (SELECT id FROM landing.userinfo WHERE email='b@daplanding.com'), 1, GETDATE(), :user_id);
    """), {"user_id": system_user_id})

def downgrade():
    # Remove the sample data
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    conn.execute(
        sa.text("DELETE FROM landing.modules_modules_tags WHERE created_by = :user_id"),
        {"user_id": system_user_id}
    )
