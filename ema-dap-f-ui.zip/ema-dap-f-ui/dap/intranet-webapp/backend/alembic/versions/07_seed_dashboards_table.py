"""
Revision ID: 07_seed_dashboards_table
Revises: 06_seed_dashboards_categories
Create Date: 2024-06-10 12:55:00.000000
"""
revision = '07_seed_dashboards_table'
down_revision = '06_seed_dashboards_categories'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa

def upgrade():
    # Insert sample data into dashboards table
    
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    
    conn.execute(sa.text("""
        INSERT INTO landing.dashboards (title, description, version, url, order_index, status, created_at, updated_at, created_by, updated_by)
        VALUES
            ('Solar Energy Performance', 'This dashboard provides a detailed overview of the performance metrics for solar and wind energy generation within our renewable energy portfolio. It highlights key indicators such as total energy generated, the contribution of renewable sources to the overall energy mix, and the environmental impact in terms of carbon emissions saved. ', '1.1', 'https://example.com', 1, 'active', GETDATE(), GETDATE(), :user_id, :user_id),
            ('Analytical Insights', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sagittis nulla et bibendum interdum. Mauris pharetra efficitur dui, nec sollicitudin quam sodales non. Cras ultricies, ipsum vitae varius viverra, nibh lectus tincidunt sapien, eu gravida tortor magna eget eros. ', '1.2', 'https://example.com', 2, 'active', GETDATE(), GETDATE(), :user_id, :user_id),
            ('Dashboard X', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sagittis nulla et bibendum interdum. Mauris pharetra efficitur dui, nec sollicitudin quam sodales non. Cras ultricies, ipsum vitae varius viverra, nibh lectus tincidunt sapien, eu gravida tortor magna eget eros. ', '1.3', 'https://example.com', 3, 'active', GETDATE(), GETDATE(), :user_id, :user_id);
    """), {"user_id": system_user_id})

def downgrade():
    # Remove the sample data
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    conn.execute(
        sa.text("DELETE FROM landing.modules_modules_tags WHERE created_by = :user_id"),
        {"user_id": system_user_id}
    )