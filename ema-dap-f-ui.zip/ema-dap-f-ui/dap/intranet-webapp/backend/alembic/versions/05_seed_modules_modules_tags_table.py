"""
Revision ID: 05_seed_modules_m_tags_table
Revises: 04_seed_modules_tags_table
Create Date: 2024-06-10 12:45:00.000000
"""
revision = '05_seed_modules_m_tags_table'
down_revision = '04_seed_modules_tags_table'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa

def upgrade():
    # Insert sample data into modules_tags table
    
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    
    conn.execute(sa.text("""
        INSERT INTO landing.modules_modules_tags (module_id, tag_id, created_at, created_by)
        VALUES
            ((SELECT id FROM landing.modules WHERE label='Power BI'), (SELECT id FROM landing.modules_tags WHERE label='ML Ops'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Power BI'), (SELECT id FROM landing.modules_tags WHERE label='Data'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Power BI'), (SELECT id FROM landing.modules_tags WHERE label='Tools'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='ML Ops Dashboards'), (SELECT id FROM landing.modules_tags WHERE label='ML Ops'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='ML Ops Dashboards'), (SELECT id FROM landing.modules_tags WHERE label='Tools'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Data Catalog'), (SELECT id FROM landing.modules_tags WHERE label='Data'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Data Catalog'), (SELECT id FROM landing.modules_tags WHERE label='Tools'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Analytical Insights'), (SELECT id FROM landing.modules_tags WHERE label='Tools'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Manual Upload'), (SELECT id FROM landing.modules_tags WHERE label='Admin'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Synthetic Data Generation'), (SELECT id FROM landing.modules_tags WHERE label='ML Ops'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Synthetic Data Generation'), (SELECT id FROM landing.modules_tags WHERE label='AI'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Dashboards'), (SELECT id FROM landing.modules_tags WHERE label='Tools'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Azure'), (SELECT id FROM landing.modules_tags WHERE label='ML Ops'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Azure'), (SELECT id FROM landing.modules_tags WHERE label='Admin'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Azure'), (SELECT id FROM landing.modules_tags WHERE label='Tools'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='GenAI Platform'), (SELECT id FROM landing.modules_tags WHERE label='AI'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Public Datasets'), (SELECT id FROM landing.modules_tags WHERE label='Data'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Support'), (SELECT id FROM landing.modules_tags WHERE label='Admin'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Workflows'), (SELECT id FROM landing.modules_tags WHERE label='ML Ops'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Workflows'), (SELECT id FROM landing.modules_tags WHERE label='Admin'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Workflows'), (SELECT id FROM landing.modules_tags WHERE label='Tools'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='Requests'), (SELECT id FROM landing.modules_tags WHERE label='Admin'), GETDATE(), :user_id),
            ((SELECT id FROM landing.modules WHERE label='User Management'), (SELECT id FROM landing.modules_tags WHERE label='Admin'), GETDATE(), :user_id)
    """), {"user_id": system_user_id})

def downgrade():
    # Remove the sample data
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    conn.execute(
        sa.text("DELETE FROM landing.modules_modules_tags WHERE created_by = :user_id"),
        {"user_id": system_user_id}
    )
