"""
Revision ID: 02_seed_userinfo_table
Revises: seed_roles_table
Create Date: 2024-06-10 12:00:00.000000
"""
revision = '02_seed_userinfo_table'
down_revision = '01_seed_roles_table'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa

def upgrade():
    # Insert sample data into userinfo table
    # Insert only if the email does not already exist
    op.execute("""
        INSERT INTO landing.userinfo (
            first_name, last_name, email, status, 
            role_id, 
            created_at, updated_at, 
            last_login, last_active, logged_in
            )
        VALUES 
            ('System', '', 'system@daplanding.com', 'active', 
                (SELECT id FROM landing.roles WHERE name='Admin'), 
                GETDATE(), GETDATE(), null, null, 0),
            ('Alicia', 'Adams', 'a@daplanding.com', 'active', 
                (SELECT id FROM landing.roles WHERE name='Admin'), 
                GETDATE(), GETDATE(), null, null, 0),
            ('Billy', 'Barnes', 'b@daplanding.com', 'active', 
                (SELECT id FROM landing.roles WHERE name='StandardUser'), 
                GETDATE(), GETDATE(), null, null, 0),
            ('Cheryl', 'Chan', 'c@daplanding.com', 'active', 
                (SELECT id FROM landing.roles WHERE name='PBIUser'), 
                GETDATE(), GETDATE(), null, null, 0),
            ('Daniel', 'Davies', 'd@daplanding.com', 'active', 
                (SELECT id FROM landing.roles WHERE name='Admin'), 
                GETDATE(), GETDATE(), null, null, 0);
    """)

def downgrade():
    # Remove the sample data
    op.execute("""
        DELETE FROM landing.userinfo WHERE email IN (
            'a@daplanding.com',
            'b@daplanding.com',
            'c@daplanding.com',
            'd@daplanding.com'
        );
    """)
