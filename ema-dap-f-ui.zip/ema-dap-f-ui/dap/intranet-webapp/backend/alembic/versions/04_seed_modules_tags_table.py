"""
Revision ID: 04_seed_modules_tags_table
Revises: 03_seed_modules_table
Create Date: 2024-06-10 12:40:00.000000
"""
revision = '04_seed_modules_tags_table'
down_revision = '03_seed_modules_table'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa

def upgrade():
    # Insert sample data into tags table
    
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    
    conn.execute(sa.text("""
        INSERT INTO landing.modules_tags (label, created_at, updated_at, created_by, updated_by)
        VALUES
            ('ML Ops', GETDATE(), GETDATE(), :user_id, :user_id),
            ('Data', GETDATE(), GETDATE(), :user_id, :user_id),
            ('Admin', GETDATE(), GETDATE(), :user_id, :user_id),
            ('AI', GETDATE(), GETDATE(), :user_id, :user_id),
            ('Tools', GETDATE(), GETDATE(), :user_id, :user_id)
    """), {"user_id": system_user_id})

def downgrade():
    # Remove the sample data
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    conn.execute(
        sa.text("DELETE FROM landing.modules_modules_tags WHERE created_by = :user_id"),
        {"user_id": system_user_id}
    )
