"""
Revision ID: 13_seed_announcement_table
Revises: 12_seed_roles_access_table
Create Date: 2024-06-10 12:30:00.000000
"""
revision = '13_seed_announcement_table'
down_revision = '12_seed_roles_access_table'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa

def upgrade():
    # Insert sample data into roles_access table
    
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    
    conn.execute(
        sa.text("""
            INSERT INTO landing.announcements (
                title, text, url, order_index, start_date, end_date, status,
                created_at, updated_at, created_by, updated_by
            ) VALUES
                ('Welcome to the New Platform!',
                 'We are excited to announce the launch of our new platform! Explore the new features and enhancements designed to improve your experience.',
                 NULL, 1, 
                 DATEADD(month, -2, GETDATE()), 
                 DATEADD(month, -1, GETDATE()), 
                 'published', GETDATE(), GETDATE(), :user_id, :user_id),
                ('New Features Released',
                 'Check out the latest features we have added to enhance your data analytics experience. From improved dashboards to advanced reporting tools, weve got you covered!',
                 NULL, 2, 
                 DATEADD(month, -2, GETDATE()), 
                 DATEADD(month, -1, GETDATE()), 
                 'published', GETDATE(), GETDATE(), :user_id, :user_id),
                ('<p>DAP 1.0 is Live!</p>',
                 '<p>DAP 1.0 is Live! Be sure to take your orientation training to understand whats new.</p>',
                 NULL, 3, 
                 DATEADD(month, -1, GETDATE()), 
                 DATEADD(month, +1, GETDATE()), 
                 'published', GETDATE(), GETDATE(), :user_id, :user_id),
                ('Enhanced Data Security Measures Implemented',
                 'Your data security is our top priority. We have implemented advanced security measures to protect your sensitive information. Learn more about our commitment to data privacy.',
                 NULL, 4, 
                 DATEADD(month, -1, GETDATE()), 
                 DATEADD(month, +1, GETDATE()), 
                 'published', GETDATE(), GETDATE(), :user_id, :user_id),
                ('New Integration',
                 'Were thrilled to announce new integrations with popular data sources like Google Analytics, Salesforce, and more! Connect your data seamlessly and gain comprehensive insights.',
                 NULL, 5, 
                 DATEADD(month, -1, GETDATE()), 
                 DATEADD(month, +1, GETDATE()), 
                 'published', GETDATE(), GETDATE(), :user_id, :user_id),
                ('Join Our Upcoming Webinar on Data Visualization',
                 'Dont miss our upcoming webinar where our experts will share best practices for effective data visualization. Register now to enhance your skills and make your data tell a story!',
                 'https://example.com', 6, 
                 DATEADD(month, -1, GETDATE()), 
                 DATEADD(month, +1, GETDATE()), 
                 'published', GETDATE(), GETDATE(), :user_id, :user_id),
                ('Performance Improvements Now Live',
                 'Weve made significant performance improvements to our platform! Enjoy faster loading times and smoother navigation as you analyze your data.',
                 'string', 7,
                 DATEADD(month, -1, GETDATE()),
                 DATEADD(month, +1, GETDATE()), 
                 'published', GETDATE(), GETDATE(), :user_id, :user_id),
                ('New Training Resources Available',
                 'We are excited to offer new training resources, including tutorials and guides, to help you maximize your use of our platform. Check them out in our resource center!',
                 NULL, 8, 
                 DATEADD(month, -2, GETDATE()), 
                 DATEADD(month, -1, GETDATE()), 
                 'published', GETDATE(), GETDATE(), :user_id, :user_id),
                ('Customer Feedback Implementation',
                 'Thank you for your feedback! Weve implemented several user-requested features to improve your experience. Explore the updates and let us know what you think!',
                 NULL, 9, 
                 DATEADD(month, -2, GETDATE()), 
                 DATEADD(month, -1, GETDATE()), 
                 'published', GETDATE(), GETDATE(), :user_id, :user_id),
                ('Celebrate Our Anniversary with Us!',
                 'Join us in celebrating our anniversary! Enjoy special promotions and events throughout the month as a thank you for being part of our community. Stay tuned for more details!',
                 NULL, 10, 
                 DATEADD(month, -1, GETDATE()), 
                 DATEADD(month, +1, GETDATE()), 
                 'published', GETDATE(), GETDATE(), :user_id, :user_id),
                ('New Community Forum for Users',
                 'Connect with fellow users in our newly launched community forum! Share insights, ask questions, and collaborate on best practices to enhance your data analytics journey.',
                 'https://example.com', 11, 
                 DATEADD(month, -1, GETDATE()), 
                 DATEADD(month, +1, GETDATE()), 
                 'draft', GETDATE(), GETDATE(), :user_id, :user_id),
                ('Monthly Data Challenge – Win Exciting Prizes!',
                 'Participate in our monthly data challenge and showcase your analytics skills! Compete for exciting prizes and gain recognition within our community. Join us now!',
                 'https://example.com', 12, 
                 DATEADD(month, -2, GETDATE()), 
                 DATEADD(month, -1, GETDATE()), 
                 'draft', GETDATE(), GETDATE(), :user_id, :user_id),
                ('Exclusive Partnership with Industry Leaders',
                 'We are thrilled to announce our exclusive partnership with industry leaders in data analytics! This collaboration will bring you cutting-edge tools and resources to elevate your analytics capabilities.',
                 NULL, 13, 
                 DATEADD(month, -1, GETDATE()), 
                 DATEADD(month, +1, GETDATE()), 
                 'published', GETDATE(), GETDATE(), :user_id, :user_id),
                ('<p>What is due from you</p>',
                 '<p>Remember to fill up form by today</p><p><a target="_blank" rel="noopener noreferrer nofollow" href="https://gms.ey.net/ui/home">click here</a></p>',
                 'string', 14, 
                 DATEADD(month, -1, GETDATE()), 
                 DATEADD(month, +1, GETDATE()), 
                 'published', GETDATE(), GETDATE(), :user_id, :user_id),
                ('<p>test2</p>',
                 '<p><a target="_blank" rel="noopener noreferrer nofollow" href="https://google.com">test link</a></p>',
                 'string', 15, 
                 DATEADD(month, -2, GETDATE()), 
                 DATEADD(month, -1, GETDATE()), 
                 'published', GETDATE(), GETDATE(), :user_id, :user_id)
        """),
        {"user_id": system_user_id}
    )

def downgrade():
    # Remove the sample data
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    conn.execute(
        sa.text("DELETE FROM landing.modules_modules_tags WHERE created_by = :user_id"),
        {"user_id": system_user_id}
    )
