"""
Revision ID: 03_seed_modules_table
Revises: 02_seed_userinfo_table
Create Date: 2024-06-10 12:20:00.000000
"""
revision = '03_seed_modules_table'
down_revision = '02_seed_userinfo_table'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa

def upgrade():
    # Insert sample data into modules table
    # Fetch the user id for 'System'
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()

    # Insert sample data into modules table using the fetched user id
    conn.execute(sa.text("""
        INSERT INTO landing.modules (label, icon_name, tooltip_text, url, default_visible, order_index, editable, confirmation_step, confirmation_text, status, created_at, updated_at, created_by, updated_by)
        VALUES
            ('Power BI', 'tools', 'Power BI', 'https://example.com', 1, 1, 1, 1, 'Lorem ipsum dolor sit amet', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :user_id, :user_id),
            ('ML Ops Dashboards', 'circleWithX', 'ML Ops Dashboards', 'https://example.com', 1, 2, 1, 0, '', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :user_id, :user_id),
            ('Data Catalog', 'dataStack', 'Data Catalog', 'https://example.com', 1, 3, 1, 0, '', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :user_id, :user_id),
            ('Analytical Insights', 'treeH', 'Analytical Insights', 'https://example.com', 1, 4, 1, 0, '', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :user_id, :user_id),
            ('Manual Upload', 'upload', 'Manual Upload', 'https://example.com', 0, 5, 0, 0, '', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :user_id, :user_id),
            ('Synthetic Data Generation', 'lineChart', 'Synthetic Data Generation', 'https://example.com', 1, 6, 1, 0, '', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :user_id, :user_id),
            ('Dashboards', 'dashboard', 'Dashboards', 'https://example.com', 1, 7, 0, 0, '', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :user_id, :user_id),
            ('Azure', 'tools', 'Azure', 'https://example.com', 1, 8, 1, 0, '', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :user_id, :user_id),
            ('GenAI Platform', 'monitor', 'GenAI Platform', 'https://example.com', 1, 9, 1, 0, '', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :user_id, :user_id),
            ('Public Datasets', 'dataStack', 'Public Datasets', 'https://example.com', 1, 10, 1, 0, '', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :user_id, :user_id),
            ('Support', 'headset', 'Support', 'https://example.com', 1, 11, 1, 0, '', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :user_id, :user_id),
            ('Workflows', 'workflow', 'Workflows', 'https://example.com', 1, 12, 1, 0, '', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :user_id, :user_id),
            ('Requests', 'edit', 'Requests', 'https://example.com', 0, 13, 0, 0, '', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :user_id, :user_id),
            ('User Management', 'userManagement', 'User Management', 'https://example.com', 0, 14, 0, 0, '', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :user_id, :user_id);
    """), {"user_id": system_user_id})

def downgrade():
    # Remove the sample data
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    conn.execute(
        sa.text("DELETE FROM landing.modules_modules_tags WHERE created_by = :user_id"),
        {"user_id": system_user_id}
    )
