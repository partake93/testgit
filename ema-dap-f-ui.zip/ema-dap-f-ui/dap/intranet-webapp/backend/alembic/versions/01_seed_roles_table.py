"""
Revision ID: 01_seed_roles_table
Revises: 
Create Date: 2024-06-10 12:10:00.000000
"""
revision = '01_seed_roles_table'
down_revision = None
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa

def upgrade():
    # Insert sample data into roles table
    op.execute("""
        INSERT INTO landing.roles (name, description, created_at, updated_at)
        VALUES
            ('Admin', 'Administrator role', GETDATE(), GETDATE()),
            ('DefaultUser', 'Default user role', GETDATE(), GETDATE()),
            ('StandardUser', 'Standard user role', GETDATE(), GETDATE()),
            ('PBIUser', 'Power BI user role', GETDATE(), GETDATE());
    """)

def downgrade():
    # Remove the sample data
    op.execute("""
        DELETE FROM landing.roles WHERE name IN (
            'Admin',
            'User',
            'PBIUser'
        );
    """)
