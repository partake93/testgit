"""
Revision ID: 09_seed_dashboards_starred_table
Revises: 08_seed_dashboards_db_category
Create Date: 2024-06-10 13:00:00.000000
"""
revision = '09_seed_dashboards_starred_table'
down_revision = '08_seed_dashboards_db_category'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa

def upgrade():
    # Insert sample data into dashboards_starred table
    
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    
    conn.execute(sa.text("""
        INSERT INTO landing.dashboards_starred (user_id, dashboard_id, created_at, created_by)
        VALUES
            ((SELECT id FROM landing.userinfo WHERE email='a@daplanding.com'), (SELECT id FROM landing.dashboards WHERE title='Solar Energy Performance'), GETDATE(), :user_id),
            ((SELECT id FROM landing.userinfo WHERE email='a@daplanding.com'), (SELECT id FROM landing.dashboards WHERE title='Solar Energy Performance'), GETDATE(), :user_id),
            ((SELECT id FROM landing.userinfo WHERE email='b@daplanding.com'), (SELECT id FROM landing.dashboards WHERE title='Analytical Insights'), GETDATE(), :user_id);
    """), {"user_id": system_user_id})

def downgrade():
    # Remove the sample data
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    conn.execute(
        sa.text("DELETE FROM landing.modules_modules_tags WHERE created_by = :user_id"),
        {"user_id": system_user_id}
    )
