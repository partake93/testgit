"""
Revision ID: 06_seed_dashboards_categories
Revises: 05_seed_modules_m_tags_table
Create Date: 2024-06-10 13:05:00.000000
"""
revision = '06_seed_dashboards_categories'
down_revision = '05_seed_modules_m_tags_table'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa

def upgrade():
    # Seed dashboards_categories table
    
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    
    conn.execute(sa.text("""
        INSERT INTO landing.dashboards_categories (name, created_at, updated_at, created_by, updated_by)
        VALUES
            ('Energy Consumption', GETDATE(), GETDATE(), :user_id, :user_id),
            ('Energy Production', GETDATE(), GETDATE(), :user_id, :user_id),
            ('Grid Management', GETDATE(), GETDATE(), :user_id, :user_id),
            ('Market Analysis', GETDATE(), GETDATE(), :user_id, :user_id),
            ('Renewable Energy', GETDATE(), GETDATE(), :user_id, :user_id),
            ('Sustainable Initiatives', GETDATE(), GETDATE(), :user_id, :user_id);
    """), {"user_id": system_user_id})

def downgrade():
    # Remove the sample data
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    conn.execute(
        sa.text("DELETE FROM landing.modules_modules_tags WHERE created_by = :user_id"),
        {"user_id": system_user_id}
    )