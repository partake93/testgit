"""
Revision ID: 12_seed_roles_access_table
Revises: 10_seed_quickactions_table
Create Date: 2024-06-10 12:30:00.000000
"""
revision = '12_seed_roles_access_table'
down_revision = '10_seed_quickactions_table'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa

def upgrade():
    # Insert sample data into roles_access table
    
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    
    conn.execute(sa.text("""
        INSERT INTO landing.roles_access (role_id, module_id, created_at, updated_at, created_by, updated_by)
        VALUES
            ((SELECT id FROM landing.roles WHERE name='StandardUser'), (SELECT id FROM landing.modules WHERE label='ML Ops Dashboards'), GETDATE(), GETDATE(), :user_id, :user_id), 
            ((SELECT id FROM landing.roles WHERE name='StandardUser'), (SELECT id FROM landing.modules WHERE label='Data Catalog'), GETDATE(), GETDATE(), :user_id, :user_id),
            ((SELECT id FROM landing.roles WHERE name='StandardUser'), (SELECT id FROM landing.modules WHERE label='Analytical Insights'), GETDATE(), GETDATE(), :user_id, :user_id),
            ((SELECT id FROM landing.roles WHERE name='StandardUser'), (SELECT id FROM landing.modules WHERE label='Synthetic Data Generation'), GETDATE(), GETDATE(), :user_id, :user_id),
            ((SELECT id FROM landing.roles WHERE name='StandardUser'), (SELECT id FROM landing.modules WHERE label='Azure'), GETDATE(), GETDATE(), :user_id, :user_id),
            ((SELECT id FROM landing.roles WHERE name='StandardUser'), (SELECT id FROM landing.modules WHERE label='Public Datasets'), GETDATE(), GETDATE(), :user_id, :user_id),
            ((SELECT id FROM landing.roles WHERE name='PBIUser'), (SELECT id FROM landing.modules WHERE label='Power BI'), GETDATE(), GETDATE(), :user_id, :user_id);
    """), {"user_id": system_user_id})

def downgrade():
    # Remove the sample data
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    conn.execute(
        sa.text("DELETE FROM landing.modules_modules_tags WHERE created_by = :user_id"),
        {"user_id": system_user_id}
    )