"""
Revision ID: 08_seed_dashboards_db_category
Revises: 07_seed_dashboards_table
Create Date: 2024-06-10 13:05:00.000000
"""
revision = '08_seed_dashboards_db_category'
down_revision = '07_seed_dashboards_table'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa

def upgrade():
    
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    
    conn.execute(sa.text("""
            INSERT INTO landing.dashboards_dashboards_categories (dashboard_id, category_id, created_at, created_by)
            VALUES
                ((SELECT id FROM landing.dashboards WHERE title='Solar Energy Performance'), (SELECT id FROM landing.dashboards_categories WHERE name='Energy Consumption'), GETDATE(), :user_id),
                ((SELECT id FROM landing.dashboards WHERE title='Solar Energy Performance'), (SELECT id FROM landing.dashboards_categories WHERE name='Energy Production'), GETDATE(), :user_id),
                ((SELECT id FROM landing.dashboards WHERE title='Analytical Insights'), (SELECT id FROM landing.dashboards_categories WHERE name='Energy Production'), GETDATE(), :user_id),
                ((SELECT id FROM landing.dashboards WHERE title='Analytical Insights'), (SELECT id FROM landing.dashboards_categories WHERE name='Grid Management'), GETDATE(), :user_id),
                ((SELECT id FROM landing.dashboards WHERE title='Analytical Insights'), (SELECT id FROM landing.dashboards_categories WHERE name='Market Analysis'), GETDATE(), :user_id),
                ((SELECT id FROM landing.dashboards WHERE title='Dashboard X'), (SELECT id FROM landing.dashboards_categories WHERE name='Energy Consumption'), GETDATE(), :user_id),
                ((SELECT id FROM landing.dashboards WHERE title='Dashboard X'), (SELECT id FROM landing.dashboards_categories WHERE name='Energy Production'), GETDATE(), :user_id),
                ((SELECT id FROM landing.dashboards WHERE title='Dashboard X'), (SELECT id FROM landing.dashboards_categories WHERE name='Renewable Energy'), GETDATE(), :user_id);
    """), {"user_id": system_user_id})

def downgrade():
    conn = op.get_bind()
    result = conn.execute(
        sa.text("SELECT id FROM landing.userinfo WHERE first_name='System'")
    )
    system_user_id = result.scalar()
    conn.execute(
        sa.text("DELETE FROM landing.modules_modules_tags WHERE created_by = :user_id"),
        {"user_id": system_user_id}
    )
   