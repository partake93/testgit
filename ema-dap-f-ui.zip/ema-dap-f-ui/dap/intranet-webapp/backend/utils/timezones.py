from pytz import timezone

def tz_aware(dt, tz):
    if dt is not None and dt.tzinfo is None:
        return dt.replace(tzinfo=tz)
    return dt
  
sg_tz = timezone("Asia/Singapore")