from datetime import datetime
from typing import Annotated, Optional

from fastapi import Depends, HTTPException
from pytz import timezone
from sqlalchemy.orm import Session

from database import get_db
from models import Audit_logs

db_dependency = Annotated[Session, Depends(get_db)]

def create_audit_log(
  db: db_dependency, 
  user_id: Optional[int] = None, 
  action: Optional[str] = None,
  table_name: Optional[str] = None,
  record_id: Optional[int] = None
):
  try:
    audit_log = Audit_logs(
        user_id=user_id,
        action=action,
        table_name=table_name,
        record_id=record_id,
        created_at=datetime.now(timezone("Asia/Singapore"))
    )
    db.add(audit_log)
    if not getattr(db, "is_unit_test", None) in [None, False]:
      db.commit()
  except Exception as e:
    db.rollback()
    raise HTTPException(
        status_code=500,
        detail=f"Failed to create audit log: {str(e)}"
    )