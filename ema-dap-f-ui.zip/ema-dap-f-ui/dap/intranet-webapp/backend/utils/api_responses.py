from fastapi import Response
from fastapi import Request
import time
from typing import Callable
from constants.api_responses import (
    api_status_key,
    api_message_key,
    api_detail_key,
    api_status_error
)

def error_response(message: str, status_code: int = 503, detail: str = ""):
  return Response(
    content=(
        '{'
        f'"{api_status_key}": "{api_status_error}",'
        f'"{api_message_key}": "{message}",'
        f'"{api_detail_key}": "{detail}"'
        '}'
    ),
    status_code=status_code,
    media_type="application/json"
  )
  
async def unauthorised_response():
  return error_response(
    message="Unauthorized to perform this action",
    status_code=403
  )
  
# Simple in-memory rate limiter (per IP)
rate_limit_store = {}

import functools
import inspect

def rate_limiter(max_requests: int = 10, period: int = 60) -> Callable:
  """
  Rate limiter decorator.

  Args:
      max_requests (int): Maximum allowed requests in the period.
      period (int): Time window in seconds.

  Returns:
      Callable: Decorator for FastAPI endpoints.
  """
  def decorator(func):
    sig = inspect.signature(func)

    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
      bound = sig.bind(*args, **kwargs)
      bound.apply_defaults()
      request = bound.arguments.get("request")
      if request is None:
        raise ValueError("Request parameter is required for rate limiting.")
      ip = request.client.host
      now = time.time()
      window = rate_limit_store.get(ip, [])
      # Remove timestamps outside the window
      window = [ts for ts in window if now - ts < period]
      if len(window) >= max_requests:
        return error_response(
          message="Rate limit exceeded",
          status_code=429,
          detail=f"Max {max_requests} requests per {period} seconds"
        )
      window.append(now)
      rate_limit_store[ip] = window
      return await func(*args, **kwargs)
    return wrapper
  return decorator