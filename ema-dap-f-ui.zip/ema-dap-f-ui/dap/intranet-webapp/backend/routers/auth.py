import os
import inspect
from datetime import datetime

from typing import Annotated

from dotenv import load_dotenv
from itsdangerous import URLSafeSerializer
from pydantic import BaseModel
from pytz import timezone
from starlette.responses import Response as StarletteResponse

from fastapi import (
  APIRouter,
  Cookie,
  Depends,
  HTTPException,
  Request,
  Response,
)

from sqlalchemy.orm import Session

# from apscheduler.schedulers.background import BackgroundScheduler
# from apscheduler.triggers.cron import CronTrigger

from database import get_db, SessionLocal
from models import UserInfo, Roles, Notifications, Notifications_info

from constants.api_responses import (
  api_status_key,
  api_message_key,
  api_status_success,
  api_status_error,
)
from constants.auth import (
  auth_cookie_name,
)
from constants.statuses import (
  statusInactive,
  statusActive,
  statusNeedAttention
)
from constants.response_messages import (
    invalid_credentials,
    invalid_user,
    logged_out_success,
    user_info_fetch_success
)
from utils.api_responses import error_response, rate_limiter
from utils.audit_logs import create_audit_log

load_dotenv()

COOKIE_SECRET_KEY=os.getenv("COOKIE_SECRET_KEY", "default_secret_key")
COOKIE_MAX_AGE_SECONDS = int(os.getenv("COOKIE_MAX_AGE_SECONDS", 1800)) 
COOKIE_HTTP_ONLY = os.getenv("COOKIE_HTTP_ONLY", "true").lower() == "true"
MAX_INACTIVE_SECONDS = int(os.getenv("MAX_INACTIVE_SECONDS", ))
TRIGGER_BY_SECONDS = int(os.getenv("TRIGGER_BY_SECONDS", 0))
ALERT_INACTIVE_SECONDS = int(os.getenv("ALERT_INACTIVE_SECONDS", 90))

serializer = URLSafeSerializer(COOKIE_SECRET_KEY)
db_dependency = Annotated[Session, Depends(get_db)]

router = APIRouter(
  prefix='/api/auth',
  tags=['auth']
)

def non_dap_user():
  user = UserInfo(
    email="nondapuser",
    first_name="Non-DAP",
    last_name="User",
    role_id=2,
    status=statusActive
  )
  return user

def authenticate_user(
  db: db_dependency, 
  email: str
):
  userinfo = db.query(UserInfo).filter(UserInfo.email == email).first()
  if userinfo and userinfo.email == email and userinfo.status == statusActive:
    return userinfo
  return non_dap_user()

class LoginRequest(BaseModel):
  email: str

@router.post("/login")
async def login_and_set_cookie(
  response: Response,
  payload: LoginRequest,
  db: db_dependency
):
  user = authenticate_user(db, payload.email)
  if not user:
    return error_response(
      message=invalid_credentials,
      status_code=401
    )
  
  encrypted_value = serializer.dumps(user.email)
  response.set_cookie(
    key=auth_cookie_name, 
    value=encrypted_value,
    httponly=COOKIE_HTTP_ONLY,
    samesite="none",  
    secure=True,
    max_age=COOKIE_MAX_AGE_SECONDS
  )
  
  user.last_login = datetime.now(timezone("Asia/Singapore"))
  db.commit()
  
  return {
    api_status_key: api_status_success,
    api_message_key: "Logged in successfully"
  }
  
async def get_current_user(
  db: db_dependency,
  site_cookie: str = Cookie(None),
):
  err_response = error_response(
    message=invalid_user,
    status_code=401
  )
 
  if site_cookie is None:
    return err_response
  
  try:
    email = serializer.loads(site_cookie)
  except Exception:
    return err_response
  
  user = authenticate_user(db, email)
  if not user:
    return err_response
  return user  

@router.post("/logout")
async def logout_and_delete_cookie(
  db: db_dependency,
  request: Request,
  response: Response
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  user.logged_in = False
  create_audit_log(
    db=db,
    user_id=user.email,
    action="logout"
  )
  db.commit()
  
  response.delete_cookie(key=auth_cookie_name)
  
  return {
    api_status_key: api_status_success,
    api_message_key: logged_out_success
  } 

async def get_admin_role_id(db: Session):
  admin_role = db.query(Roles).filter(Roles.name == 'Admin').first() 
  return admin_role.id if admin_role else None

async def get_nondap_role_id(db: Session):
  nondap_role = db.query(Roles).filter(Roles.name == 'DefaultUser').first() 
  return nondap_role.id if nondap_role else None

@router.get("/user_info")
async def get_user_info(
  db: db_dependency,
  site_cookie: str = Cookie(None),
  response: Response = None
):
  user = await get_current_user(db, site_cookie)
  
  if isinstance(user, Response):
    return user
  
  encrypted_value = serializer.dumps(user.email)
  response.set_cookie(
    key=auth_cookie_name, 
    value=encrypted_value,
    httponly=COOKIE_HTTP_ONLY,
    samesite="none",  # or "lax" if on same site
    secure=True,
    max_age=COOKIE_MAX_AGE_SECONDS
  )
  
  admin_role_id = await get_admin_role_id(db)
  nondap_role_id = await get_nondap_role_id(db)
  
  if user.email != "nondapuser":
    user.last_active = datetime.now(timezone("Asia/Singapore"))
    db.commit()
  
  return {
    api_status_key: api_status_success,
    api_message_key: user_info_fetch_success,
    "data": {
      "email": user.email,
      "first_name": user.first_name,
      "last_name": user.last_name,
      "is_admin": user.role_id == admin_role_id,
      "is_dap_user": user.role_id != nondap_role_id,
    }
  }

# @router.get("/active_all_users")
# async def active_all_users(
#   db: db_dependency
# ):
#   try:
#     users = db.query(UserInfo).all()
#     for u in users:
#       u.status = 'active'
#     db.commit()
#     return {
#       api_status_key: api_status_success,
#       api_message_key: "All users activated successfully"
#     }
#   except Exception as e:
#     db.rollback()
#     return error_response(
#       message=f"Error activating all users: {e}",
#       status_code=500
#     )

@router.get("/users_inactivity_check")
@rate_limiter(max_requests=5, period=60)
async def inactivate_user(
  request: Request,
  db: db_dependency,
):
  if request:
    auth_header = request.headers.get('Authorization')
    scheduler_api_key = os.getenv("SCHEDULER_API_KEY")
    if not auth_header or not auth_header.startswith('Bearer '):
      return error_response(
        message=invalid_credentials,
        status_code=401
      )
    token = auth_header.split('Bearer ')[1]
    if token != scheduler_api_key:
      return error_response(
        message=invalid_credentials,
        status_code=401
      )
   
  try:
    users = db.query(UserInfo).all()
    now = datetime.now(timezone("Asia/Singapore"))
    users_deactivated = 0
    users_alerted = 0
    for u in users:
      if u.status != statusInactive:
        # Ensure last_login and created_at are timezone-aware
        last_login = u.last_login
        created_at = u.created_at
        if last_login and last_login.tzinfo is None:
          last_login = last_login.replace(tzinfo=timezone("Asia/Singapore"))
        if created_at and created_at.tzinfo is None:
          created_at = created_at.replace(tzinfo=timezone("Asia/Singapore"))
          
        # Inactivate if last_login is over 90 days ago
        if (last_login and (now - last_login).total_seconds() > MAX_INACTIVE_SECONDS):
          u.status = statusInactive
          users_deactivated += 1
          print(f"Inactivating user: {u.email}, last login {last_login}, more than {round(MAX_INACTIVE_SECONDS / (60 * 60 * 24))} days ago")
        if (last_login is None and created_at and (now - created_at).total_seconds() > MAX_INACTIVE_SECONDS):
          u.status = statusInactive
          users_deactivated += 1
          print(f"Inactivating user: {u.email}, created at {created_at}, more than {round(MAX_INACTIVE_SECONDS / (60 * 60 * 24))} days ago")
          
        if ((last_login and (now - last_login).total_seconds() > ALERT_INACTIVE_SECONDS) or (last_login is None and created_at and (now - created_at).total_seconds() > ALERT_INACTIVE_SECONDS)):
          user_notification = Notifications(
            classification=statusNeedAttention,
            inserted_at=now,
            targeted_user_id=u.id
          )
          db.add(user_notification)
          db.flush()
          days_inactive = round((now - (last_login if last_login else created_at)).total_seconds() / (60 * 60 * 24))
          user_notification_info = Notifications_info(
            notification_id=user_notification.id,
            job_name="Account Inactivity Alert",
            classification=statusNeedAttention,
            details=f"You have been inactive for more than {days_inactive} days.",
            create_datetime=now,
          ) 
          db.add(user_notification_info)
          users_alerted += 1
          print("Alerting user: ", u.email, " for inactivity of ", days_inactive, " days")
    db.commit()
  except Exception as e:
    db.rollback()
    return error_response(
      message=f"Error inactivating users: {e}",
      status_code=500
    )
  
  return {
    api_status_key: api_status_success,
    api_message_key: "User inactivity check completed",
    "data": {
      "users_deactivated": users_deactivated,
      "users_alerted": users_alerted
    }
  }
  
  
@router.get("/cookie_expiry_check")
@rate_limiter(max_requests=5, period=60)
async def cookie_expiry_check(
  request: Request,
  db: db_dependency,
):
  if request:
    auth_header = request.headers.get('Authorization')
    scheduler_api_key = os.getenv("SCHEDULER_API_KEY")
    if not auth_header or not auth_header.startswith('Bearer '):
      return error_response(
        message=invalid_credentials,
        status_code=401
      )
    token = auth_header.split('Bearer ')[1]
    if token != scheduler_api_key:
      return error_response(
        message=invalid_credentials,
        status_code=401
      )
      
  try:
    users = db.query(UserInfo).all()
    now = datetime.now(timezone("Asia/Singapore"))
    
    for u in users:
      if u.status != statusInactive and u.logged_in:
        # Ensure last_active is timezone-aware
        last_active = u.last_active
        # Always convert last_active to Asia/Singapore timezone
        if last_active:
          if last_active.tzinfo is None:
            # Assume naive datetimes are in Asia/Singapore
            last_active = timezone("Asia/Singapore").localize(last_active)
          else:
            # Convert any other timezone to Asia/Singapore
            last_active = last_active.astimezone(timezone("Asia/Singapore"))
          
        # Check if cookie has expired
        if last_active and (now - last_active).total_seconds() > COOKIE_MAX_AGE_SECONDS:
          u.logged_in = False
          
          create_audit_log(
            db=db,
            user_id=u.email,
            action="cookie expired",
          )
    db.commit()
    
    return {
      api_status_key: api_status_success,
      api_message_key: "Cookie expiry check completed",
    }
  except Exception as e:
    db.rollback()
    return error_response(
      message=f"Error checking cookie expiry: {e}",
      status_code=500
    )

# scheduler = BackgroundScheduler(daemon=True)

# if TRIGGER_BY_SECONDS > 0:
#   scheduler.add_job(
#     inactivate_user,
#     trigger='interval',
#     seconds=TRIGGER_BY_SECONDS,
#     timezone=timezone("Asia/Singapore")
#   )

# scheduler.add_job(
#   inactivate_user,
#   'cron',
#   hour=0,
#   minute=0,
#   timezone=timezone("Asia/Singapore")
# )
# scheduler.start()

# import atexit

# @atexit.register
# def shutdown():
#     scheduler.shutdown()
