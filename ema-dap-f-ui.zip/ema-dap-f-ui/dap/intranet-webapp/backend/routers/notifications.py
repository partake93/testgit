import asyncio
from datetime import datetime
from typing import Annotated, List

from fastapi import APIRouter, Depends, HTTPException, Path, Request, Response
from pydantic import BaseModel, Field
from pytz import timezone
from sqlalchemy import text
from sqlalchemy.orm import Session
from starlette import status
from starlette.responses import Response as StarletteResponse

from constants.api_responses import (
  api_status_key,
  api_message_key,
  api_data_key,
  api_status_success,
  api_total_pages_key,
  api_current_page_key,
  api_total_count_key
)
from constants.auth import auth_cookie_name
from constants.response_messages import (
  notifications_fetch_success,
  notifications_fetch_error,
  notifications_hard_top_5_fetch_success,
  notification_not_found,
  notification_already_viewed,
  notification_mark_viewed_success,
  notifications_mark_viewed_error,
  notification_content_fetch_success,
  notification_content_fetch_error
)
from constants.statuses import (
  statusNeedAttention,
  statusWarning,
  statusInfo
)
from database import get_db
from models import Notifications, Notifications_viewed, Notifications_info
from utils.api_responses import error_response, unauthorised_response
from .auth import get_current_user, get_admin_role_id

router = APIRouter(
  prefix='/api/notifications',
  tags=['notifications']
)

delay = 0
itemsPerPage = 10

db_dependency = Annotated[Session, Depends(get_db)]

@router.get("/", status_code=status.HTTP_200_OK)
async def read_all(
  db: db_dependency, 
  request: Request, 
  page: int = 1,
  classification: str = None,
  startdate: str = None,
  enddate: str = None,
  search: str = None
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  try:
    page = int(page)
    offset = (page - 1) * itemsPerPage
    notifications_query = db.query(Notifications).order_by(Notifications.inserted_at.desc())
    if classification:
      notifications_query = notifications_query.filter(Notifications.classification == classification)
    if startdate:
      notifications_query = notifications_query.filter(Notifications.inserted_at >= startdate)
    if enddate:
      notifications_query = notifications_query.filter(Notifications.inserted_at <= enddate)
    if search:
      # Search in Notifications_info fields and also in ALERTS.ERROR_LIST.ERROR_DESC
      # First, find notification_ids where search matches Notifications_info fields
      matching_info_ids = [
        info.notification_id
        for info in db.query(Notifications_info)
        .filter(
          (Notifications_info.error_code.ilike(f"%{search}%")) |
          (Notifications_info.zip_file_name.ilike(f"%{search}%")) |
          (Notifications_info.source_file_name.ilike(f"%{search}%")) |
          (Notifications_info.data_module.ilike(f"%{search}%")) |
          (Notifications_info.job_name.ilike(f"%{search}%")) |
          (Notifications_info.details.ilike(f"%{search}%"))
        )
        .all()
      ]

      # Now, find notification_ids where search matches ALERTS.ERROR_LIST.ERROR_DESC
      error_desc_query = db.execute(
        text("""
          SELECT DISTINCT ni.notification_id
          FROM landing.notifications_info ni
          JOIN ALERTS.ERROR_LIST el ON ni.error_code = el.ERROR_CODE
          WHERE LOWER(el.ERROR_DESC) LIKE :search
        """),
        {"search": f"%{search.lower()}%"}
      )
      matching_error_desc_ids = [row[0] for row in error_desc_query.fetchall()]

      # Combine all matching notification ids
      all_matching_ids = set(matching_info_ids) | set(matching_error_desc_ids)
      if all_matching_ids:
        notifications_query = notifications_query.filter(Notifications.id.in_(all_matching_ids))
      else:
        # If nothing matches, return empty result
        notifications_query = notifications_query.filter(False)

    admin_role_id = await get_admin_role_id(db)
    if user.role_id != admin_role_id:
      notifications_query = notifications_query.filter(
        (Notifications.admin_only == False) | (Notifications.admin_only.is_(None))
      )
      
    notifications_query = notifications_query.filter(
      (Notifications.targeted_user_id == None) | (Notifications.targeted_user_id == user.id)
    )
      
    notifications = notifications_query.offset(offset).limit(itemsPerPage).all()
    viewed_notification_ids = {
      n.notification_id for n in db.query(Notifications_viewed)
      .filter(Notifications_viewed.user_id == user.id)
      .all()
    }
    notifications_list = []
    for notification in notifications:
      is_viewed = notification.id in viewed_notification_ids
      
      notification_dict = {}
      notification_dict['id'] = notification.id
      notification_dict['inserted_at'] = notification.inserted_at.isoformat() if notification.inserted_at else None 
      notification_dict['classification'] = notification.classification
      notification_dict['is_viewed'] = is_viewed
      notification_dict['details'] = None
      
      if notification.classification == statusNeedAttention or notification.classification == statusInfo:
        info = db.query(Notifications_info).filter(Notifications_info.notification_id == notification.id).first()
        notification_dict['error_log_id'] = info.error_log_id if info and hasattr(info, 'error_log_id') else None
        notification_dict['zip_file_name'] = info.zip_file_name if info and hasattr(info, 'zip_file_name') else None
        notification_dict['source_file_name'] = info.source_file_name if info and hasattr(info, 'source_file_name') else None
        notification_dict['data_module'] = info.data_module if info and hasattr(info, 'data_module') else None
        notification_dict['error_code'] = info.error_code if info and hasattr(info, 'error_code') else None
        notification_dict['details'] = info.details if info and hasattr(info, 'details') else None
        notification_dict['request_id'] = info.request_id if info and hasattr(info, 'request_id') else None
        
        # Get error_desc from ALERTS.ERROR_LIST where info.error_code = ALERTS.ERROR_LIST.ERROR_CODE
        error_desc = None
        if info and hasattr(info, 'error_code') and info.error_code:
          error_list_row = db.execute(
            text("SELECT ERROR_DESC FROM ALERTS.ERROR_LIST WHERE ERROR_CODE = :error_code"),
            {"error_code": info.error_code}
          ).fetchone()
          if error_list_row:
            error_desc = error_list_row[0]
        notification_dict['error_desc'] = error_desc
        
      if notification.classification == statusWarning:
        infos = db.query(Notifications_info).filter(Notifications_info.notification_id == notification.id).all()
        notification_dict['zip_file_name'] = infos[0].zip_file_name if infos and hasattr(infos[0], 'zip_file_name') else None
        notification_dict['source_file_name'] = infos[0].source_file_name if infos and hasattr(infos[0], 'source_file_name') else None
        notification_dict['data_module'] = infos[0].data_module if infos and hasattr(infos[0], 'data_module') else None
        
        notification_dict['items'] = []
        for item in infos:
          error_desc = None
          if item and hasattr(item, 'error_code') and item.error_code:
            error_list_row = db.execute(
              text("SELECT ERROR_DESC FROM ALERTS.ERROR_LIST WHERE ERROR_CODE = :error_code"),
              {"error_code": item.error_code}
            ).fetchone()
            if error_list_row:
              error_desc = error_list_row[0]
          item_dict = {
            'error_log_id': item.error_log_id if hasattr(item, 'error_log_id') else None,
            'inserted_at': item.create_datetime.isoformat() if item.create_datetime else None,
            'classification': item.classification,
            'zip_file_name': item.zip_file_name if hasattr(item, 'zip_file_name') else None,
            'source_file_name': item.source_file_name if hasattr(item, 'source_file_name') else None,
            'data_module': item.data_module if hasattr(item, 'data_module') else None,
            'error_code': item.error_code if hasattr(item, 'error_code') else None,
            'error_desc': error_desc
          }
          notification_dict['items'].append(item_dict)
      
      notifications_list.append(notification_dict)
      
    notifications = notifications_list
    # Calculate total_count and total_pages before applying offset/limit
    total_count = notifications_query.order_by(None).count()
    total_pages = (total_count + itemsPerPage - 1) // itemsPerPage
    return {
      api_status_key: api_status_success,
      api_message_key: notifications_fetch_success,
      api_data_key: notifications,
      api_total_count_key: total_count,
      api_total_pages_key: total_pages
    }
  except Exception as e:
    return error_response(
      status_code=500,
      message=notifications_fetch_error,
      detail=str(e)
    )
  
@router.get("/header", status_code=status.HTTP_200_OK)
async def read_for_header(
  db: db_dependency, 
  request: Request
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  try:
    admin_role_id = await get_admin_role_id(db)
    notifications_query = db.query(Notifications).filter(Notifications.classification == statusNeedAttention)

    if user.role_id != admin_role_id:
      notifications_query = notifications_query.filter(
        (Notifications.admin_only == False) | (Notifications.admin_only.is_(None))
      )

    notifications = (
      notifications_query
      .order_by(Notifications.inserted_at.desc())
      .limit(100)
      .all()
    )
    viewed_notification_ids = {
      n.notification_id for n in db.query(Notifications_viewed)
      .filter(Notifications_viewed.user_id == user.id)
      .all()
    }
    notifications_list = []
    count = 0
    for notification in notifications:
      is_viewed = notification.id in viewed_notification_ids
      if not is_viewed:
        notification_dict = {}
        notification_dict['is_viewed'] = is_viewed
        notifications_list.append(notification_dict)
        
        info = db.query(Notifications_info).filter(Notifications_info.notification_id == notification.id).first()
        notification_dict['error_code'] = info.error_code if info and hasattr(info, 'error_code') else None
        notification_dict['source_file_name'] = info.source_file_name if info and hasattr(info, 'source_file_name') else None
        notification_dict['details'] = info.details if info and hasattr(info, 'details') else None
        
        count += 1
      if count >= 5:
        break
    return {
      api_status_key: api_status_success,
      api_message_key: notifications_hard_top_5_fetch_success,
      api_data_key: {
        "notifications": notifications_list
      }
    }
  except Exception as e:
    return error_response(
      status_code=500,
      message=notifications_fetch_error,
      detail=str(e)
    )
    
class MarkAsViewedRequest(BaseModel):
  notification_id: int

@router.post("/viewed", status_code=status.HTTP_200_OK)
async def mark_as_viewed(
  db: db_dependency, 
  request: Request,
  body: MarkAsViewedRequest
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response

  await asyncio.sleep(delay)
  try:
    notification = db.query(Notifications).filter(Notifications.id == body.notification_id).first()
    if not notification:
      return error_response(
        status_code=404,
        message=notification_not_found,
        error=f"Notification with ID {body.notification_id} does not exist"
      )
    # Check if already marked as viewed
    already_viewed = db.query(Notifications_viewed).filter(
      Notifications_viewed.user_id == user.id,
      Notifications_viewed.notification_id == body.notification_id
    ).first()
    if already_viewed:
      return {
        api_status_key: api_status_success,
        api_message_key: notification_already_viewed,
        api_data_key: {}
      }
    viewed_notification = Notifications_viewed(
      user_id=user.id,
      notification_id=body.notification_id,
      created_at=datetime.now(timezone("Asia/Singapore"))
    )
    db.add(viewed_notification)
    db.commit()
    return {
      api_status_key: api_status_success,
      api_message_key: notification_mark_viewed_success,
      api_data_key: {}
    }
  except Exception as e:
    return error_response(
      status_code=500,
      message=notifications_mark_viewed_error,
      detail=str(e)
    )
    
@router.get("/{error_log_id}", status_code=status.HTTP_200_OK)
async def read_notification(
  db: db_dependency, 
  request: Request, 
  error_log_id: str
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response

  sample_html = None
  try:
    result = db.execute(
      text("SELECT ERROR_REF_DETAILS FROM ALERTS.ALERTS_ERROR_LOGS WHERE ERROR_LOG_ID = :error_log_id"),
      {"error_log_id": error_log_id}
    ).fetchone()
    if result:
      sample_html = result[0]
    else:
      sample_html = ""
  except Exception as e:
    sample_html = f"{notification_content_fetch_error}: {str(e)}"

  return {
    api_status_key: api_status_success,
    api_message_key: notification_content_fetch_success,
    api_data_key: {
      "notification": {
        "error_log_id": error_log_id,
        "content": sample_html
      }
    }
  } 
