import asyncio
from datetime import datetime
from typing import Annotated, List

from fastapi import APIRouter, Depends, HTTPException, Path, Request, Response
from pydantic import BaseModel, Field
from pytz import timezone
from sqlalchemy.orm import Session
from starlette import status
from starlette.responses import Response as StarletteResponse

from database import get_db
from models import Announcements, UserInfo
from .auth import get_current_user, get_admin_role_id
from constants.api_responses import (
  api_status_key,
  api_message_key,
  api_data_key,
  api_status_success,
  api_total_pages_key,
  api_current_page_key,
  api_total_count_key,
)
from constants.response_messages import (
  announcements_fetch_success,
  announcements_fetch_error,
  announcements_published_fetch_success,
  announcement_single_fetch_success,
  announcement_single_not_found,
  announcement_more_than_8_error,
  announcement_create_success,
  announcement_create_error,
  announcement_update_success,
  announcement_update_error,
  announcement_delete_success,
  announcement_delete_error,
  announcement_sort_success,
  announcement_sort_error,
)
from constants.statuses import (
  statusPublished,
  statusDraft, 
  statusExpired,
)
from constants.auth import auth_cookie_name
from utils.api_responses import error_response, unauthorised_response
from utils.timezones import tz_aware, sg_tz
from utils.audit_logs import create_audit_log

router = APIRouter(
  prefix='/api/announcements',
  tags=['announcements']
)

delay = 0
itemsPerPage = 10

db_dependency = Annotated[Session, Depends(get_db)]

class AnnouncementsRequest(BaseModel):
    title: str | None = Field(default=None, min_length=0)
    text: str = Field(min_length=3)
    url: str | None = Field(default=None, min_length=0)
    start_date: datetime 
    end_date: datetime 
    status: str = Field(
        ...,
        pattern=f"^({statusExpired}|{statusDraft}|{statusPublished})$"
    )

@router.get("/", status_code=status.HTTP_200_OK)
async def read_all(
  db: db_dependency, 
  request: Request, 
  page: int = 1
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  
  await asyncio.sleep(delay)
  try:
    offset = (page - 1) * itemsPerPage
    now = datetime.now(sg_tz)
    
    from sqlalchemy import case

    # Custom ordering using CASE for SQL Server compatibility
    announcements = db.query(Announcements).order_by(
        case(
            (
                (Announcements.status == statusPublished) & (Announcements.end_date != None) & (Announcements.end_date > now), 0
            ),
            (
                (Announcements.status == statusDraft), 1
            ),
            (
                (Announcements.status == statusPublished) & (Announcements.end_date != None) & (Announcements.end_date <= now), 2
            ),
            else_=3
        ),
        Announcements.order_index
    ).offset(offset).limit(itemsPerPage).all()

    result = []
    for announcement in announcements:
      end_date = tz_aware(announcement.end_date, sg_tz) if announcement.end_date else None
      if (
          (end_date is not None and end_date < now)
          and announcement.status == statusPublished
      ):
        announcement.status = statusExpired
      user_info = db.query(UserInfo).filter(UserInfo.id == announcement.updated_by).first()
      first_name = user_info.first_name if user_info else None
      last_name = user_info.last_name if user_info else None
      announcement.first_name = first_name
      announcement.last_name = last_name
      result.append(announcement)
    total_count = db.query(Announcements).count()
    total_pages = (total_count + itemsPerPage - 1) // itemsPerPage

    return {
        api_status_key: api_status_success,
        api_message_key: announcements_fetch_success,
        api_data_key: result,
        api_total_count_key: total_count,
        api_total_pages_key: total_pages,
        api_current_page_key: page
    }
  except Exception as e:
    return error_response(
      message=announcements_fetch_error,
      status_code=503,
      detail=str(e)
    )
  
@router.get("/published", status_code=status.HTTP_200_OK)
async def read_published(
  db: db_dependency,
  request: Request, 
):
  
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  
  await asyncio.sleep(delay)
  now = datetime.now(timezone("Asia/Singapore"))
  try:
    announcements = db.query(Announcements).filter(
      Announcements.status == statusPublished,
      Announcements.start_date <= now,
      (Announcements.end_date == None) | (Announcements.end_date >= now)
    ).all()
  except Exception as e:
    return error_response(
      message=announcements_fetch_error,
      status_code=503,
      detail=str(e)
    )
  return {
    api_status_key: api_status_success,
    api_message_key: announcements_published_fetch_success,
    api_data_key: [
      {
        "id": str(announcement.id),
        "title": announcement.title,
        "text": announcement.text,
        "url": announcement.url,
        "order_index": announcement.order_index,
        "start_date": announcement.start_date,
        "end_date": announcement.end_date
      } for announcement in announcements
    ]
  }

@router.get("/{announcement_id}", status_code=status.HTTP_200_OK)
async def read_announcement(
  announcement_id: str, 
  request: Request, 
  db: db_dependency
):
  
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  
  await asyncio.sleep(delay)
  announcements_model = db.query(Announcements).filter(Announcements.id == announcement_id).first()
  if announcements_model is None:
    return error_response(
      message=announcement_single_not_found,
      status_code=404
    )
  now = datetime.now(timezone("Asia/Singapore"))
  end_date = tz_aware(announcements_model.end_date, sg_tz) if announcements_model.end_date else None
  if announcements_model.status == statusPublished and end_date is not None and end_date < now:
    announcements_model.status = statusExpired
  return {
    api_status_key: api_status_success,
    api_message_key: announcement_single_fetch_success,
    api_data_key: announcements_model
  }
  
  
@router.post("/add", status_code=status.HTTP_200_OK)
async def create_announcement(
  db: db_dependency, 
  request: Request, 
  announcements_request: AnnouncementsRequest
):
  
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  
  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()
  
  now = datetime.now(timezone("Asia/Singapore"))
  announcements_model = Announcements(**announcements_request.model_dump())
  
  max_order_index = db.query(Announcements.order_index).order_by(Announcements.order_index.desc()).first()
  announcements_model.order_index = (max_order_index[0] + 1) if max_order_index and max_order_index[0] is not None else 1
  
  published_count = db.query(Announcements).filter(
    Announcements.status == statusPublished,
    (Announcements.end_date != None) & (Announcements.end_date >= now)
  ).count()
  if announcements_model.status == statusPublished and published_count >= 8:
    return error_response(
      message=announcement_more_than_8_error,
      status_code=400
    )
  announcements_model.created_at = now
  announcements_model.updated_at = now
  announcements_model.created_by = user.id
  announcements_model.updated_by = user.id
  
  try:
    
    create_audit_log(
        db=db,
        user_id=user.email,
        action="add",
        table_name="announcements",
    )
    
    db.add(announcements_model)
    db.commit()
  except Exception as e:
    db.rollback()
    return error_response(
      message=announcement_create_error,
      status_code=503,
      detail=str(e)
    )

  db.refresh(announcements_model)
  return {
    api_status_key: api_status_success,
    api_message_key: announcement_create_success,
    api_data_key: announcements_model.__dict__
  }

@router.post("/{announcement_id}/edit", status_code=status.HTTP_200_OK)
async def update_announcement(
  db: db_dependency,
  request: Request,
  announcements_request: AnnouncementsRequest, 
  announcement_id: str
):
  
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  
  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()
  
  announcements_model = db.query(Announcements).filter(Announcements.id == announcement_id).first()
  if announcements_model is None:
    return error_response(
      message=announcement_single_not_found,
      status_code=404
    )
    
  now = datetime.now(timezone("Asia/Singapore"))
  
  if(announcements_request.status == statusPublished and announcements_model.status != statusPublished):  
    published_count = db.query(Announcements).filter(
      Announcements.status == statusPublished,
      (Announcements.end_date != None) & (Announcements.end_date >= now)
    ).count()
    if published_count >= 8:
      return error_response(
        message=announcement_more_than_8_error,
        status_code=400
      )
      
  announcements_model.title = announcements_request.title
  announcements_model.text = announcements_request.text
  announcements_model.url = announcements_request.url
  announcements_model.start_date = announcements_request.start_date
  announcements_model.end_date = announcements_request.end_date
  announcements_model.status = announcements_request.status
  announcements_model.updated_at = now
  announcements_model.updated_by = user.id
  
  try:
    
    create_audit_log(
      db=db,
      user_id=user.email,
      action="edit",
      table_name="announcements",
    )
     
    db.add(announcements_model)
    db.commit()
  except Exception as e:
    db.rollback()
    return error_response(
      message=announcement_update_error,
      status_code=503,
      detail=str(e)
    )

  db.refresh(announcements_model)
  return {
    api_status_key: api_status_success,
    api_message_key: announcement_update_success,
    api_data_key: announcements_model.__dict__
  }
    
@router.post("/{announcement_id}/delete", status_code=status.HTTP_200_OK)
async def delete_announcement(
  db: db_dependency, 
  request: Request, 
  announcement_id: str
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  
  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()

  announcements_model = db.query(Announcements).filter(Announcements.id == announcement_id).first()
  
  if announcements_model is None:
    return error_response(
      message=announcement_single_not_found,
      status_code=404
    )
    
  try:  
    
    create_audit_log(
      db=db,
      user_id=user.email,
      action="delete",
      table_name="announcements",
    )
    
    db.query(Announcements).filter(Announcements.id == announcement_id).delete()
    db.commit()
    return {
      api_status_key: api_status_success,
      api_message_key: announcement_delete_success
    }
  except Exception as e:
    db.rollback()
    return error_response(
      message=announcement_delete_error,
      status_code=503,
      detail=str(e)
    )

class AnnouncementSortUpdate(BaseModel):
  announcement_id: int
  newIndex: int

class AnnouncementSortRequest(BaseModel):
  updates: List[AnnouncementSortUpdate] = Field(..., min_items=2, max_items=2)

@router.post("/sort", status_code=status.HTTP_200_OK)
async def sort_announcements(
  db: db_dependency,
  request: Request, 
  announcements_request: AnnouncementSortRequest
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response

  await asyncio.sleep(delay)

  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
      return await unauthorised_response()
  
  try:
    for update in announcements_request.updates:
      db.query(Announcements).filter(Announcements.id == update.announcement_id).update({
        "order_index": update.newIndex,
        "updated_by": user.id,
        "updated_at": datetime.now(timezone("Asia/Singapore"))
      })
    db.commit()
    
    create_audit_log(
      db=db,
      user_id=user.email,
      action="sort",
      table_name="announcements",
    )
    
    return {
      api_status_key: api_status_success,
      api_message_key: announcement_sort_success
    }
  except Exception as e:
    db.rollback()
    return error_response(
      message=announcement_sort_error,
      status_code=503,
      detail=str(e)
    )