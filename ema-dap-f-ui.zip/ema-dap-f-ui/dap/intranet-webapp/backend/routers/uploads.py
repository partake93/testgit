import os
import asyncio
import tempfile
from datetime import datetime
from typing import Annotated

from fastapi import (
  APIRouter,
  Depends,
  File,
  Form,
  HTTPException,
  Path,
  Request,
  Response,
  UploadFile,
)
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from starlette import status
from starlette.responses import Response as StarletteResponse

from pytz import timezone

from azure.storage.blob import BlobServiceClient

from database import get_db
from models import Files_uploaded
from .auth import get_current_user, get_admin_role_id
from constants.api_responses import (
  api_status_key,
  api_message_key,
  api_data_key,
  api_status_success,
)
from constants.auth import auth_cookie_name
from constants.response_messages import (
  file_uploaded_success,
  file_upload_error,
  file_not_found,
)
from utils.api_responses import error_response

router = APIRouter(
  prefix='/api/uploads',
  tags=['uploads']
)

delay = 0

db_dependency = Annotated[Session, Depends(get_db)]

from fastapi import Form
from fastapi.responses import FileResponse

AZURE_STORAGE_ACCOUNT_NAME = os.getenv("AZURE_STORAGE_ACCOUNT_NAME")
AZURE_STORAGE_ACCOUNT_KEY = os.getenv("AZURE_STORAGE_ACCOUNT_KEY")
AZURE_STORAGE_CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME")

connect_str = (
  f"DefaultEndpointsProtocol=https;"
  f"AccountName={AZURE_STORAGE_ACCOUNT_NAME};"
  f"AccountKey={AZURE_STORAGE_ACCOUNT_KEY};"
  f"EndpointSuffix=core.windows.net"
)

class UploadResquest(BaseModel):
    domain_name: str
    table_name: str
    action_name: str
    justification: str

@router.get("/file/{filename}")
async def download_file(
  db: db_dependency,
  filename: str,
  request: Request,
):
  
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  if not filename:
    return error_response(
      status_code=404,
      message=file_not_found
    )

  # Check if the user is the owner or an admin
  file_record = db.query(Files_uploaded).filter(Files_uploaded.file_name == filename).first()
  if not file_record:
    return error_response(
      status_code=404,
      message=file_not_found
    )

  is_admin = user.role_id == await get_admin_role_id(db)
  if file_record.created_by != user.id and not is_admin:
    return error_response(
      status_code=404,
      message=file_not_found
    )

  blob_service_client = BlobServiceClient.from_connection_string(connect_str)
  container_client = blob_service_client.get_container_client(AZURE_STORAGE_CONTAINER_NAME)
  blob_client = container_client.get_blob_client(filename)

  try:
    download_stream = blob_client.download_blob()
    file_data = download_stream.readall()
  except Exception:
    return error_response(
      status_code=404,
      message=file_not_found
    )

  return Response(
    content=file_data,
    media_type='application/octet-stream',
    headers={"Content-Disposition": f"attachment; filename={filename}"}
  )

@router.post("/", status_code=status.HTTP_200_OK)
async def upload(
  db: db_dependency, 
  request: Request,
  domain_name: str = Form(...),
  table_name: str = Form(...),
  action_name: str = Form(...),
  justification: str = Form(...),
  file: UploadFile = File(...)
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response

  await asyncio.sleep(delay)
  now = datetime.now(timezone("Asia/Singapore"))
  
  try:
    
    # Temporarily save the file to get the database id, then rename the file to include the id
    file_content = await file.read() if hasattr(file, "read") and asyncio.iscoroutinefunction(file.read) else file.read()
    upload_files_model = Files_uploaded(
      file_name = file.filename,
      domain_name = domain_name,
      table_name = table_name,
      action_name = action_name,
      justification = justification,
      file_size = len(file_content),
      created_at = now,
      created_by = user.id,
    )
    db.add(upload_files_model)
    db.flush()
    
    # Append id to file name
    file_id = upload_files_model.id
    name, ext = os.path.splitext(file.filename)
    new_file_name = f"{name}_{file_id}{ext}"

    # Upload file to Azure Blob Storage instead of local directory

    blob_service_client = BlobServiceClient.from_connection_string(connect_str)
    container_client = blob_service_client.get_container_client(AZURE_STORAGE_CONTAINER_NAME)
    # try:
    #   await container_client.create_container()
    # except ResourceExistsError:
    #   pass

    blob_client = container_client.get_blob_client(new_file_name)
    blob_client.upload_blob(file_content, overwrite=True)

    upload_files_model.file_url = blob_client.url
    
    # The following code is not needed since you are uploading directly to Azure Blob Storage:
    # upload_dir = os.path.join(os.path.dirname(__file__), "../temp_uploads")
    # os.makedirs(upload_dir, exist_ok=True)
    # file_path = os.path.join(upload_dir, new_file_name)
    # file_content = await file.read()
    # with open(file_path, "wb") as f:
    #   f.write(file_content)

    # Update file_name in db
    upload_files_model.file_name = new_file_name
    db.commit()
    db.refresh(upload_files_model)
    
    return {
      api_status_key: api_status_success,
      api_message_key: file_uploaded_success,
      api_data_key: {
        "id": upload_files_model.id,
        "file_name": upload_files_model.file_name,
        "file_size": upload_files_model.file_size,
        "domain_name": upload_files_model.domain_name,
        "table_name": upload_files_model.table_name,
        "action_name": upload_files_model.action_name,
        "justification": upload_files_model.justification,
      }
    }
  except Exception as e:
    db.rollback()
    return error_response(
      status_code=500,
      message=file_upload_error,
      detail=str(e)
    )
    
