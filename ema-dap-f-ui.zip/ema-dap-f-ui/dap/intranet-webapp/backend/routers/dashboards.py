import asyncio
from datetime import datetime
from typing import Annotated, List

from fastapi import APIRouter, Depends, HTTPException, Path, Request, Response
from pydantic import BaseModel, Field
from pytz import timezone
from sqlalchemy import case
from sqlalchemy.orm import Session, aliased
from starlette import status
from starlette.responses import Response as StarletteResponse

from database import get_db
from models import (
  Dashboards,
  Dashboards_categories,
  Dashboards_dashboards_categories,
  Dashboards_starred,
  UserInfo,
  Quickactions,
  Modules,
)
from .auth import get_current_user, get_admin_role_id
from constants.api_responses import (
  api_status_key,
  api_message_key,
  api_data_key,
  api_status_success,
)
from constants.auth import auth_cookie_name
from constants.response_messages import (
  dashboards_fetch_success,
  dashboards_fetch_error,
  dashboards_module_not_found,
  dashboard_create_success,
  dashboard_create_error,
  dashboard_not_found,
  dashboard_unstar_success,
  dashboard_star_success,
  dashboard_star_fail,
  dashboard_sorted_success,
  dashboard_sorted_error,
  dashboard_categories_fetch_success,
  dashboard_categories_fetch_error,
  dashboard_fetch_success,
  dashboard_fetch_error,
  dashboard_update_success,
  dashboard_update_error,
  dashboard_delete_success,
  dashboard_delete_error
)
from utils.api_responses import error_response, unauthorised_response
from utils.audit_logs import create_audit_log

router = APIRouter(
  prefix='/api/dashboards',
  tags=['dashboards']
)

delay = 0
itemsPerPage = 10

db_dependency = Annotated[Session, Depends(get_db)]

class DashboardsRequest(BaseModel):
  title: str = Field(min_length=0)
  description: str = Field(min_length=0)
  notes: str = Field(min_length=0)
  version: str = Field(min_length=0)
  url: str = Field(min_length=0) 
  category_ids: List[int] = Field(default_factory=list)

@router.get("/", status_code=status.HTTP_200_OK)
async def read_all(
  db: db_dependency, 
  request: Request
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  try:
    Starred = aliased(Dashboards_starred)
    
    result = (
      db.query(
        Dashboards,
        case(
          (Starred.user_id != None, True),
          else_=False
        ).label("is_starred"),
      )
      .outerjoin(Starred, (Dashboards.id == Starred.dashboard_id) & (Starred.user_id == user.id))
      .all()
    )

    # Convert result to list of dicts with is_starred field
    dashboards_list = []
    for dashboard, is_starred in result:
      dashboard_dict = {k: v for k, v in dashboard.__dict__.items() if not k.startswith('_sa_instance_state')}
      dashboard_dict["is_starred"] = is_starred
      dashboards_list.append(dashboard_dict)
      
      user_info = db.query(UserInfo).filter(UserInfo.id == dashboard.updated_by).first()
      dashboard_dict["updated_by_first_name"] = user_info.first_name if user_info else None
      dashboard_dict["updated_by_last_name"] = user_info.last_name if user_info else None
      
      dashboard_categories = db.query(Dashboards_categories).join(
        Dashboards_dashboards_categories,
        Dashboards_dashboards_categories.category_id == Dashboards_categories.id
      ).filter(
        Dashboards_dashboards_categories.dashboard_id == dashboard.id
      ).all()
      dashboard_dict["categories"] = [{
        "id": category.id,
        "name": category.name
      } for category in dashboard_categories]

    return {
      api_status_key: api_status_success,
      api_message_key: dashboards_fetch_success,
      api_data_key: dashboards_list
    }
  except Exception as e:
    return error_response(
      message=dashboards_fetch_error,
      status_code=503,
      detail=str(e)
    )
    
@router.post("/add", status_code=status.HTTP_200_OK)
async def add(
  db: db_dependency, 
  request: Request,
  dashboards_request: DashboardsRequest
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  
  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()
  
  now = datetime.now(timezone("Asia/Singapore"))
  max_order_index = db.query(Dashboards.order_index).order_by(Dashboards.order_index.desc()).first()
  try:
    new_dashboard = Dashboards(
      title=dashboards_request.title,
      description=dashboards_request.description,
      notes=dashboards_request.notes,
      version=dashboards_request.version,
      url=dashboards_request.url,
      order_index=(max_order_index[0] + 1) if max_order_index else 1,
      created_at=now,
      updated_at=now,
      created_by=user.id,
      updated_by=user.id
    )
    db.add(new_dashboard)
    
    db.flush()
    # Add dashboard-category relationships
    for category_id in dashboards_request.category_ids:
      dashboard_category = Dashboards_dashboards_categories(
        dashboard_id=new_dashboard.id,
        category_id=category_id,
        created_at=now,
        created_by=user.id
      )
      db.add(dashboard_category)
    
    create_audit_log(
      db=db,
      user_id=user.email,
      action="add",
      table_name="dashboards",
    )
    
    db.commit()
    
    db.refresh(new_dashboard)
    return {
      api_status_key: api_status_success,
      api_message_key: dashboard_create_success,
      api_data_key: new_dashboard
    }
  except Exception as e:
    return error_response(
      message=dashboard_create_error,
      status_code=503,
      detail=str(e)
    )

class StarDashboardRequest(BaseModel):
  dashboard_id: int

@router.post("/star", status_code=status.HTTP_200_OK)
async def star_dashboard(
  db: db_dependency,
  request: Request,
  body: StarDashboardRequest
):
  """
  Star or unstar a dashboard by ID.
  If the dashboard is already starred, it will be unstarred and removed from quickactions for the user.
  If it is not starred, it will be starred and added to quickactions for the user.
  """
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response

  dashboard_id = body.dashboard_id

  await asyncio.sleep(delay)
  now = datetime.now(timezone("Asia/Singapore"))
  
  try:
    dashboard_model = db.query(Dashboards).filter(Dashboards.id == dashboard_id).first()
    
    dashboards_module = db.query(Modules).filter(Modules.label == "Dashboards").first()
    if not dashboards_module:
      return error_response(
        message=dashboards_module_not_found,
        status_code=404
      )
    dashboards_module_id = dashboards_module.id
    
    if not dashboard_model:
      return error_response(
        message=dashboard_not_found,
        status_code=404
      )

    starred_model = db.query(Dashboards_starred).filter(
      Dashboards_starred.user_id == user.id,
      Dashboards_starred.dashboard_id == dashboard_id
    ).first()

    if starred_model:
      db.delete(starred_model)
      db.commit()

      db.query(Quickactions).filter(
        Quickactions.module_id == dashboards_module_id,
        Quickactions.item_id == dashboard_id,
        Quickactions.user_id == user.id
      ).delete()
      db.commit()

      return {
        api_status_key: api_status_success,
        api_message_key: dashboard_unstar_success
      }

    new_starred = Dashboards_starred(
      user_id=user.id,
      dashboard_id=dashboard_id,
      created_at=now,
      created_by=user.id
    )
    new_quickaction = Quickactions(
      label=dashboard_model.title,
      user_id=user.id,
      url=dashboard_model.url,
      module_id=dashboards_module_id,
      item_id=dashboard_id,
      created_at=now,
      created_by=user.id
    )
    db.add(new_quickaction)
    db.add(new_starred)
    db.commit()

    db.refresh(new_starred)
    return {
      api_status_key: api_status_success,
      api_message_key: dashboard_star_success
    }
  except Exception as e:
    db.rollback()
    return error_response(
      message=dashboard_star_fail,
      status_code=503,
      detail=str(e)
    )

class DashboardsSortUpdate(BaseModel):
  dashboard_id: int
  newIndex: int

class DashboardsSortRequest(BaseModel):
  updates: List[DashboardsSortUpdate] = Field(..., min_items=2, max_items=2)

@router.post("/sort", status_code=status.HTTP_200_OK)
async def sort_dashboards(
  db: db_dependency,
  request: Request,
  body: DashboardsSortRequest
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response

  await asyncio.sleep(delay)
  
  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()
  
  try:
    for update in body.updates:
      dashboard_model = db.query(Dashboards).filter(Dashboards.id == update.dashboard_id).first()
      if not dashboard_model:
        return error_response(
          message=dashboard_not_found,
          status_code=404
        )
      db.query(Dashboards).filter(Dashboards.id == update.dashboard_id).update({
        "order_index": update.newIndex,
        "updated_by": user.id,
        "updated_at": datetime.now(timezone("Asia/Singapore"))
      })
    db.commit()

    create_audit_log(
      db=db,
      user_id=user.email,
      action="sort",
      table_name="dashboards",
    )
    
    return {
      api_status_key: api_status_success,
      api_message_key: dashboard_sorted_success
    }
  except Exception as e:
    return error_response(
      message=dashboard_sorted_error,
      status_code=503,
      detail=str(e)
    )
    
@router.get("/categories", status_code=status.HTTP_200_OK)
async def read_categories(
  db: db_dependency, 
  request: Request
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  
  await asyncio.sleep(delay)
  try:
    categories = db.query(Dashboards_categories).all()
    categories_list = [
      {"id": category.id, "name": category.name} for category in categories
    ]
    
    return {
      api_status_key: api_status_success,
      api_message_key: dashboard_categories_fetch_success,
      api_data_key: categories_list
    }
  except Exception as e:
    return error_response(
      message=dashboard_categories_fetch_error,
      status_code=503,
      detail=str(e)
    )
    
@router.get("/{dashboard_id}", status_code=status.HTTP_200_OK)
async def read_dashboard(
  db: db_dependency, 
  request: Request, 
  dashboard_id: str
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  
  await asyncio.sleep(delay)
  try:
    dashboard_model = (
      db.query(Dashboards)
      .filter(Dashboards.id == dashboard_id)
      .first()
    )
    
    if not dashboard_model:
      return error_response(
        message=dashboard_not_found,
        status_code=404
      )
    
    dashboard_dict = {k: v for k, v in dashboard_model.__dict__.items() if not k.startswith('_sa_instance_state')}
    dashboard_categories = db.query(Dashboards_categories).join(
      Dashboards_dashboards_categories,
      Dashboards_dashboards_categories.category_id == Dashboards_categories.id
    ).filter(
      Dashboards_dashboards_categories.dashboard_id == dashboard_model.id
    ).all()
    dashboard_dict["categories"] = [
      {"id": category.id, "name": category.name} for category in dashboard_categories
    ]
    
    return {
      api_status_key: api_status_success,
      api_message_key: dashboard_fetch_success,
      api_data_key: dashboard_dict
    }
  except Exception as e:
    return error_response(
      message=dashboard_fetch_error,
      status_code=503,
      detail=str(e)
    )
    
@router.post("/{dashboard_id}/update", status_code=status.HTTP_200_OK)
async def update_dashboard(
  db: db_dependency, 
  request: Request, 
  dashboard_id: str,
  dashboards_request: DashboardsRequest
):
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  now = datetime.now(timezone("Asia/Singapore"))
  
  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()
  
  try:
    dashboard_model = db.query(Dashboards).filter(Dashboards.id == dashboard_id).first()
    if not dashboard_model:
      return error_response(
        message=dashboard_fetch_error,
        status_code=404
      )
    
    dashboard_model.title = dashboards_request.title
    dashboard_model.description = dashboards_request.description
    dashboard_model.notes = dashboards_request.notes
    dashboard_model.version = dashboards_request.version
    dashboard_model.url = dashboards_request.url
    dashboard_model.updated_at = now
    dashboard_model.updated_by = user.id
    
    # Remove existing dashboard-category relationships
    db.query(Dashboards_dashboards_categories).filter(
      Dashboards_dashboards_categories.dashboard_id == dashboard_id
    ).delete()

    # Add new dashboard-category relationships
    for category_id in dashboards_request.category_ids:
      dashboard_category = Dashboards_dashboards_categories(
        dashboard_id=dashboard_id,
        category_id=category_id,
        created_at=now,
        created_by=user.id,
      )
      db.add(dashboard_category)
    
    db.commit()
    
    create_audit_log(
      db=db,
      user_id=user.email,
      action="edit",
      table_name="dashboards",
    )
    
    db.refresh(dashboard_model)
    
    return {
      api_status_key: api_status_success,
      api_message_key: dashboard_update_success,
      api_data_key: dashboard_model.__dict__
    }
  except Exception as e:
    return error_response(
      message=dashboard_update_error,
      status_code=503,
      detail=str(e)
    )
    
@router.post("/{dashboard_id}/delete", status_code=status.HTTP_200_OK)
async def delete_dashboard(
  db: db_dependency, 
  request: Request, 
  dashboard_id: str
):
  """
  Delete a dashboard by ID, also removes all starred records,
  dashboard-category relationships, and quickactions associated with it.
  """
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  
  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()
  
  try:
    dashboard_model = db.query(Dashboards).filter(Dashboards.id == dashboard_id).first()
    if not dashboard_model:
      return error_response(
        message=dashboard_fetch_error,
        status_code=404
      )
    
    # Remove all starred records for this dashboard
    db.query(Dashboards_starred).filter(
      Dashboards_starred.dashboard_id == dashboard_id
    ).delete()
    
    # Remove all dashboard-category relationships for this dashboard
    db.query(Dashboards_dashboards_categories).filter(
      Dashboards_dashboards_categories.dashboard_id == dashboard_id
    ).delete()
    
    dashboards_module = db.query(Modules).filter(Modules.label == "Dashboards").first()
    if not dashboards_module:
      return error_response(
        message=dashboards_module_not_found,
        status_code=404
      )
    dashboards_module_id = dashboards_module.id
    
    # Remove all quickactions for this dashboard in the Dashboards module
    db.query(Quickactions).filter(
      Quickactions.module_id == dashboards_module_id,
      Quickactions.item_id == dashboard_id
    ).delete()
    
    db.delete(dashboard_model)
    
    db.commit()
    
    create_audit_log(
      db=db,
      user_id=user.email,
      action="delete",
      table_name="dashboards",
    )
    
    return {
      api_status_key: api_status_success,
      api_message_key: dashboard_delete_success
    }
  except Exception as e:
    return error_response(
      message=dashboard_delete_error,
      status_code=503,
      detail=str(e)
    )
    
