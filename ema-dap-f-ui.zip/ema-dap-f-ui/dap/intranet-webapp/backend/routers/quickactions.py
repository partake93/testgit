import asyncio
from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Path, Request, Response
from pydantic import BaseModel, Field
from pytz import timezone
from sqlalchemy.orm import Session
from starlette import status
from starlette.responses import Response as StarletteResponse

from constants.api_responses import api_data_key, api_message_key, api_status_key, api_status_success
from constants.auth import auth_cookie_name
from constants.response_messages import (
  quickactions_fetch_success,
  quickactions_fetch_error,
  quickaction_create_success,
  quickaction_create_error,
  quickaction_not_found,
  quickaction_fetch_success,
  quickaction_delete_success,
  quickaction_delete_error
)
from database import get_db
from models import Quickactions, Modules, Dashboards_starred
from utils.api_responses import error_response
from .auth import get_current_user

router = APIRouter(
  prefix='/api/quickactions',
  tags=['quickactions']
)

delay = 0

db_dependency = Annotated[Session, Depends(get_db)]

class QuickactionsRequest(BaseModel):
    label: str = Field(min_length=3)
    url: str = Field(min_length=3, max_length=100)
    
@router.get("/", status_code=status.HTTP_200_OK)
async def read_all(
  request: Request, 
  db: db_dependency
):
  
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  try: 
        
    quickactions = db.query(Quickactions).filter(Quickactions.user_id == user.id).all()
    for quickaction in quickactions:
      if quickaction.module_id:
        module = db.query(Modules).filter(Modules.id == quickaction.module_id).first()
        quickaction.icon_name = module.icon_name if module else None
      else:
        quickaction.icon_name = None
    
    return {
      api_status_key: api_status_success,
      api_message_key: quickactions_fetch_success,
      api_data_key: [
        {
          "id": quickaction.id,
          "label": quickaction.label,
          "url": quickaction.url,
          "order_index": quickaction.order_index,
          "module_id": quickaction.module_id if quickaction.module_id else None,
          "icon_name": quickaction.icon_name
        } for quickaction in quickactions
      ]
    }
  except Exception as e:
    return error_response(
      message=quickactions_fetch_error,
      status_code=404,
      detail=str(e)
    )

@router.post("/add", status_code=status.HTTP_200_OK)
async def create_quickaction(
  db: db_dependency, 
  request: Request, 
  quickactions_request: QuickactionsRequest
):
  
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response

  await asyncio.sleep(delay)
  now = datetime.now(timezone("Asia/Singapore"))
  quickactions_model = Quickactions(**quickactions_request.model_dump())
  max_order_index = db.query(Quickactions.order_index).order_by(Quickactions.order_index.desc()).first()
  quickactions_model.order_index = (max_order_index[0] + 1) if max_order_index and max_order_index[0] is not None else 1
  quickactions_model.user_id = user.id
  quickactions_model.created_at = now
  quickactions_model.created_by = user.id
  
  try:
    db.add(quickactions_model)
    db.commit()
  except Exception as e:
    db.rollback()
    return error_response(
      message=quickaction_create_error,
      status_code=503,
      detail=str(e)
    )

  db.refresh(quickactions_model)
  return {
    api_status_key: api_status_success,
    api_message_key: quickaction_create_success,
    api_data_key: quickactions_model.__dict__
  }

@router.get("/{quickaction_id}", status_code=status.HTTP_200_OK)
async def read_quickaction(
  quickaction_id: str, 
  request: Request, 
  db: db_dependency
):
  
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  
  await asyncio.sleep(delay)
  quickactions_model = db.query(Quickactions).filter(Quickactions.id == quickaction_id).first()
  if quickactions_model is None:
     return error_response(
      message=quickaction_not_found,
      status_code=404
    )
  return {
    api_status_key: api_status_success,
    api_message_key: quickaction_fetch_success,
    api_data_key: {
      "id": quickactions_model.id,
      "label": quickactions_model.label,
      "url": quickactions_model.url,
      "order_index": quickactions_model.order_index,
      "module_id": quickactions_model.module_id if quickactions_model.module_id else None,
    }
  }
  
@router.post("/{quickaction_id}/delete", status_code=status.HTTP_200_OK)
async def delete_quickaction(
  db: db_dependency, 
  request: Request, 
  quickaction_id: str
):
 
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response

  quickactions_model = db.query(Quickactions).filter(Quickactions.id == quickaction_id).first()
  
  if quickactions_model is None:
    return error_response(
      message=quickaction_not_found,
      status_code=503
    )
    
  try:  
    dashboards_module = db.query(Modules).filter(Modules.label == "Dashboards").first()
    dashboards_module_id = dashboards_module.id
    
    if quickactions_model.module_id == dashboards_module_id:
      # Remove from starred dashboards if it exists
      db.query(Dashboards_starred).filter(
        Dashboards_starred.dashboard_id == quickactions_model.item_id,
        Dashboards_starred.user_id == quickactions_model.user_id
      ).delete()
    
    db.query(Quickactions).filter(Quickactions.id == quickaction_id).delete()
    db.commit()
    return {
      api_status_key: api_status_success,
      api_message_key: quickaction_delete_success
    }
  except Exception as e:
    db.rollback()
    return error_response(
      message=quickaction_delete_error,
      status_code=503,
      detail=str(e)
    )