import asyncio
from datetime import datetime
from typing import Annotated, List

from fastapi import APIRouter, Depends, HTTPException, Path, Request, Body
from pydantic import BaseModel, Field
from pytz import timezone
from sqlalchemy.orm import Session
from starlette import status
from starlette.responses import Response as StarletteResponse

from database import get_db
from models import (
  Requests,
  Request_files,
  Files_uploaded,
  Notifications,
  Notifications_info,
  Modules,
  Module_access,
  Roles_access,
  UserInfo
)
from .auth import get_current_user, get_admin_role_id
from constants.api_responses import (
  api_status_key,
  api_message_key,
  api_data_key,
  api_status_success,
  api_total_pages_key,
  api_current_page_key,
  api_total_count_key,
)
from constants.auth import auth_cookie_name
from constants.statuses import (
  statusPending,
  statusNeedAttention,
  statusInfo,
  statusApproved,
  statusRejected,
  actionApprove,
  actionReject,
)
from constants.response_messages import (
  requests_fetch_success,
  requests_fetch_error,
  request_create_success,
  request_create_error,
  request_not_found,
  request_fetch_single_success,
  request_fetch_single_error,
  request_exists,
  access_granted_previously,
  access_granted_through_role,
  request_invalid_action,
  request_notification_title,
  request_process_error,
  request_action,
  request_notification_status,
  request_notification_new,
)
from utils.api_responses import error_response, unauthorised_response
from utils.audit_logs import create_audit_log

router = APIRouter(
  prefix='/api/requests',
  tags=['requests']
)

delay = 0
items_per_page = 10

db_dependency = Annotated[Session, Depends(get_db)]

class RequestData(BaseModel):
  module_id: int
  purpose: str
  justification: str
  file_ids: List[int] = Field(default_factory=list)

@router.post("/raise", status_code=status.HTTP_200_OK)
async def add_request(
  db: db_dependency, 
  request: Request,
  request_data: RequestData,
  is_testing: bool = False
):
  """
  This api will
  - checks if user has already requested access to the module
  - add a new request to the database
  - create a notification for the admin and the user
  """
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response

  await asyncio.sleep(delay)

  try:
    # Check for duplicate request
    existing_request = db.query(Requests).filter(
      Requests.module_id == request_data.module_id,
      Requests.created_by == user.id,
      Requests.status == statusPending
    ).first()
    
    if existing_request:
      return error_response(
        status_code=400,
        message=request_exists
      )
      
    # Check if user already has access
    module_access = (
      db.query(Module_access)
      .filter(
        Module_access.user_id == user.id,
        Module_access.module_id == request_data.module_id
      )
      .first()
    )
    if module_access:
      return error_response(
        status_code=400,
        message=access_granted_previously
      )
      
    role_module_access = (
      db.query(Modules)
      .join(Roles_access, Roles_access.module_id == Modules.id)
      .filter(
        Roles_access.role_id == user.role_id,
        Modules.id == request_data.module_id
      ).first()
    )
    if role_module_access:
      return error_response(
        status_code=400,
        message=access_granted_through_role
      )
    
    new_request = Requests(
      module_id=request_data.module_id,
      purpose=request_data.purpose,
      justification=request_data.justification,
      status=statusPending,
      created_at=datetime.now(timezone("Asia/Singapore")),
      created_by=user.id
    )
    if not is_testing:
      db.add(new_request)
      db.flush()

    for file_id in request_data.file_ids:
      file_record = db.query(Files_uploaded).filter(Files_uploaded.id == file_id).first()
      if file_record:
        new_request_file = Request_files(
          request_id=new_request.id,
          file_id=file_record.id,
          created_at=datetime.now(timezone("Asia/Singapore")),
          created_by=user.id
        )
        if not is_testing:
          db.add(new_request_file)

    # Notification for admin
    module = db.query(Modules).filter(Modules.id == request_data.module_id).first()
    module_name = module.label if module else "unknown module"

    admin_notification = Notifications(
      classification=statusNeedAttention,
      inserted_at=datetime.now(timezone("Asia/Singapore")),
      admin_only=True
    )
    if not is_testing:
      db.add(admin_notification)
      db.flush()
    admin_notification_info = Notifications_info(
      notification_id=admin_notification.id,
      job_name="New Request Notification",
      classification=statusNeedAttention,
      details=request_notification_new.replace("_email", user.email).replace("_module", module_name),
      request_id=new_request.id,
    )
    if not is_testing:
      db.add(admin_notification_info)
    
    # Notification for user
    user_notification = Notifications(
      classification=statusInfo,
      inserted_at=datetime.now(timezone("Asia/Singapore")),
      targeted_user_id=user.id
    )
    if not is_testing:
      db.add(user_notification)
      db.flush()
    user_notification_info = Notifications_info(
      notification_id=user_notification.id,
      job_name="Request Submitted Notification",
      classification=statusInfo,
      details=request_notification_status.replace("_module", module_name).replace("_status", "submitted"),
      create_datetime=datetime.now(timezone("Asia/Singapore")),
      request_id=new_request.id,
    )
    if not is_testing:
      db.add(user_notification_info)
      db.commit()

      create_audit_log(
        db=db,
        user_id=user.email,
        action="raise",
        table_name="requests",
      )

    return {
      api_status_key: api_status_success,
      api_message_key: request_create_success,
      api_data_key: {
        "request_id": new_request.id,
        "module_id": new_request.module_id,
        "module_name": module_name,
        "purpose": new_request.purpose,
        "justification": new_request.justification,
        "status": new_request.status,
        "created_at": new_request.created_at,
      }
    }
  except Exception as e:
    db.rollback()
    return error_response(
      status_code=500,
      message=request_create_error,
      detail=str(e)
    )

@router.get("/", status_code=status.HTTP_200_OK)
async def get_all_requests(
  db: db_dependency,
  request: Request,
  page: int = 1,
  status: str = None,
  startdate: str = None,
  enddate: str = None,
):
  """
  Get all requests with pagination
  """
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response

  await asyncio.sleep(delay)
  
  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()

  try:
    query = db.query(Requests)

    if status:
      query = query.filter(Requests.status == status)
    if startdate:
      try:
        start_dt = datetime.strptime(startdate, "%Y-%m-%d")
        query = query.filter(Requests.created_at >= start_dt)
      except ValueError:
        return error_response(
          status_code=400,
          message="Invalid startdate format. Use YYYY-MM-DD.",
          detail=""
        )
    if enddate:
      try:
        end_dt = datetime.strptime(enddate, "%Y-%m-%d")
        # To include the whole end date, add 1 day and use less than
        end_dt = end_dt.replace(hour=23, minute=59, second=59, microsecond=999999)
        query = query.filter(Requests.created_at <= end_dt)
      except ValueError:
        return error_response(
          status_code=400,
          message="Invalid enddate format. Use YYYY-MM-DD.",
          detail=""
        )
    
    total_requests = query.count()
    total_pages = (total_requests + items_per_page - 1) // items_per_page

    requests = (
      query
      .order_by(Requests.created_at.desc())
      .offset((page - 1) * items_per_page)
      .limit(items_per_page)
      .all()
    )
    
    result = []
    
    for request in requests:
      user_info = db.query(UserInfo).filter(UserInfo.id == request.created_by).first()
      if user_info:
        request.first_name = user_info.first_name
        request.last_name = user_info.last_name
      else:
        request.first_name = "Unknown"
        request.last_name = "User"

      module = db.query(Modules).filter(Modules.id == request.module_id).first()
      request.module_name = module.label if module else "Unknown Module"
      result.append(request)

    return {
      api_status_key: api_status_success,
      api_message_key: requests_fetch_success,
      api_data_key: result,
      api_total_pages_key: total_pages,
      api_current_page_key: page,
      api_total_count_key: total_requests
    }
  except Exception as e:
    return error_response(
      status_code=500,
      message=requests_fetch_error,
      detail=str(e)
    )

class ActionRequest(BaseModel):
  action: str
  request_ids: List[str] = Field(..., title="The IDs of the requests to act on")

@router.post("/action", status_code=status.HTTP_200_OK)
async def action_on_request(
  db: db_dependency,
  request: Request,
  action_request: ActionRequest = Body(...),
):
  """
  - Approve or reject a request
  - if approve, 
    - Add row to module_access table
  - Send notification to user
  """

  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response

  await asyncio.sleep(delay)

  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()

  try:
    action = getattr(action_request, "action", None)
    if action:
      action = action.lower()
    if action not in [actionApprove, actionReject]:
      return error_response(
        status_code=400,
        message=f"{request_invalid_action}. Use '{actionApprove}' or '{actionReject}'",
        detail=""
      )

    results = []
    for req_id in action_request.request_ids:
      req = db.query(Requests).filter(Requests.id == req_id).first()
      if not req:
        db.rollback()
        return error_response(
          status_code=404,
          message=request_not_found,
          detail=f"Request ID {req_id} not found"
        )

      req.status = statusApproved if action == actionApprove else statusRejected
      req.action_at = datetime.now(timezone("Asia/Singapore"))
      req.action_by = user.id
      db.commit()

      if action == actionApprove:
        # Grant access by inserting a row in module_access
        module_access = Module_access(
          user_id=req.created_by,
          request_id=req.id,
          module_id=req.module_id,
          granted_at=datetime.now(timezone("Asia/Singapore")),
          granted_by=user.id
        )
        db.add(module_access)
        db.commit()

      # Create notification for user
      notification = Notifications(
        classification=statusInfo,
        inserted_at=datetime.now(timezone("Asia/Singapore")),
        targeted_user_id=req.created_by
      )
      db.add(notification)
      db.flush()

      module = db.query(Modules).filter(Modules.id == req.module_id).first()
      module_name = module.label if module else "unknown module"

      notification_info = Notifications_info(
        notification_id=notification.id,
        job_name=request_notification_title,
        classification=statusInfo,
        details=request_notification_status.replace("_module", module_name).replace("_status", req.status.lower()),
        create_datetime=datetime.now(timezone("Asia/Singapore")),
        request_id=req.id,
      )
      db.add(notification_info)
      db.commit()

      results.append({
        "request_id": req.id,
        "status": req.status,
        "action_at": req.action_at,
        "action_by": req.action_by
      })

    db.commit()

    create_audit_log(
      db=db,
      user_id=user.email,
      action="action: " + action,
      table_name="requests",
    )
    
    return {
      api_status_key: api_status_success,
      api_message_key: request_action.replace("_action", action),
      api_data_key: results
    }
  except Exception as e:
    db.rollback()
    return error_response(
      status_code=500,
      message=request_process_error,
      detail=str(e)
    )

@router.post("/{request_id}/action", status_code=status.HTTP_200_OK)
async def action_on_request(
  db: db_dependency,
  request: Request,
  request_id: int = Path(..., title="The ID of the request to act on"),
  action: str = Body(..., embed=True, title="Action to perform ('approve' or 'reject')"),
):
  """
  - Approve or reject a request
  - Add row to module_access table
  - Send notification to user
  """

  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response

  await asyncio.sleep(delay)

  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()

  try:
    req = db.query(Requests).filter(Requests.id == request_id).first()
    if not req:
      raise HTTPException(status_code=404, detail="Request not found")

    if action:
      action = action.lower()
    if action not in ["approve", "reject"]:
      return error_response(
        status_code=400,
        message="Invalid action. Use 'approve' or 'reject'.",
        detail=""
      )

    req.status = "Approved" if action == "approve" else "Rejected"
    req.action_at = datetime.now(timezone("Asia/Singapore"))
    req.action_by = user.id
    db.commit()

    if action == "approve":
      # Grant access by inserting a row in module_access
      module_access = Module_access(
        user_id=req.created_by,
        request_id=req.id,
        module_id=req.module_id,
        granted_at=datetime.now(timezone("Asia/Singapore")),
        granted_by=user.id
      )
      db.add(module_access)
      db.commit()

    # Create notification for user
    notification = Notifications(
      classification="Information",
      inserted_at=datetime.now(timezone("Asia/Singapore")),
      targeted_user_id=req.created_by
    )
    db.add(notification)
    db.flush()

    module = db.query(Modules).filter(Modules.id == req.module_id).first()
    module_name = module.label if module else "unknown module"

    notification_info = Notifications_info(
      notification_id=notification.id,
      job_name="Request Action Notification",
      classification="Information",
      details=f"Your request to access {module_name} has been {req.status.lower()}.",
      create_datetime=datetime.now(timezone("Asia/Singapore")),
      request_id=req.id,
    )
    db.add(notification_info)

    db.commit()

    create_audit_log(
      db=db,
      user_id=user.email,
      action="action: " + action,
      table_name="requests",
    )

    return {
      api_status_key: api_status_success,
      api_message_key: f"Request {action} successfully",
      api_data_key: {
        "request_id": req.id,
        "status": req.status,
        "action_at": req.action_at,
        "action_by": req.action_by
      }
    }
  except Exception as e:
    db.rollback()
    return error_response(
      status_code=500,
      message="An error occurred while processing the request",
      detail=str(e)
    )

@router.get("/{request_id}", status_code=status.HTTP_200_OK)
async def get_request_by_id(
  db: db_dependency,
  request: Request,
  request_id: int = Path(..., title="The ID of the request to retrieve"),
):
  """Get a specific request by ID
  """
  
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response

  await asyncio.sleep(delay)
  
  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()
  
  try:
    request_data = (
      db.query(Requests, Request_files)
      .outerjoin(Request_files, Requests.id == Request_files.request_id)
      .filter(Requests.id == request_id)
      .all()
    )
    if not request_data:
      raise HTTPException(status_code=404, detail=request_not_found)

    # Flatten the result: get the request and all associated file_ids
    request_obj = request_data[0][0]
    file_ids = []
    for _, rf in request_data:
      if rf is not None:
        file_record = db.query(Files_uploaded).filter(Files_uploaded.id == rf.file_id).first()
        if file_record:
          file_ids.append({
            "id": file_record.id,
            "file_name": file_record.file_name,
            "file_size": file_record.file_size,
          })

    module = db.query(Modules).filter(Modules.id == request_obj.module_id).first()
    module_name = module.label if module else "Unknown Module"
    
    user_info = db.query(UserInfo).filter(UserInfo.id == request_obj.created_by).first()
    created_by_first_name = user_info.first_name if user_info else ""
    created_by_last_name = user_info.last_name if user_info else ""
    
    result = {
      "id": request_obj.id,
      "module_id": request_obj.module_id,
      "module_name": module_name,
      "purpose": request_obj.purpose,
      "justification": request_obj.justification,
      "status": request_obj.status,
      "created_at": request_obj.created_at,
      "created_by": request_obj.created_by,
      "created_by_first_name": created_by_first_name,
      "created_by_last_name": created_by_last_name,
      "file_ids": file_ids,
    }
    if not request_data:
      raise HTTPException(status_code=404, detail=request_not_found)

    return {
      api_status_key: api_status_success,
      api_message_key: request_fetch_single_success,
      api_data_key: result
    }
  except Exception as e:
    return error_response(
      status_code=500,
      message=request_fetch_single_error,
      detail=str(e)
    )

