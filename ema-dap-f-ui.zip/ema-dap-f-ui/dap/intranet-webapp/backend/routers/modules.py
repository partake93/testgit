import asyncio
from datetime import datetime
from typing import Annotated, List

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from pytz import timezone
from sqlalchemy.orm import Session
from starlette import status
from starlette.responses import Response as StarletteResponse

from models import (
  Roles_access,
  Modules,
  Modules_modules_tags,
  Modules_tags,
  Module_access,
  UserInfo,
  Requests
)
from database import get_db
from .auth import get_current_user, get_admin_role_id
from constants.api_responses import (
  api_status_key,
  api_message_key,
  api_data_key,
  api_status_success,
)
from constants.auth import auth_cookie_name
from constants.statuses import (
  statusActive,
  statusInactive,
  statusPending
)
from constants.response_messages import (
  modules_fetch_success,
  modules_fetch_error,
  modules_sort_success,
  modules_sort_error,
  module_create_success,
  module_create_error,
  module_tags_fetch_success,
  module_tags_fetch_error,
  module_not_found,
  module_fetch_success,
  module_update_success,
  module_update_error,
  module_delete_success,
  module_delete_error
)
from utils.api_responses import error_response, unauthorised_response
from utils.audit_logs import create_audit_log

router = APIRouter(
  prefix='/api/modules',
  tags=['modules']
)

delay = 0

db_dependency = Annotated[Session, Depends(get_db)]

class ModuleRequest(BaseModel):
  label: str = Field(min_length=3)
  icon_name: str = Field(min_length=3, max_length=100)
  tooltip_text: str = Field(min_length=3, max_length=255)
  default_visible: bool = Field(default=True)
  url: str = Field(min_length=3, max_length=255)
  tags: List[int] = Field(default=[])
  confirmation_step: bool = Field(default=False)
  confirmation_text: str = Field(default=None)
   
@router.get("/", status_code=status.HTTP_200_OK)
async def read_all(
  request: Request, 
  db: db_dependency
):
  """
  admin can see and access all modules 
    - FE: if has_access==true even if default_visible==false, do not disable tile \n
  non-admin users 
    - can only see all modules that are default visible
    - can only access modules their role has access to
    - individual users can access modules they are granted access to
  """
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  try: 
    
    admin_role_id = await get_admin_role_id(db)
    
    modules_query = (
      db.query(Modules)
      .filter(Modules.status == statusActive)
      .all()
    )
   
    user_module_access_ids = (
      db.query(Module_access.module_id)
      .filter(Module_access.user_id == user.id)
      .all()
    )
    role_module_ids = (
      db.query(Roles_access.module_id)
      .filter(Roles_access.role_id == user.role_id)
      .all()
    )
    all_accessible_module_ids = set([mid[0] for mid in role_module_ids] + [mid[0] for mid in user_module_access_ids])

    modules_model = []
    for module in modules_query:
      tags = (
        db.query(Modules_tags.id, Modules_tags.label)
        .join(Modules_modules_tags, Modules_modules_tags.tag_id == Modules_tags.id)
        .filter(Modules_modules_tags.module_id == module.id)
        .all()
      )
      tags_list = [{"id": tag.id, "label": tag.label} for tag in tags]
      updated_by_user = db.query(UserInfo).filter(UserInfo.id == module.updated_by).first()
      updated_by_first_name = updated_by_user.first_name if updated_by_user else None
      updated_by_last_name = updated_by_user.last_name if updated_by_user else None
      
      existing_request = db.query(Requests).filter(
        Requests.module_id == module.id,
        Requests.created_by == user.id,
        Requests.status == statusPending
      ).first()
      
      module_dict = {
        "id": module.id,
        "label": module.label,
        "icon_name": module.icon_name,
        "tooltip_text": module.tooltip_text,
        "url": module.url,
        "tags": tags_list,
        "order_index": module.order_index,
        "default_visible": module.default_visible,
        "has_access": user.role_id == admin_role_id or module.id in all_accessible_module_ids,
        "pending": existing_request is not None,
        "editable": module.editable,
        "confirmation_step": module.confirmation_step,
        "confirmation_text": module.confirmation_text,
        "updated_at": module.updated_at,
        "updated_by_first_name": updated_by_first_name,
        "updated_by_last_name": updated_by_last_name,
      }
      
      if user.role_id == admin_role_id or module.default_visible :
        modules_model.append(module_dict)
    modules_model.sort(key=lambda x: x["order_index"])
    return {
      api_status_key: api_status_success,
      api_message_key: modules_fetch_success,
      api_data_key: modules_model
    }
  except Exception as e:
    return error_response(
      message=modules_fetch_error,
      status_code=400,
      detail=str(e)
    )

class ModuleSortUpdate(BaseModel):
  module_id: int
  newIndex: int

class ModuleSortRequest(BaseModel):
  updates: List[ModuleSortUpdate] = Field(..., min_items=2, max_items=2)

@router.post("/sort", status_code=status.HTTP_200_OK)
async def sort_modules(
  db: db_dependency, 
  request: Request, 
  modules_request: ModuleSortRequest
):
  
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  
  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()

  now = datetime.now(timezone("Asia/Singapore"))
  
  try:
    for module in modules_request.updates:
      module_model = db.query(Modules).filter(Modules.id == module.module_id).first()
      if module_model is not None:
        module_model.order_index = module.newIndex
        module_model.updated_at = now
        module_model.updated_by = user.id
        db.commit()
    
    create_audit_log(
      db=db,
      user_id=user.email,
      action="sort",
      table_name="modules",
    )
    
    return {
      api_status_key: api_status_success,
      api_message_key: modules_sort_success
    }
  except Exception as e:
    db.rollback()
    return error_response(
      message=modules_sort_error,
      status_code=503,
      detail=str(e)
    )
    
@router.post("/add", status_code=status.HTTP_200_OK)
async def create_module(
  db: db_dependency, 
  request: Request, 
  module_request: ModuleRequest
):
  
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  
  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()
  
  now = datetime.now(timezone("Asia/Singapore"))
  
  module_data = module_request.model_dump()
  module_data.pop("tags", None)  # Remove 'tags' key if present
  module_model = Modules(**module_data)
  max_order_index = db.query(Modules.order_index).order_by(Modules.order_index.desc()).first()
  module_model.order_index = (max_order_index[0] + 1) if max_order_index and max_order_index[0] is not None else 1
  module_model.confirmation_step = module_request.confirmation_step  
  module_model.confirmation_text = module_request.confirmation_text if module_request.confirmation_step else "" 
  module_model.status = statusActive
  module_model.created_at = now
  module_model.updated_at = now
  module_model.created_by = user.id
  module_model.updated_by = user.id
  
  try:
    db.add(module_model)
    
    db.flush()  # Ensure module_model.id is available
    for tag_id in module_request.tags:
      tag = db.query(Modules_tags).filter(Modules_tags.id == tag_id).first()
      if tag:
        module_tag = Modules_modules_tags(
            module_id=module_model.id,
            tag_id=tag_id,
            created_by=user.id,
            created_at=now
        )
        db.add(module_tag)
    
    db.commit()
    
    create_audit_log(
      db=db,
      user_id=user.email,
      action="add",
      table_name="modules",
    )
    
    db.refresh(module_model)
    return {
      api_status_key: api_status_success,
      api_message_key: module_create_success,
      api_data_key: module_model.__dict__
    }
  except Exception as e:
    db.rollback()
    return error_response(
      message=module_create_error,
      status_code=503,
      detail=str(e)
    )

@router.get("/all_tags", status_code=status.HTTP_200_OK)
async def read_all_tags(
  request: Request, 
  db: db_dependency
):
  
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  
  await asyncio.sleep(delay)
  
  try:
    tags_query = db.query(Modules_tags).all()
    tags_model = [{"id": tag.id, "label": tag.label} for tag in tags_query]
    
    return {
      api_status_key: api_status_success,
      api_message_key: module_tags_fetch_success,
      api_data_key: tags_model
    }
  except Exception as e:
    return error_response(
      message=module_tags_fetch_error,
      status_code=400,
      detail=str(e)
    )

@router.get("/{module_id}", status_code=status.HTTP_200_OK)
async def read_module(
  module_id: str, 
  request: Request, 
  db: db_dependency
):
  """
   If the user is not an admin and the module_id is not in the allowed list, return unauthorized response \n
   TODO: check with module_access table
  """
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
    
  # Join Modules and Roles_access, filter by user's role, and check if module_id exists in the allowed list
  check_allowed_module_id = (
    db.query(Modules.id)
    .join(Roles_access, Roles_access.module_id == Modules.id)
    .filter(Roles_access.role_id == user.role_id)
    .filter(Modules.id == module_id)
    .first()
  )
  admin_role_id = await get_admin_role_id(db)
  if check_allowed_module_id is None and user.role_id != admin_role_id:
    return await unauthorised_response()
  
  module_model = (
    db.query(Modules)
    .filter(Modules.id == module_id)
    .filter(Modules.status == statusActive)
    .first()
  )
  if module_model is None:
    return error_response(
      message=module_not_found,
      status_code=404
    )
  tags = (
    db.query(Modules_tags.id, Modules_tags.label)
    .join(Modules_modules_tags, Modules_modules_tags.tag_id == Modules_tags.id)
    .filter(Modules_modules_tags.module_id == module_model.id)
    .all()
  )
  tags_list = [{"id": tag.id, "label": tag.label} for tag in tags]
  
  return {
    api_status_key: api_status_success,
    api_message_key: module_fetch_success,
    api_data_key: {
      "id": module_model.id,
      "label": module_model.label,
      "icon_name": module_model.icon_name,
      "tooltip_text": module_model.tooltip_text,
      "default_visible": module_model.default_visible,
      "url": module_model.url,
      "order_index": module_model.order_index,
      "tags": tags_list,
      "confirmation_step": module_model.confirmation_step,
      "confirmation_text": module_model.confirmation_text,
    }
  }
  
@router.post("/{module_id}/edit", status_code=status.HTTP_200_OK)
async def update_module(
  db: db_dependency, 
  request: Request, 
  module_id: str, 
  module_request: ModuleRequest
):
  
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  
  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()
  
  now = datetime.now(timezone("Asia/Singapore"))
  
  module_model = (
    db.query(Modules)
    .filter(Modules.id == module_id)
    .filter(Modules.status == statusActive)
    .first()
  )
  
  if module_model is None:
    return error_response(
      message=module_not_found,
      status_code=404,
    )
    
  try:
    module_model.label = module_request.label
    module_model.icon_name = module_request.icon_name
    module_model.tooltip_text = module_request.tooltip_text
    module_model.default_visible = module_request.default_visible
    module_model.url = module_request.url
    module_model.confirmation_step = module_request.confirmation_step
    module_model.confirmation_text = module_request.confirmation_text if module_request.confirmation_step else ""
    module_model.updated_at = now
    module_model.updated_by = user.id
    
    db.add(module_model)
    db.flush()  # Ensure module_model.id is available

    db.query(Modules_modules_tags).filter(Modules_modules_tags.module_id == module_model.id).delete()
    for tag_id in module_request.tags:
      tag = db.query(Modules_tags).filter(Modules_tags.id == tag_id).first()
      if tag:
        module_tag = Modules_modules_tags(
            module_id=module_model.id,
            tag_id=tag_id,
            created_by=user.id,
            created_at=now,
        )
        db.add(module_tag)
    
    db.commit()
    
    create_audit_log(
      db=db,
      user_id=user.email,
      action="edit",
      table_name="modules",
    )
    
    return {
      api_status_key: api_status_success,
      api_message_key: module_update_success,
      api_data_key: {
        "id": module_model.id,
        "label": module_model.label,
        "icon_name": module_model.icon_name,
        "tooltip_text": module_model.tooltip_text,
        "default_visible": module_model.default_visible,
        "url": module_model.url,
        "order_index": module_model.order_index,
        "tags": module_request.tags
      }
    }
  except Exception as e:
    db.rollback()
    return error_response(
      message=module_update_error,
      status_code=503,
      detail=str(e)
    )

@router.post("/{module_id}/delete", status_code=status.HTTP_200_OK)
async def delete_module(
  db: db_dependency, 
  request: Request, 
  module_id: str
):
  
  get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  if isinstance(get_current_user_response, StarletteResponse):
    return get_current_user_response
  user = get_current_user_response
  
  await asyncio.sleep(delay)
  
  admin_role_id = await get_admin_role_id(db)
  if user.role_id != admin_role_id:
    return await unauthorised_response()
  
  module_model = (
    db.query(Modules)
    .filter(Modules.id == module_id)
    .filter(Modules.status == statusActive)
    .first()
  )
  
  if module_model is None:
    return error_response(
      message=module_not_found,
      status_code=404
    )
    
  try:
    # db.query(Modules_modules_tags).filter(Modules_modules_tags.module_id == module_model.id).delete()
    module_model.status = statusInactive
    module_model.updated_at = datetime.now(timezone("Asia/Singapore"))
    module_model.updated_by = user.id
    db.add(module_model)
    db.commit()
    
    create_audit_log(
      db=db,
      user_id=user.email,
      action="delete",
      table_name="modules",
    )
    
    return {
      api_status_key: api_status_success,
      api_message_key: module_delete_success
    }
  except Exception as e:
    db.rollback()
    return error_response(
      message=module_delete_error,
      status_code=503,
      detail=str(e)
    )