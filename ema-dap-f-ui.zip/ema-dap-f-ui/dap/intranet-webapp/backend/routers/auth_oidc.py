import os
import secrets
from datetime import datetime

import httpx
import jwt
from dotenv import load_dotenv
from fastapi import (
    APIRouter, 
    Depends, 
    Response
)
from fastapi.responses import RedirectResponse
from itsdangerous import URLSafeSerializer
from jwt import PyJWKClient
# from pydantic import BaseModel
from pytz import timezone
from sqlalchemy.orm import Session

from constants.auth import auth_cookie_name
from constants.response_messages import (
    invalid_oidc_config,
    invalid_token,
    no_token_received,
    issuer_not_found,
    token_decoded_error,
    claim_not_found,
    invalid_credentials,
    fe_url_error,
)
from database import get_db
from .auth import authenticate_user
from utils.audit_logs import create_audit_log
from utils.api_responses import error_response

load_dotenv()

SECRET_KEY=os.getenv("COOKIE_SECRET_KEY", "default_secret_key")
serializer = URLSafeSerializer(SECRET_KEY)

router = APIRouter(
  prefix='',
  tags=['auth_oidc']
)

OIDC_CLIENT_ID = os.getenv("OIDC_CLIENT_ID")
OIDC_CLIENT_SECRET = os.getenv("OIDC_CLIENT_SECRET")
OIDC_ISSUER_URL = os.getenv("OIDC_ISSUER_URL")
OIDC_REDIRECT_URI = os.getenv("OIDC_REDIRECT_URI")
OIDC_AUTHORIZATION_URL = f"{OIDC_ISSUER_URL}/connect/authorize"
OIDC_TOKEN_URL = f"{OIDC_ISSUER_URL}/connect/token"
OIDC_USERINFO_URL = f"{OIDC_ISSUER_URL}/userinfo"

COOKIE_MAX_AGE_SECONDS = int(os.getenv("COOKIE_MAX_AGE_SECONDS", 1800)) 
COOKIE_HTTP_ONLY = os.getenv("COOKIE_HTTP_ONLY", "true").lower() == "true"

# OIDC Login Route
@router.get("/login")
async def login():
    # Validate OIDC environment variables
    if not all([OIDC_CLIENT_ID, OIDC_CLIENT_SECRET, OIDC_ISSUER_URL, OIDC_REDIRECT_URI]):
        return error_response(
            message=invalid_oidc_config,
            status_code=500,
        )
    
    state = secrets.token_urlsafe(16)
    nonce = secrets.token_urlsafe(16)
    authorization_url = (
        f"{OIDC_AUTHORIZATION_URL}?response_type=code"
        f"&client_id={OIDC_CLIENT_ID}"
        f"&redirect_uri={OIDC_REDIRECT_URI}"
        f"&scope=openid"
        f"&state={state}"
        f"&nonce={nonce}"
    )
    return RedirectResponse(authorization_url)

# OIDC Callback Route
@router.get("/callback")
async def callback(
    response: Response,
    code: str,
    db: Session = Depends(get_db),
):

    # Exchange authorization code for access token
    async with httpx.AsyncClient() as client:
        response = await client.post(
            OIDC_TOKEN_URL,
            data={
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": OIDC_REDIRECT_URI,
                "client_id": OIDC_CLIENT_ID,
                "client_secret": OIDC_CLIENT_SECRET,
            },
        )
        response_data = response.json()

    if response.status_code != 200:
        return error_response(
            message=invalid_token,
            status_code=400,
        )

    access_token = response_data.get("access_token")
   
    if not access_token:
        return error_response(
            message=no_token_received,
            status_code=400,
        )

    # Get OIDC public keys for signature verification and actual issuer
    oidc_config_url = f"{OIDC_ISSUER_URL}/.well-known/openid-configuration"
    async with httpx.AsyncClient() as client:
        oidc_config_resp = await client.get(oidc_config_url)
        oidc_config_json = oidc_config_resp.json()
        jwks_uri = oidc_config_json.get("jwks_uri")
        actual_issuer = oidc_config_json.get("issuer")
        if not jwks_uri or not actual_issuer:
            return error_response(
                message=issuer_not_found,
                status_code=500,
            )
        # jwks_response = await client.get(jwks_uri)
        # jwks = jwks_response.json()

    # Use PyJWKClient to get signing key
    jwks_client = PyJWKClient(jwks_uri)
    signing_key = jwks_client.get_signing_key_from_jwt(access_token)

    try:
        decoded_token = jwt.decode(
            access_token,
            signing_key.key,
            algorithms=["RS256"],
            issuer=actual_issuer,
            options={"verify_aud": False}
        )
        # decoded_token now contains the claims from the access token
    except jwt.PyJWTError as e:
        return error_response(
            message=token_decoded_error,
            status_code=401,
            detail=str(e)
        )

    # get name identifier
    name_identifier = decoded_token.get("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier")
    if not name_identifier:
        return error_response(
            message=claim_not_found,
            status_code=401
        )

    # compare with user in database
    user = authenticate_user(db, name_identifier)
    if not user:
        return error_response(
            message=invalid_credentials,
            status_code=401
        )

    encrypted_value = serializer.dumps(name_identifier)
    FE_URL = os.getenv("FE_URL")
    if not FE_URL:
        return error_response(
            message=fe_url_error,
            status_code=500
        )

    response = RedirectResponse(url=FE_URL, status_code=302)
    
    # auth coookie first issued after successful OIDC login
    response.set_cookie(
        key=auth_cookie_name,
        value=encrypted_value,
        httponly=COOKIE_HTTP_ONLY,
        samesite="none",  # or "lax" if on same site
        secure=True,
        max_age=COOKIE_MAX_AGE_SECONDS
    )
    
    user.logged_in = True
    user.last_login = datetime.now(timezone("Asia/Singapore"))
    db.commit()
    
    # Insert record in audit_logs table
    create_audit_log(
        db=db,
        user_id=user.email,
        action="login"
    )
    
    return response
