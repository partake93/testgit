import os
import time
import asyncio
import pyodbc
import pandas as pd

from datetime import datetime
from typing import Annotated, List

from dotenv import load_dotenv

from fastapi import APIRouter, Depends, HTTPException, Path, Request, Response
from starlette import status
from starlette.responses import Response as StarletteResponse

from sqlalchemy.orm import Session
from sqlalchemy import text

from pydantic import BaseModel, Field

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from azure.storage.queue import QueueClient, BinaryBase64EncodePolicy, BinaryBase64DecodePolicy

from database import get_db
from .auth import get_current_user, get_admin_role_id
from constants.api_responses import (
  api_status_key,
  api_message_key,
  api_data_key,
  api_detail_key,
  api_status_success,
  api_status_error,
  api_total_pages_key,
  api_current_page_key
)
from constants.auth import auth_cookie_name
from constants.response_messages import (
  invalid_user
)
from utils.api_responses import error_response, unauthorised_response, rate_limiter
from models import Notifications, Notifications_info

load_dotenv()

router = APIRouter(
  prefix='/api/notifications_queue',
  tags=['notifications_queue']
)

QUEUE_ACCOUNT_NAME=os.getenv("QUEUE_ACCOUNT_NAME", "")
QUEUE_ACCOUNT_KEY=os.getenv("QUEUE_ACCOUNT_KEY", "")
QUEUE_NAME1=os.getenv("QUEUE_NAME1", "")
QUEUE_NAME2=os.getenv("QUEUE_NAME2", "")
SCHEDULER_ENABLED=os.getenv("SCHEDULER_ENABLED", "False")
SCHEDULER_INTERVAL=os.getenv("SCHEDULER_INTERVAL", "300")

connect_str = (
  f"DefaultEndpointsProtocol=https;"
  f"AccountName={QUEUE_ACCOUNT_NAME};"
  f"AccountKey={QUEUE_ACCOUNT_KEY};"
  f"EndpointSuffix=core.windows.net"
)

@router.get("/{class_type}", status_code=status.HTTP_200_OK)
@rate_limiter(max_requests=5, period=60)
async def get_notification_from_queue(
  request: Request,
  db: Annotated[Session, Depends(get_db)],
  class_type: str
):
  if request:
    auth_header = request.headers.get('Authorization')
    scheduler_api_key = os.getenv("SCHEDULER_API_KEY")
    if not auth_header or not auth_header.startswith('Bearer '):
      return error_response(
        message=invalid_user,
        status_code=401
      )
    token = auth_header.split('Bearer ')[1]
    if token != scheduler_api_key:
      return error_response(
        message=invalid_user,
        status_code=401
      )
  
  received_messages = get_messages(db, class_type)
  return received_messages

def get_messages(
  db: Annotated[Session, Depends(get_db)],
  class_type: str
):
  print(f"[{datetime.now().isoformat()}] Fetching messages: {class_type}")
  
  queue_client = QueueClient.from_connection_string(
    conn_str=connect_str,
    queue_name=QUEUE_NAME1 if class_type == "hard" else QUEUE_NAME2,
    message_encode_policy=BinaryBase64EncodePolicy(),
    message_decode_policy=BinaryBase64DecodePolicy()
  )
  
  if queue_client is None:
    print("Queue client is not available.")
    return []
  
  messages = queue_client.receive_messages()
  received_messages = []
  for msg_batch in messages.by_page():
    for msg in msg_batch:

      inserted_at = msg.inserted_on if msg.inserted_on else None
      try:
        if inserted_at and not isinstance(inserted_at, datetime):
          inserted_at = datetime.fromisoformat(str(inserted_at))
      except Exception:
        inserted_at = None
        
      try:
        notification = Notifications(
          message_queue_id=msg.id,
          classification="Need Attention" if class_type == "hard" else "Warning",  
          inserted_at=inserted_at,
        )
        db.add(notification)
        db.commit()
        db.refresh(notification)
        notification_id = notification.id
        
        if class_type == "hard":          
          alert_log = get_alert_log(
            db, 
            msg.content.decode()
          )
          if alert_log is not None:
            create_datetime = get_create_datetime(alert_log)
            error_datetime = get_error_datetime(alert_log)
            notification_info = Notifications_info(
              notification_id=notification_id,
              error_log_id=alert_log.ERROR_LOG_ID,
              data_module=alert_log.MODULE,
              zip_file_name=alert_log.ZIP_FILE_NAME,
              source_file_name=alert_log.SOURCE_FILE_NAME,
              create_datetime=create_datetime,
              job_name=alert_log.JOB_NAME,
              error_code=alert_log.ERROR_CODE,
              error_datetime=error_datetime
            )
            db.add(notification_info)
            db.commit()
            received_messages.append({
              "message_id": msg.id,
            })
          else:
            db.delete(notification)
            db.commit()
            print(f"Alert log not found for message: {msg.content.decode()}")
            
          queue_client.delete_message(msg)  # Dequeue (delete) the message after appending
          
        elif class_type == "soft":
          # Decode bytes to string if needed
          content_str = msg.content.decode() if isinstance(msg.content, bytes) else msg.content
          # Parse the string as a JSON array
          messages_list = [item.strip() for item in content_str.strip("[]").split(",") if item.strip()]
          
          if not isinstance(messages_list, list):
            messages_list = [messages_list]
          
          valid_alerts = 0;  
          for single_message in messages_list:
            alert_log = get_alert_log(
              db, 
              single_message
            )
            if alert_log is not None:
              create_datetime = get_create_datetime(alert_log)
              error_datetime = get_error_datetime(alert_log)
              notification_info = Notifications_info(
                notification_id=notification_id,
                error_log_id=alert_log.ERROR_LOG_ID,
                data_module=alert_log.MODULE,
                zip_file_name=alert_log.ZIP_FILE_NAME,
                source_file_name=alert_log.SOURCE_FILE_NAME,
                create_datetime=create_datetime,
                job_name=alert_log.JOB_NAME,
                error_code=alert_log.ERROR_CODE,
                error_datetime=error_datetime
              )
              db.add(notification_info)
              db.commit()
              valid_alerts += 1
              received_messages.append({
                "message_id": single_message,
              })
            else: 
              print(f"Alert log not found for message: {single_message}")
            
          if valid_alerts == 0:
            db.delete(notification)
            db.commit()
            print(f"No valid alerts found for message: {msg.content.decode()}")
          queue_client.delete_message(msg)  # Dequeue (delete) the message after appending
        
      except Exception as e:
        db.rollback()
        print(f"Error writing to database: {e}")
      
  return received_messages


def get_alert_log(
  db: Annotated[Session, Depends(get_db)],
  error_log_id: str
):
  try:
    result =  db.execute(
      text("""
      SELECT * FROM [ALERTS].[ALERTS_ERROR_LOGS]
      WHERE ERROR_LOG_ID = :error_log_id
      """),
      {"error_log_id": error_log_id}
    )
    alert_log = result.fetchone()
  except Exception as e:
    print(f"Error querying ALERTS_ERROR_LOGS", e)
    alert_log = None
  return alert_log

def get_create_datetime(
  alert_log: dict | None = None
):
  create_datetime = alert_log.CREATE_DATETIME if alert_log.CREATE_DATETIME else None
  try:
    if create_datetime and not isinstance(create_datetime, datetime):
      create_datetime = datetime.fromisoformat(str(create_datetime))
  except Exception:
    create_datetime = None
  return create_datetime

def get_error_datetime(
  alert_log: dict | None = None
):
  error_datetime = alert_log.ERROR_DATETIME if alert_log.ERROR_DATETIME else None
  try:
    if error_datetime and not isinstance(error_datetime, datetime):
      error_datetime = datetime.fromisoformat(str(error_datetime))
  except Exception:
    error_datetime = None
  return error_datetime

# if SCHEDULER_ENABLED.lower() == "true":
#   scheduler = BackgroundScheduler(daemon=True)
#   # You need to provide a valid db session and class_type for the scheduled job.
#   # Since scheduler jobs run outside of a request context, you must create a new db session manually.

#   def scheduled_job_hard():
#     db = SessionLocal()
#     try:
#         # Replace 'hard' with the desired class_type or make it configurable
#         get_messages(db, "hard")
#     finally:
#         db.close()
#   scheduler.add_job(scheduled_job_hard, 'interval', seconds=int(SCHEDULER_INTERVAL))
  
#   def scheduled_job_soft():
#     db = SessionLocal()
#     try:
#         # Replace 'hard' with the desired class_type or make it configurable
#         get_messages(db, "soft")
#     finally:
#         db.close()
#   scheduler.add_job(scheduled_job_soft, 'interval', seconds=int(SCHEDULER_INTERVAL))
  
#   scheduler.start()

#   import atexit
#   from database import SessionLocal

#   @atexit.register
#   def shutdown():
#       scheduler.shutdown()
# else :
#   print("Scheduler is disabled.")
    
# time_to_live = 259200 #3days
# server = 'ema-dap-dev-iz-sqldb-001.database.windows.net'
# database = 'izdap001'
# username = 'emadapsqladmin'
# password = 'b8W?SWo$=4UD'
# driver = '{ODBC Driver 18 for SQL Server}'

# conn_str = f"""
#     DRIVER={driver};
#     SERVER={server};
#     DATABASE={database};
#     UID={username};
#     PWD={password};
#     Encrypt=yes;
#     TrustServerCertificate=no;
#     Connection Timeout=30;
# """
# conn = pyodbc.connect(conn_str)
# cursor = conn.cursor()
# cursor.execute("""
# SELECT 
#     dm.ALERT_TYPE_ID,
#     ael.error_code,
#     ael.error_log_id
# FROM 
#     [ALERTS].[ALERTS_ERROR_LOGS] AEL
# JOIN 
#     [ALERTS].[ERROR_LIST] EL
#     ON AEL.error_code = EL.error_code
# JOIN 
#     [ALERTS].[FILE_LIST] FL
#     ON AEL.file_id = FL.file_id
# JOIN 
#     [ALERTS].[DISTRIBUTION_MAPPING] DM
#     ON DM.file_group_id = FL.file_group_id 
#     AND DM.error_id = EL.error_id 
# WHERE 
#     ael.alert_processed_datetime IS NULL
#     AND ael.error_log_id NOT IN (
#         SELECT error_log_id FROM alert_sent
#     )

# """
#               )


  # get_current_user_response = await get_current_user(db, request.cookies.get(auth_cookie_name))
  # if isinstance(get_current_user_response, StarletteResponse):
  #     return get_current_user_response
  # user = get_current_user_response

  # if user.role_id != await get_admin_role_id(db):
  #     return unauthorised_response()

  # # Example logic for the test feature
  # data = {
  #     "message": "This is a test feature response",
  #     "timestamp": datetime.now(timezone("Asia/Singapore")).isoformat()
  # }

  # return {
  #     api_status_key: api_status_success,
  #     api_message_key: "Test feature accessed successfully",
  #     api_data_key: data
  # }
  # return {"message": "This is a test feature response", "timestamp": datetime.now(timezone("Asia/Singapore")).isoformat()} 
  # conn = pyodbc.connect(conn_str)
  # cursor = conn.cursor()
  # cursor.execute("""
  # SELECT 
  #   dm.ALERT_TYPE_ID,
  #   ael.error_code,
  #   ael.error_log_id
  # FROM 
  #   [ALERTS].[ALERTS_ERROR_LOGS] AEL
  # JOIN 
  #   [ALERTS].[ERROR_LIST] EL
  #   ON AEL.error_code = EL.error_code
  # JOIN 
  #   [ALERTS].[FILE_LIST] FL
  #   ON AEL.file_id = FL.file_id
  # JOIN 
  #   [ALERTS].[DISTRIBUTION_MAPPING] DM
  #   ON DM.file_group_id = FL.file_group_id 
  #   AND DM.error_id = EL.error_id 
  # WHERE 
  #   ael.alert_processed_datetime IS NULL
  #   AND ael.error_log_id NOT IN (
  #       SELECT error_log_id FROM alert_sent
  #   )

  # """
  # )
  # columns = [column[0] for column in cursor.description]
  # rows = cursor.fetchall()
  # df = pd.DataFrame.from_records(rows, columns=columns)

  # for index, row in df.iterrows():
  #     alert_type = row['ALERT_TYPE_ID']
  #     error_code = row['error_code']
  #     error_log_id = row['error_log_id']

  #     message_content = error_code.encode('utf-8')

  #     if alert_type == 1:
  #         time_to_live = 259200  # 3 days in seconds
  #         queue_client.send_message(message_content, time_to_live=time_to_live)

  #     elif alert_type == 2:
  #         queue_client.send_message(message_content)
  #         send_email()

  #     # Insert the error_log_id into alert_sent table
  #     cursor.execute("""
  #         INSERT INTO alert_sent (error_log_id)
  #         VALUES (?)
  #     """, (error_log_id,))
  # conn.commit()
  # Receive messages from the Azure queue
  # messages = queue_client.receive_messages(messages_per_page=1)
  
  
  
  

  
  
  
  # Dequeue (delete) messages after reading
  # for msg_batch in messages.by_page():
  #   for msg in msg_batch:
  #     queue_client.delete_message(msg)  # Remove message from the queue
  # received_messages = []
  # for msg_batch in messages.by_page():
  #   for msg in msg_batch:
  #     received_messages.append({
  #       "message_id": msg.id,
  #       "content": msg.content,
  #       "insertion_time": msg.inserted_on.isoformat() if msg.inserted_on else None
  #     })
      
      
  # return received_messages